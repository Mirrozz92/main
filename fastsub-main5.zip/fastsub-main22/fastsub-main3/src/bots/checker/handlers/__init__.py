"""Checker bot handlers."""
