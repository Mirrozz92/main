"""Combined advertiser + publisher bot."""
