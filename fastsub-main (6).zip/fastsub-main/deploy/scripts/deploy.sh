#!/usr/bin/env bash
# FastSub deployment script (без CI/CD, ручной запуск).
#
# Usage: ./deploy.sh [--no-backup] [--no-migrate]
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/opt/fastsub}"
DO_BACKUP=1
DO_MIGRATE=1

for arg in "$@"; do
    case "${arg}" in
        --no-backup) DO_BACKUP=0 ;;
        --no-migrate) DO_MIGRATE=0 ;;
        *) echo "Unknown arg: ${arg}" >&2; exit 2 ;;
    esac
done

cd "${PROJECT_DIR}"

echo "==> Pulling latest changes"
git pull --ff-only

if [ "${DO_BACKUP}" -eq 1 ]; then
    echo "==> Pre-deploy backup"
    bash "${PROJECT_DIR}/deploy/scripts/backup.sh"
fi

echo "==> Building images"
docker compose build

echo "==> Bringing services up"
docker compose up -d --remove-orphans

# Recreated containers (esp. api) get fresh IPs. `nginx -s reload` does NOT
# reliably re-resolve the `server api:8000` upstream after a recreate (it can
# keep the stale IP and serve public 502s while the in-container health check
# still passes), so do a full restart — that re-resolves the upstream cleanly.
echo "==> Restarting nginx (re-resolve api upstream)"
docker compose restart nginx

if [ "${DO_MIGRATE}" -eq 1 ]; then
    echo "==> Waiting for postgres"
    for _ in {1..30}; do
        if docker compose exec -T postgres pg_isready -U "$(grep ^POSTGRES_USER .env | cut -d= -f2)" >/dev/null 2>&1; then
            break
        fi
        sleep 1
    done

    echo "==> Running migrations"
    docker compose run --rm api alembic upgrade head
fi

echo "==> Health check"
sleep 3
API_PUBLIC_HOST="$(grep ^API_PUBLIC_HOST= .env | cut -d= -f2- || true)"
for _ in {1..20}; do
    # Prefer the public endpoint through nginx (validates the whole path incl. TLS);
    # fall back to the in-container check if API_PUBLIC_HOST has no valid cert.
    if curl -sf "https://${API_PUBLIC_HOST}/health" >/dev/null \
       || docker compose exec -T api python -c \
            "import urllib.request; urllib.request.urlopen('http://localhost:8000/health')" >/dev/null 2>&1; then
        echo "==> Deployment successful ✓"
        exit 0
    fi
    sleep 1
done

echo "ERROR: health check failed" >&2
exit 1
