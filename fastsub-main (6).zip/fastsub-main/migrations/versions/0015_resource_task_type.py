"""Add CampaignResource.task_type (subscribe / boost / start_bot).

Orthogonal to resource `type`: a channel/group can be a SUBSCRIBE or a BOOST
task; a bot is START_BOT. Existing rows: bot_start → start_bot, else subscribe.

Revision ID: 0015
Revises: 0014
"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0015"
down_revision: Union[str, Sequence[str], None] = "0014"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

TASK_TYPE = postgresql.ENUM(
    "subscribe", "boost", "start_bot", name="task_type", create_type=False
)


def upgrade() -> None:
    TASK_TYPE.create(op.get_bind(), checkfirst=True)
    op.add_column(
        "campaign_resources",
        sa.Column("task_type", TASK_TYPE, nullable=False, server_default="subscribe"),
    )
    # Existing bot_start resources are "start_bot" tasks; channels/groups stay subscribe.
    op.execute("UPDATE campaign_resources SET task_type = 'start_bot' WHERE type = 'bot_start'")


def downgrade() -> None:
    op.drop_column("campaign_resources", "task_type")
    TASK_TYPE.drop(op.get_bind(), checkfirst=True)
