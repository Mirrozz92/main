"""TON direct USDT top-ups.

Создаёт таблицу ton_topups — намерения прямого пополнения баланса рекламодателя
в USDT на наш TON-кошелёк, сверяемые фоновым воркером по уникальному memo.

Revision ID: 0012
Revises: 0011
"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0012"
down_revision: Union[str, Sequence[str], None] = "0011"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


TON_TOPUP_STATUS = postgresql.ENUM(
    "pending", "paid", "expired",
    name="ton_topup_status", create_type=False,
)


def upgrade() -> None:
    bind = op.get_bind()
    TON_TOPUP_STATUS.create(bind, checkfirst=True)

    op.create_table(
        "ton_topups",
        sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
        sa.Column(
            "advertiser_id",
            sa.BigInteger,
            sa.ForeignKey("advertisers.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("amount_rub", sa.Numeric(18, 4), nullable=False),
        sa.Column("expected_usdt", sa.Numeric(18, 6), nullable=False),
        sa.Column("memo", sa.String(32), nullable=False, unique=True),
        sa.Column("status", TON_TOPUP_STATUS, nullable=False, server_default="pending"),
        sa.Column("tx_hash", sa.String(128), nullable=True, unique=True),
        sa.Column("paid_usdt", sa.Numeric(18, 6), nullable=True),
        sa.Column(
            "transaction_id",
            sa.BigInteger,
            sa.ForeignKey("transactions.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_ton_topups_advertiser_id", "ton_topups", ["advertiser_id"])
    op.create_index("ix_ton_topups_status_expires", "ton_topups", ["status", "expires_at"])


def downgrade() -> None:
    op.drop_index("ix_ton_topups_status_expires", table_name="ton_topups")
    op.drop_index("ix_ton_topups_advertiser_id", table_name="ton_topups")
    op.drop_table("ton_topups")
    TON_TOPUP_STATUS.drop(op.get_bind(), checkfirst=True)
