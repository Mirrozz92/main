"""Campaign theme — тематика кампании (ниша рекламируемого ресурса).

Добавляет campaigns.theme (значения из BOT_NICHES). Паблишеры исключают
ненужные тематики через publisher_bots.excluded_themes, а API отдаёт тематику
в каждом задании /request-op.

Revision ID: 0011
Revises: 0010
"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0011"
down_revision: Union[str, Sequence[str], None] = "0010"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "campaigns",
        sa.Column(
            "theme",
            sa.String(32),
            nullable=True,
            comment="Тематика кампании (ниша из BOT_NICHES)",
        ),
    )
    op.create_index("ix_campaigns_theme", "campaigns", ["theme"])


def downgrade() -> None:
    op.drop_index("ix_campaigns_theme", table_name="campaigns")
    op.drop_column("campaigns", "theme")
