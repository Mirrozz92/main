"""Publisher bot minimum price-per-subscriber filter.

Adds publisher_bots.min_reward_rub: the minimum gross reward (₽ per subscriber)
a bot will serve. 0 = no filter (default).

Revision ID: 0019
Revises: 0018
"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0019"
down_revision: Union[str, Sequence[str], None] = "0018"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "publisher_bots",
        sa.Column(
            "min_reward_rub", sa.Numeric(18, 4), nullable=False, server_default="0"
        ),
    )


def downgrade() -> None:
    op.drop_column("publisher_bots", "min_reward_rub")
