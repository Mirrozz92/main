"""EndUser geo fields detected from the registration IP (country, city, VPN flag).

Revision ID: 0013
Revises: 0012
"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0013"
down_revision: Union[str, Sequence[str], None] = "0012"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("end_users", sa.Column("geo_country", sa.String(length=2), nullable=True))
    op.add_column("end_users", sa.Column("city", sa.String(length=80), nullable=True))
    op.add_column("end_users", sa.Column("is_vpn", sa.Boolean(), nullable=True))
    op.create_index("ix_end_users_geo_country", "end_users", ["geo_country"])


def downgrade() -> None:
    op.drop_index("ix_end_users_geo_country", table_name="end_users")
    op.drop_column("end_users", "is_vpn")
    op.drop_column("end_users", "city")
    op.drop_column("end_users", "geo_country")
