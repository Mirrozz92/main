"""Add 'get_user_chat_boosts' to the verification_method enum (boost tasks).

Revision ID: 0016
Revises: 0015
"""
from __future__ import annotations

from typing import Sequence, Union

from alembic import op

revision: str = "0016"
down_revision: Union[str, Sequence[str], None] = "0015"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # PG 12+ allows ADD VALUE inside a transaction (value just can't be used in
    # the same tx — we don't here).
    op.execute(
        "ALTER TYPE verification_method ADD VALUE IF NOT EXISTS 'get_user_chat_boosts'"
    )


def downgrade() -> None:
    # PostgreSQL cannot drop a value from an enum type — no-op.
    pass
