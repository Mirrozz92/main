"""Store the API token Fernet-encrypted so the integration mini-app can show/copy it.

Revision ID: 0014
Revises: 0013
"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0014"
down_revision: Union[str, Sequence[str], None] = "0013"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "publisher_api_tokens",
        sa.Column("token_encrypted", sa.LargeBinary(), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("publisher_api_tokens", "token_encrypted")
