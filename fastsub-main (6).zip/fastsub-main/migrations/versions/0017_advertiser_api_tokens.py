"""Advertiser API tokens — for bot-start confirmation.

Creates advertiser_api_tokens: a per-advertiser API key whose only job is to let
the advertiser's bot confirm bot-start tasks via POST /api/v1/advertiser/confirm-start.

Revision ID: 0017
Revises: 0016
"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0017"
down_revision: Union[str, Sequence[str], None] = "0016"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "advertiser_api_tokens",
        sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
        sa.Column(
            "advertiser_id",
            sa.BigInteger,
            sa.ForeignKey("advertisers.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("token_prefix", sa.String(16), nullable=False),
        sa.Column("token_hash", sa.String(64), nullable=False, unique=True),
        sa.Column("token_encrypted", sa.LargeBinary(), nullable=True),
        sa.Column("label", sa.String(128), nullable=False, server_default="Default"),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("revoked_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_used_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("requests_count", sa.BigInteger, nullable=False, server_default="0"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index(
        "ix_advertiser_api_tokens_advertiser_id", "advertiser_api_tokens", ["advertiser_id"]
    )
    op.create_index(
        "ix_advertiser_api_tokens_token_hash", "advertiser_api_tokens", ["token_hash"], unique=True
    )
    op.create_index(
        "ix_advertiser_api_tokens_active", "advertiser_api_tokens", ["is_active", "advertiser_id"]
    )


def downgrade() -> None:
    op.drop_index("ix_advertiser_api_tokens_active", table_name="advertiser_api_tokens")
    op.drop_index("ix_advertiser_api_tokens_token_hash", table_name="advertiser_api_tokens")
    op.drop_index("ix_advertiser_api_tokens_advertiser_id", table_name="advertiser_api_tokens")
    op.drop_table("advertiser_api_tokens")
