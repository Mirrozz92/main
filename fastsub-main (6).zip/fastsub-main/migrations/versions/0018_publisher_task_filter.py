"""Publisher bot task filtering — exclude task/resource types.

Adds excluded_task_types and excluded_resource_types (JSON arrays) to
publisher_bots so a publisher can opt out of serving certain kinds of tasks
(e.g. boosts, or bot-starts) on a given bot.

Revision ID: 0018
Revises: 0017
"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0018"
down_revision: Union[str, Sequence[str], None] = "0017"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "publisher_bots",
        sa.Column("excluded_task_types", sa.JSON(), nullable=False, server_default="[]"),
    )
    op.add_column(
        "publisher_bots",
        sa.Column("excluded_resource_types", sa.JSON(), nullable=False, server_default="[]"),
    )


def downgrade() -> None:
    op.drop_column("publisher_bots", "excluded_resource_types")
    op.drop_column("publisher_bots", "excluded_task_types")
