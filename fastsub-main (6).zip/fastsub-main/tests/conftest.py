"""Shared pytest fixtures."""

from __future__ import annotations

import os

# Установим тестовое окружение ДО импорта приложения
os.environ.setdefault("ENV", "test")

# Dummy-значения обязательных настроек, чтобы get_settings() строился в юнит-тестах
# (реальные секреты не нужны — БД здесь не используется).
for _k, _v in {
    "POSTGRES_HOST": "localhost",
    "POSTGRES_DB": "fastsub_test",
    "POSTGRES_USER": "fastsub_test",
    "POSTGRES_PASSWORD": "test",
    "REDIS_PASSWORD": "test",
    "MAIN_BOT_TOKEN": "0:test",
    "ADMIN_BOT_TOKEN": "0:test",
    "CRYPTOBOT_TOKEN": "test",
    "CRYPTOBOT_WEBHOOK_SECRET": "test",
    "SECRET_KEY": "x" * 64,
}.items():
    os.environ.setdefault(_k, _v)

from collections.abc import Callable  # noqa: E402
from datetime import UTC, datetime, timedelta  # noqa: E402
from decimal import Decimal  # noqa: E402
from typing import Any  # noqa: E402

import pytest  # noqa: E402

from src.core.db.models import (  # noqa: E402
    Advertiser,
    Campaign,
    Publisher,
    ResourceIssue,
    Transaction,
)
from src.core.db.models.enums import (  # noqa: E402
    CampaignStatus,
    IssueStatus,
    TransactionStatus,
    TransactionType,
)

NOW = datetime(2026, 1, 1, 12, 0, tzinfo=UTC)


@pytest.fixture
def make_publisher() -> Callable[..., Publisher]:
    """Factory for in-memory Publisher rows with sane money defaults."""

    def _make(**overrides: Any) -> Publisher:
        defaults: dict[str, Any] = {
            "id": 1,
            "balance_rub": Decimal("0.0000"),
            "hold_rub": Decimal("0.0000"),
            "total_earned_rub": Decimal("0.0000"),
            "total_paid_out_rub": Decimal("0.0000"),
            "verified_subs_in_window": 0,
            "total_subscriptions": 0,
            "total_unsubscriptions": 0,
        }
        defaults.update(overrides)
        return Publisher(**defaults)

    return _make


@pytest.fixture
def make_issue() -> Callable[..., ResourceIssue]:
    """Factory for in-memory ResourceIssue rows.

    publisher_bot_id defaults to None so webhook emission is a no-op in tests.
    The reward split defaults are self-consistent (payout + commission = reward).
    """

    def _make(**overrides: Any) -> ResourceIssue:
        defaults: dict[str, Any] = {
            "link_id": "lnk_test000000000000000000",
            "task_id": "tsk_test000000000000000000",
            "publisher_id": 1,
            "publisher_bot_id": None,
            "publisher_token_id": 1,
            "user_tg_id": 555,
            "campaign_resource_id": 1,
            "reward_rub": Decimal("2.0000"),
            "publisher_payout_rub": Decimal("1.5000"),
            "platform_commission_rub": Decimal("0.5000"),
            "retention_bonus_rub": Decimal("0.0000"),
            "status": IssueStatus.PENDING,
            "issued_at": NOW,
            "expires_at": NOW + timedelta(hours=1),
            "user_context": {},
        }
        defaults.update(overrides)
        return ResourceIssue(**defaults)

    return _make


@pytest.fixture
def make_campaign() -> Callable[..., Campaign]:
    """Factory for in-memory Campaign rows with budget defaults."""

    def _make(**overrides: Any) -> Campaign:
        defaults: dict[str, Any] = {
            "id": 1,
            "advertiser_id": 1,
            "title": "Test campaign",
            "status": CampaignStatus.ACTIVE,
            "budget_total_rub": Decimal("1000.0000"),
            "budget_spent_rub": Decimal("0.0000"),
            "budget_reserved_rub": Decimal("0.0000"),
        }
        defaults.update(overrides)
        return Campaign(**defaults)

    return _make


@pytest.fixture
def make_advertiser() -> Callable[..., Advertiser]:
    """Factory for in-memory Advertiser rows with money defaults."""

    def _make(**overrides: Any) -> Advertiser:
        defaults: dict[str, Any] = {
            "id": 1,
            "tg_user_id": 111,
            "balance_rub": Decimal("0.0000"),
            "reserved_rub": Decimal("0.0000"),
            "total_spent_rub": Decimal("0.0000"),
        }
        defaults.update(overrides)
        return Advertiser(**defaults)

    return _make


@pytest.fixture
def make_payout_tx() -> Callable[..., Transaction]:
    """Factory for in-memory pending PUBLISHER_PAYOUT transactions."""

    def _make(**overrides: Any) -> Transaction:
        defaults: dict[str, Any] = {
            "id": 1,
            "type": TransactionType.PUBLISHER_PAYOUT,
            "status": TransactionStatus.PENDING,
            "amount_rub": Decimal("-100.0000"),
            "publisher_id": 1,
            "meta": {},
        }
        defaults.update(overrides)
        return Transaction(**defaults)

    return _make


class _FakeTxRepo:
    """Records create() calls and returns a Transaction-like object."""

    def __init__(self) -> None:
        self.created: list[dict[str, Any]] = []

    async def create(self, **kwargs: Any) -> Transaction:
        self.created.append(kwargs)
        return Transaction(
            id=len(self.created),
            type=kwargs.get("type"),
            status=kwargs.get("status", TransactionStatus.PENDING),
            amount_rub=kwargs.get("amount_rub"),
            publisher_id=kwargs.get("publisher_id"),
            meta=kwargs.get("meta") or {},
        )

    def of_type(self, tx_type: TransactionType) -> list[dict[str, Any]]:
        """All recorded create() kwargs whose type matches."""
        return [c for c in self.created if c.get("type") == tx_type]


@pytest.fixture
def fake_tx_repo() -> _FakeTxRepo:
    return _FakeTxRepo()
