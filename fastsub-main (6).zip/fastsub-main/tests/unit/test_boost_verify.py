"""Unit tests for boost detection in the checker pool (no DB / no Telegram)."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from src.integrations.telegram.checker_pool import CheckerBotPool


class _Boost:
    def __init__(self, expiration_date: datetime | None) -> None:
        self.expiration_date = expiration_date


class _Result:
    def __init__(self, boosts: list[_Boost]) -> None:
        self.boosts = boosts


class _FakeBot:
    """Stand-in for an aiogram Bot exposing get_user_chat_boosts."""

    def __init__(self, *, result: object = None, raises: bool = False) -> None:
        self._result = result
        self._raises = raises

    async def get_user_chat_boosts(self, *, chat_id: int, user_id: int) -> object:
        if self._raises:
            raise RuntimeError("telegram error")
        return self._result


def _pool_with(tg_id: int, bot: object) -> CheckerBotPool:
    pool = CheckerBotPool()
    pool._bots_by_tg_id[tg_id] = bot  # type: ignore[index]
    return pool


_FUTURE = datetime.now(timezone.utc) + timedelta(hours=10)
_PAST = datetime.now(timezone.utc) - timedelta(hours=10)


class TestUserIsBoosting:
    async def test_active_boost_is_true(self) -> None:
        pool = _pool_with(999, _FakeBot(result=_Result([_Boost(_FUTURE)])))
        assert await pool.user_is_boosting(checker_bot_tg_id=999, chat_id=1, user_id=2) is True

    async def test_no_expiry_treated_as_active(self) -> None:
        pool = _pool_with(999, _FakeBot(result=_Result([_Boost(None)])))
        assert await pool.user_is_boosting(checker_bot_tg_id=999, chat_id=1, user_id=2) is True

    async def test_only_expired_boost_is_false(self) -> None:
        pool = _pool_with(999, _FakeBot(result=_Result([_Boost(_PAST)])))
        assert await pool.user_is_boosting(checker_bot_tg_id=999, chat_id=1, user_id=2) is False

    async def test_no_boosts_is_false(self) -> None:
        pool = _pool_with(999, _FakeBot(result=_Result([])))
        assert await pool.user_is_boosting(checker_bot_tg_id=999, chat_id=1, user_id=2) is False

    async def test_unknown_bot_is_none(self) -> None:
        pool = CheckerBotPool()
        assert await pool.user_is_boosting(checker_bot_tg_id=404, chat_id=1, user_id=2) is None

    async def test_telegram_error_is_none(self) -> None:
        pool = _pool_with(999, _FakeBot(raises=True))
        assert await pool.user_is_boosting(checker_bot_tg_id=999, chat_id=1, user_id=2) is None
