"""Unit tests for stats helper math and bucket alignment (no DB)."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal

from src.domain.stats.repository import _bucket_starts, _churn, _growth, _retention


def test_growth_positive() -> None:
    assert _growth(Decimal("150"), Decimal("100")) == 50.0


def test_growth_negative() -> None:
    assert _growth(Decimal("80"), Decimal("100")) == -20.0


def test_growth_no_baseline_is_none() -> None:
    assert _growth(Decimal("10"), Decimal("0")) is None


def test_retention_basic() -> None:
    assert _retention(100, 5) == 95.0


def test_retention_no_subs_is_none() -> None:
    assert _retention(0, 0) is None


def test_retention_clamps_at_zero() -> None:
    assert _retention(10, 25) == 0.0  # never negative


def test_churn_ratio() -> None:
    assert _churn(100, 4) == 0.04


def test_churn_no_subs_is_none() -> None:
    assert _churn(0, 3) is None


def test_bucket_starts_day_count() -> None:
    since = datetime(2026, 6, 1, 10, 0, tzinfo=UTC)
    until = datetime(2026, 6, 7, 23, 0, tzinfo=UTC)
    days = _bucket_starts(since, until, "day")
    assert days[0] == datetime(2026, 6, 1, 0, 0, tzinfo=UTC)
    assert len(days) == 7
    assert all(d.hour == 0 for d in days)


def test_bucket_starts_week_aligns_to_monday() -> None:
    # 2026-06-03 is a Wednesday; week start must be Monday 2026-06-01
    since = datetime(2026, 6, 3, 12, 0, tzinfo=UTC)
    until = datetime(2026, 6, 20, 0, 0, tzinfo=UTC)
    weeks = _bucket_starts(since, until, "week")
    assert weeks[0] == datetime(2026, 6, 1, 0, 0, tzinfo=UTC)
    assert weeks[0].weekday() == 0
    assert (weeks[1] - weeks[0]).days == 7


def test_bucket_starts_month() -> None:
    since = datetime(2026, 1, 15, tzinfo=UTC)
    until = datetime(2026, 4, 2, tzinfo=UTC)
    months = _bucket_starts(since, until, "month")
    assert [m.month for m in months] == [1, 2, 3, 4]
    assert all(m.day == 1 for m in months)
