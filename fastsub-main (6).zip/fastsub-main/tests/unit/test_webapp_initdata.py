"""Unit tests for Telegram Mini App initData validation."""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from urllib.parse import urlencode

from src.integrations.telegram.webapp import validate_init_data

BOT_TOKEN = "123456:TESTTOKEN_abcdef"


def _make_init_data(bot_token: str, user: dict, auth_date: int | None = None) -> str:
    auth_date = auth_date if auth_date is not None else int(time.time())
    fields = {
        "auth_date": str(auth_date),
        "query_id": "AAEtest",
        "user": json.dumps(user, separators=(",", ":")),
    }
    dcs = "\n".join(f"{k}={fields[k]}" for k in sorted(fields))
    secret = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    fields["hash"] = hmac.new(secret, dcs.encode(), hashlib.sha256).hexdigest()
    return urlencode(fields)


def test_valid_init_data_returns_user() -> None:
    init = _make_init_data(BOT_TOKEN, {"id": 777, "first_name": "Аня"})
    data = validate_init_data(init, BOT_TOKEN)
    assert data is not None
    assert data["user"]["id"] == 777
    assert data["user"]["first_name"] == "Аня"


def test_tampered_hash_rejected() -> None:
    init = _make_init_data(BOT_TOKEN, {"id": 1})
    tampered = init.replace("id%22%3A1", "id%22%3A2")  # change the signed payload
    assert validate_init_data(tampered, BOT_TOKEN) is None


def test_wrong_token_rejected() -> None:
    init = _make_init_data(BOT_TOKEN, {"id": 1})
    assert validate_init_data(init, "999:OTHERTOKEN") is None


def test_expired_auth_date_rejected() -> None:
    old = int(time.time()) - 10_000
    init = _make_init_data(BOT_TOKEN, {"id": 1}, auth_date=old)
    assert validate_init_data(init, BOT_TOKEN, max_age_seconds=3600) is None
    # but accepted when freshness check is disabled
    assert validate_init_data(init, BOT_TOKEN, max_age_seconds=0) is not None


def test_empty_init_data_rejected() -> None:
    assert validate_init_data("", BOT_TOKEN) is None


def test_missing_hash_rejected() -> None:
    assert validate_init_data("auth_date=1&user=%7B%7D", BOT_TOKEN) is None
