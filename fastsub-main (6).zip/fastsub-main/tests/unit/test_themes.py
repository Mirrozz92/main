"""Unit tests for the campaign тематика feature (no DB required)."""

from __future__ import annotations

from src.api.v1.schemas.tasks import TaskItem
from src.bots.publisher.keyboards import excluded_themes_kb
from src.domain.campaigns.pricing import (
    BOT_NICHES,
    BOT_NICHE_LABELS,
    BOT_NICHES_SET,
    niche_label,
)
from src.domain.publisher_bots.service import VALID_THEMES


class TestNicheVocabulary:
    def test_every_niche_has_a_label(self) -> None:
        assert set(BOT_NICHES) == set(BOT_NICHE_LABELS)

    def test_valid_themes_match_bot_niches(self) -> None:
        # Publisher exclusions are validated against the same canonical vocabulary.
        assert VALID_THEMES == BOT_NICHES_SET

    def test_niche_label_known(self) -> None:
        assert niche_label("нейросети") == "Нейросети"

    def test_niche_label_none_and_unknown(self) -> None:
        assert niche_label(None) == "—"
        assert niche_label("") == "—"
        assert niche_label("несуществующая") == "несуществующая"


class TestExcludedThemesKeyboard:
    def test_buttons_show_share_and_mark(self) -> None:
        counts = {"музыка": 3, "кино": 1, "": 2}  # "" = untagged, total = 6
        kb = excluded_themes_kb(7, ["музыка"], counts)
        labels = [b.text for row in kb.inline_keyboard for b in row]

        music = next(t for t in labels if "Музыка" in t)
        assert music.startswith("✓ ")          # excluded → checkmark
        assert "50%" in music                   # 3 of 6 available

        cinema = next(t for t in labels if "Кино" in t)
        assert not cinema.startswith("✓ ")      # not excluded
        assert "17%" in cinema                  # round(100 * 1 / 6)

    def test_zero_total_does_not_divide_by_zero(self) -> None:
        kb = excluded_themes_kb(1, [], {})
        labels = [b.text for row in kb.inline_keyboard for b in row]
        assert any("0%" in t for t in labels)


class TestAdminCampaignThemeKeyboard:
    def test_current_theme_marked_and_back_present(self) -> None:
        from src.bots.admin import keyboards as kb

        k = kb.campaign_theme_select_kb(42, current="кино")
        texts = [b.text for row in k.inline_keyboard for b in row]
        cb_data = [b.callback_data for row in k.inline_keyboard for b in row]

        cinema = next(t for t in texts if "Кино" in t)
        assert cinema.startswith("✓ ")
        assert f"{kb.CB_CAMP_THEME_SET}42:кино" in cb_data
        assert f"{kb.CB_VIEW_CAMPAIGN}42" in cb_data  # back button

    def test_menu_prefix_does_not_collide_with_set_prefix(self) -> None:
        from src.bots.admin import keyboards as kb

        set_data = f"{kb.CB_CAMP_THEME_SET}1:музыка"
        assert not set_data.startswith(kb.CB_CAMP_SET_THEME_MENU)


class TestTaskItemSchema:
    def test_theme_fields_optional_and_settable(self) -> None:
        item = TaskItem(
            link_id="lnk_abcdef012345",
            type="channel",
            title="Test",
            reward_for_publisher="1.5000",
        )
        assert item.theme is None
        assert item.theme_label is None

        item2 = TaskItem(
            link_id="lnk_abcdef012345",
            type="channel",
            title="Test",
            theme="нейросети",
            theme_label="Нейросети",
            reward_for_publisher="1.5000",
        )
        assert item2.theme == "нейросети"
        assert item2.theme_label == "Нейросети"
