"""Unit tests for the publisher task/resource-type filter (no DB required)."""

from __future__ import annotations

import pytest

from src.bots.publisher import texts
from src.bots.publisher.keyboards import task_filter_kb
from src.core.db.models import PublisherBot
from src.core.db.models.enums import ResourceType, TaskType
from src.domain.exceptions import DomainError
from src.domain.publisher_bots.service import (
    VALID_RESOURCE_TYPES,
    VALID_TASK_TYPES,
    PublisherBotService,
)


class TestFilterVocabulary:
    def test_valid_sets_match_enums(self) -> None:
        assert VALID_TASK_TYPES == {e.value for e in TaskType}
        assert VALID_RESOURCE_TYPES == {e.value for e in ResourceType}

    def test_filter_order_keys_are_valid(self) -> None:
        for val, _ in texts.TASK_TYPE_FILTER_ORDER:
            assert val in VALID_TASK_TYPES
        for val, _ in texts.RESOURCE_TYPE_FILTER_ORDER:
            assert val in VALID_RESOURCE_TYPES


class TestTaskFilterKeyboard:
    def test_marks_excluded_and_enabled(self) -> None:
        kb = task_filter_kb(7, ["boost"], ["bot_start"])
        labels = [b.text for row in kb.inline_keyboard for b in row]

        assert next(t for t in labels if "Буст" in t).startswith("❌")
        assert next(t for t in labels if "Подписка" in t).startswith("✅")
        assert next(t for t in labels if t.endswith("Бот")).startswith("❌")  # bot_start
        assert next(t for t in labels if "Канал" in t).startswith("✅")

    def test_callback_data_format(self) -> None:
        kb = task_filter_kb(42, [], [])
        cb = [b.callback_data for row in kb.inline_keyboard for b in row]
        assert f"{texts.CB_FILTER_TOGGLE}42:t:subscribe" in cb
        assert f"{texts.CB_FILTER_TOGGLE}42:r:channel" in cb
        assert f"{texts.CB_FILTER_SAVE}42" in cb
        assert f"{texts.CB_BOT_SETTINGS}42" in cb  # cancel returns to settings

    def test_menu_prefix_does_not_swallow_toggle_or_save(self) -> None:
        # show_filter_menu is startswith(CB_FILTER_MENU) with NO state filter,
        # so toggle/save callbacks must not start with the menu prefix.
        assert not f"{texts.CB_FILTER_TOGGLE}5:t:boost".startswith(texts.CB_FILTER_MENU)
        assert not f"{texts.CB_FILTER_SAVE}5".startswith(texts.CB_FILTER_MENU)


class TestTaskFilterSummary:
    def test_all_enabled(self) -> None:
        assert texts.task_filter_summary([], []) == "все типы заданий"

    def test_everything_off_warns(self) -> None:
        assert "⚠️" in texts.task_filter_summary(["subscribe", "boost", "start_bot"], [])
        assert "⚠️" in texts.task_filter_summary([], ["channel", "group", "bot_start"])

    def test_partial_excludes_boost(self) -> None:
        s = texts.task_filter_summary(["boost"], [])
        assert "Подписка" in s
        assert "Буст" not in s


class TestServiceValidation:
    async def test_rejects_unknown_task_type(self) -> None:
        svc = PublisherBotService(None)  # session unused on this path
        with pytest.raises(DomainError):
            await svc.update_extra_settings(PublisherBot(), excluded_task_types=["nope"])

    async def test_rejects_unknown_resource_type(self) -> None:
        svc = PublisherBotService(None)
        with pytest.raises(DomainError):
            await svc.update_extra_settings(PublisherBot(), excluded_resource_types=["nope"])

    async def test_accepts_valid_values(self) -> None:
        svc = PublisherBotService(None)
        bot = PublisherBot()
        await svc.update_extra_settings(
            bot, excluded_task_types=["boost"], excluded_resource_types=["bot_start"],
        )
        assert bot.excluded_task_types == ["boost"]
        assert bot.excluded_resource_types == ["bot_start"]
