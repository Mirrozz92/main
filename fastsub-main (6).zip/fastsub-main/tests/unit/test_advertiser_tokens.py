"""Unit tests for advertiser API tokens (no DB required)."""

from __future__ import annotations

from src.domain.advertiser_tokens.service import (
    TOKEN_PREFIX_LITERAL,
    AdvertiserTokenService,
    hash_token,
)


class TestHash:
    def test_deterministic_and_sha256(self) -> None:
        assert hash_token("fsa_live_x") == hash_token("fsa_live_x")
        assert hash_token("a") != hash_token("b")
        assert len(hash_token("x")) == 64  # sha256 hex digest

    def test_prefix_constant(self) -> None:
        assert TOKEN_PREFIX_LITERAL == "fsa_live_"


class TestVerifyRejectsBadInput:
    async def test_wrong_prefix_returns_none_without_db(self) -> None:
        # A wrong/empty prefix short-circuits before any repository access,
        # so a None session is safe here.
        svc = AdvertiserTokenService(None)
        assert await svc.verify("fsp_live_publisherkey") is None  # publisher prefix
        assert await svc.verify("") is None
        assert await svc.verify("random-garbage") is None
