"""Unit tests for direct USDT (TON) top-up logic (no DB, no network)."""

from __future__ import annotations

import re
from decimal import Decimal
from unittest.mock import MagicMock

from src.bots.advertiser.handlers.topup_ton import _fmt_usdt, _wallet_deeplink
from src.core.db.models import TonTopup
from src.core.db.models.enums import TonTopupStatus
from src.domain.payments import PaymentsService
from src.integrations.ton import JettonTransfer
from src.shared.idgen import generate_memo


# ---------- memo ----------


def test_generate_memo_format() -> None:
    memo = generate_memo()
    assert re.fullmatch(r"FS[0-9a-f]{10}", memo), memo


def test_generate_memo_unique() -> None:
    memos = {generate_memo() for _ in range(1000)}
    assert len(memos) == 1000  # no collisions in a small sample


# ---------- display helpers ----------


def test_fmt_usdt_strips_trailing_zeros() -> None:
    assert _fmt_usdt(Decimal("5.230000")) == "5.23"
    assert _fmt_usdt(Decimal("5.000000")) == "5"
    assert _fmt_usdt(Decimal("0.100000")) == "0.1"
    assert _fmt_usdt(Decimal("0")) == "0"


def test_wallet_deeplink_has_amount_jetton_and_memo() -> None:
    link = _wallet_deeplink(
        wallet="UQwallet",
        jetton_master="EQjetton",
        expected_usdt=Decimal("5.250000"),
        memo="FS123abc4567",
    )
    assert link.startswith("https://app.tonkeeper.com/transfer/UQwallet?")
    # 5.25 USDT (6 decimals) → 5_250_000 minimal units
    assert "amount=5250000" in link
    assert "jetton=EQjetton" in link
    assert "text=FS123abc4567" in link


# ---------- matching / tolerance ----------


def _topup(memo: str = "FS0000000001", expected: str = "10") -> TonTopup:
    return TonTopup(
        memo=memo,
        expected_usdt=Decimal(expected),
        amount_rub=Decimal("1000"),
        status=TonTopupStatus.PENDING,
    )


def _transfer(comment: str | None, amount: str) -> JettonTransfer:
    return JettonTransfer(
        event_id="evt1",
        sender="0:abc",
        amount=Decimal(amount),
        comment=comment,
        utime=0,
    )


def _svc() -> PaymentsService:
    # _ton_match never touches the DB, so a dummy session is fine.
    return PaymentsService(MagicMock())


def test_match_exact_amount() -> None:
    svc = _svc()
    assert svc._ton_match(_topup(), _transfer("FS0000000001", "10")) is True


def test_match_within_tolerance() -> None:
    # default tolerance 2% → 9.8 USDT still accepted for a 10 USDT expectation
    svc = _svc()
    assert svc._ton_match(_topup(), _transfer("FS0000000001", "9.8")) is True


def test_reject_underpay_beyond_tolerance() -> None:
    svc = _svc()
    assert svc._ton_match(_topup(), _transfer("FS0000000001", "9.5")) is False


def test_reject_wrong_memo() -> None:
    svc = _svc()
    assert svc._ton_match(_topup(), _transfer("FSdeadbeef00", "10")) is False


def test_reject_missing_comment() -> None:
    svc = _svc()
    assert svc._ton_match(_topup(), _transfer(None, "10")) is False


def test_match_trims_whitespace_comment() -> None:
    svc = _svc()
    assert svc._ton_match(_topup(), _transfer("  FS0000000001  ", "10")) is True


def test_overpay_is_accepted() -> None:
    svc = _svc()
    assert svc._ton_match(_topup(), _transfer("FS0000000001", "12")) is True
