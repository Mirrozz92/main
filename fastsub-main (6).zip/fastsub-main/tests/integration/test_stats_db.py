"""Integration tests for StatsRepository against a real DB."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from decimal import Decimal
from types import SimpleNamespace

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.db.models import ResourceIssue
from src.core.db.models.enums import IssueStatus
from src.domain.stats import StatsRepository

pytestmark = pytest.mark.asyncio

SINCE = datetime(2026, 6, 1, tzinfo=UTC)
UNTIL = datetime(2026, 6, 30, tzinfo=UTC)


async def _issue(
    db_session: AsyncSession,
    seed: SimpleNamespace,
    n: int,
    *,
    status: IssueStatus,
    issued_at: datetime,
    subscribed_at: datetime | None = None,
    verified_at: datetime | None = None,
    unsubscribed_at: datetime | None = None,
    payout: str = "1.5000",
    bonus: str = "0.5000",
) -> None:
    db_session.add(
        ResourceIssue(
            link_id=f"lnk_stat{n:020d}",
            task_id=f"tsk_stat{n:020d}",
            publisher_id=seed.publisher.id,
            publisher_bot_id=seed.bot.id,
            publisher_token_id=seed.token.id,
            campaign_resource_id=seed.resource.id,
            user_tg_id=70000 + n,
            status=status,
            reward_rub=Decimal("2.0000"),
            publisher_payout_rub=Decimal(payout),
            platform_commission_rub=Decimal("0.5000"),
            retention_bonus_rub=Decimal(bonus),
            issued_at=issued_at,
            expires_at=issued_at + timedelta(hours=1),
            subscribed_at=subscribed_at,
            verified_at=verified_at,
            unsubscribed_at=unsubscribed_at,
        )
    )


async def _seed_issues(db_session: AsyncSession, seed: SimpleNamespace) -> None:
    d = lambda day: datetime(2026, 6, day, tzinfo=UTC)  # noqa: E731
    # A, B: verified/paid in window  → earned + subs
    await _issue(db_session, seed, 1, status=IssueStatus.VERIFIED, issued_at=d(4),
                 subscribed_at=d(5), verified_at=d(6), payout="1.5000", bonus="0.5000")
    await _issue(db_session, seed, 2, status=IssueStatus.PAID, issued_at=d(9),
                 subscribed_at=d(10), verified_at=d(11), payout="3.0000", bonus="0.0000")
    # C: churned in window → subs + unsubs
    await _issue(db_session, seed, 3, status=IssueStatus.UNSUBSCRIBED, issued_at=d(11),
                 subscribed_at=d(12), unsubscribed_at=d(13), payout="1.0000", bonus="0.0000")
    # D: subscribed in the PREVIOUS window (May) → baseline only
    await _issue(db_session, seed, 4, status=IssueStatus.VERIFIED,
                 issued_at=datetime(2026, 5, 14, tzinfo=UTC),
                 subscribed_at=datetime(2026, 5, 15, tzinfo=UTC),
                 verified_at=datetime(2026, 5, 16, tzinfo=UTC), payout="1.0000", bonus="0.0000")
    # E: issued in window, never subscribed
    await _issue(db_session, seed, 5, status=IssueStatus.PENDING, issued_at=d(20))
    await db_session.flush()


async def test_summary_metrics_and_growth(db_session: AsyncSession, seed: SimpleNamespace) -> None:
    await _seed_issues(db_session, seed)
    repo = StatsRepository(db_session)
    s = await repo.summary(publisher_id=seed.publisher.id, since=SINCE, until=UNTIL)

    assert s.subs == 3
    assert s.unsubs == 1
    assert s.earned_rub == Decimal("5")          # (1.5+0.5) + 3.0
    assert s.retention_pct == 66.7               # 100*(1 - 1/3)
    assert s.churn_ratio == 0.3333
    # previous window had 1 sub (D) → 200% growth
    assert s.subs_growth_pct == 200.0


async def test_timeseries_sums(db_session: AsyncSession, seed: SimpleNamespace) -> None:
    await _seed_issues(db_session, seed)
    repo = StatsRepository(db_session)
    pts = await repo.timeseries(publisher_id=seed.publisher.id, since=SINCE, until=UNTIL, bucket="day")

    assert len(pts) == 30  # June 1..30, zero-filled
    assert sum(p.subs for p in pts) == 3
    assert sum(p.unsubs for p in pts) == 1
    assert sum(p.earned_rub for p in pts) == Decimal("5")


async def test_by_resource_and_by_bot(db_session: AsyncSession, seed: SimpleNamespace) -> None:
    await _seed_issues(db_session, seed)
    repo = StatsRepository(db_session)

    res = await repo.by_resource(publisher_id=seed.publisher.id, since=SINCE, until=UNTIL)
    assert len(res) == 1
    assert res[0].resource_id == seed.resource.id
    assert res[0].subs == 3 and res[0].unsubs == 1
    assert res[0].earned_rub == Decimal("5")

    bots = await repo.by_bot(publisher_id=seed.publisher.id, since=SINCE, until=UNTIL)
    assert len(bots) == 1
    assert bots[0].bot_id == seed.bot.id
    assert bots[0].subs == 3
    assert bots[0].earned_rub == Decimal("5")


async def test_bot_scope_and_listing(db_session: AsyncSession, seed: SimpleNamespace) -> None:
    await _seed_issues(db_session, seed)
    repo = StatsRepository(db_session)

    listed = await repo.list_bots(publisher_id=seed.publisher.id)
    assert [b.bot_id for b in listed] == [seed.bot.id]

    assert await repo.bot_belongs_to_publisher(publisher_id=seed.publisher.id, bot_id=seed.bot.id) is True
    assert await repo.bot_belongs_to_publisher(publisher_id=seed.publisher.id, bot_id=999_999) is False

    # scoping to a foreign bot yields nothing
    s = await repo.summary(publisher_id=seed.publisher.id, since=SINCE, until=UNTIL, bot_id=999_999)
    assert s.subs == 0 and s.earned_rub == Decimal("0")
