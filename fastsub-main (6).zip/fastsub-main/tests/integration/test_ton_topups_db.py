"""Integration tests for direct USDT (TON) top-ups against a real DB.

Exercises migration 0012 (ton_topups table) plus the crediting path:
balance is credited exactly once, idempotently, with a ledger Transaction.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from decimal import Decimal

import pytest
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.db.models import Advertiser, TonTopup, Transaction
from src.core.db.models.enums import TonTopupStatus, TransactionStatus, TransactionType
from src.domain.payments import PaymentsService, TonTopupRepository
from src.integrations.ton import JettonTransfer

pytestmark = pytest.mark.asyncio


async def _advertiser(db_session: AsyncSession) -> Advertiser:
    adv = Advertiser(
        tg_user_id=42_424_242,
        balance_rub=Decimal("0.0000"),
        reserved_rub=Decimal("0.0000"),
        total_spent_rub=Decimal("0.0000"),
    )
    db_session.add(adv)
    await db_session.flush()
    return adv


class _FakeCryptoBot:
    """Stub CryptoBotClient that only serves a fixed exchange rate."""

    async def __aenter__(self) -> "_FakeCryptoBot":
        return self

    async def __aexit__(self, *args: object) -> None:
        return None

    async def get_rate(self, source: str, target: str) -> Decimal:
        return Decimal("100")  # 1 USDT = 100 ₽


async def test_migration_created_ton_topups_table(db_session: AsyncSession) -> None:
    # If migration 0012 didn't apply, selecting from the table raises.
    rows = (await db_session.execute(select(TonTopup))).scalars().all()
    assert rows == []


async def test_create_ton_topup_uses_rate(
    db_session: AsyncSession, monkeypatch: pytest.MonkeyPatch
) -> None:
    import src.domain.payments.service as svc_mod

    monkeypatch.setattr(svc_mod, "CryptoBotClient", lambda *a, **k: _FakeCryptoBot())
    adv = await _advertiser(db_session)

    svc = PaymentsService(db_session)
    topup = await svc.create_ton_topup(advertiser=adv, amount_rub=Decimal("1000"))

    assert topup.status == TonTopupStatus.PENDING
    assert topup.amount_rub == Decimal("1000.0000")
    assert topup.expected_usdt == Decimal("10.000000")  # 1000 / 100
    assert topup.memo.startswith("FS")


async def test_credit_ton_topup_idempotent(db_session: AsyncSession) -> None:
    adv = await _advertiser(db_session)
    repo = TonTopupRepository(db_session)
    topup = await repo.create(
        advertiser_id=adv.id,
        amount_rub=Decimal("1000"),
        expected_usdt=Decimal("10"),
        memo="FS0000000099",
        expires_at=datetime.now(UTC) + timedelta(minutes=60),
    )
    svc = PaymentsService(db_session)
    transfer = JettonTransfer(
        event_id="evt_abc", sender="0:x", amount=Decimal("10"),
        comment="FS0000000099", utime=0,
    )

    assert await svc.try_credit_ton_topup(topup, transfer) is True
    await db_session.flush()
    await db_session.refresh(adv)

    assert adv.balance_rub == Decimal("1000.0000")
    assert topup.status == TonTopupStatus.PAID
    assert topup.tx_hash == "evt_abc"
    assert topup.paid_usdt == Decimal("10.000000")

    txs = (
        await db_session.execute(
            select(Transaction).where(
                Transaction.advertiser_id == adv.id,
                Transaction.type == TransactionType.ADVERTISER_TOPUP,
            )
        )
    ).scalars().all()
    assert len(txs) == 1
    assert txs[0].status == TransactionStatus.COMPLETED
    assert txs[0].meta.get("method") == "ton_usdt"

    # Second attempt with the same transfer must NOT double-credit.
    assert await svc.try_credit_ton_topup(topup, transfer) is False
    await db_session.refresh(adv)
    assert adv.balance_rub == Decimal("1000.0000")


async def test_expire_ton_topups(db_session: AsyncSession) -> None:
    adv = await _advertiser(db_session)
    repo = TonTopupRepository(db_session)
    topup = await repo.create(
        advertiser_id=adv.id,
        amount_rub=Decimal("500"),
        expected_usdt=Decimal("5"),
        memo="FS00000000ee",
        expires_at=datetime.now(UTC) - timedelta(minutes=1),  # already past
    )
    svc = PaymentsService(db_session)

    n = await svc.expire_ton_topups()
    assert n >= 1
    await db_session.flush()
    await db_session.refresh(topup)
    assert topup.status == TonTopupStatus.EXPIRED
