"""Aggregations for publisher statistics (dashboards + public API).

All metrics derive from `resource_issues`:
  - earned   = publisher_payout_rub + retention_bonus_rub, for verified/paid
               issues, bucketed by verified_at
  - subs     = issues that became subscribed (subscribed_at), "продажи подписок"
  - unsubs   = issues that churned (unsubscribed_at)
  - issued   = issues handed out (issued_at)
  - retention% = 100 * (1 - unsubs/subs)
  - churn    = unsubs / subs

Everything is scoped to one publisher, optionally narrowed to a single bot
and/or a single campaign resource, over a [since, until] window.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Any

from dateutil.relativedelta import relativedelta
from sqlalchemy import ColumnElement, and_, case, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.db.models import Campaign, CampaignResource, EndUser, PublisherBot, ResourceIssue
from src.core.db.models.enums import CampaignStatus, IssueStatus

_EARNED_STATUSES = (IssueStatus.VERIFIED, IssueStatus.PAID)
_VALID_BUCKETS = ("day", "week", "month")

DEMOGRAPHIC_DIMENSIONS = ("nationality", "age", "premium")

# Display names for the most common countries; any other ISO-2 falls back to its
# flag + raw code.
_COUNTRY_NAMES: dict[str, str] = {
    "RU": "Россия", "UA": "Украина", "BY": "Беларусь", "KZ": "Казахстан",
    "UZ": "Узбекистан", "KG": "Киргизия", "TJ": "Таджикистан", "AM": "Армения",
    "AZ": "Азербайджан", "GE": "Грузия", "MD": "Молдова", "TM": "Туркмения",
    "US": "США", "GB": "Великобритания", "DE": "Германия", "FR": "Франция",
    "PL": "Польша", "TR": "Турция", "IL": "Израиль", "IN": "Индия",
    "CN": "Китай", "BR": "Бразилия", "ES": "Испания", "IT": "Италия",
    "NL": "Нидерланды", "CA": "Канада", "LV": "Латвия", "LT": "Литва",
    "EE": "Эстония",
}

_AGE_LABELS: dict[str, str] = {
    "under_14": "До 14", "14_16": "14–16", "16_18": "16–18", "18_plus": "18+",
}


def _flag_emoji(cc: str) -> str:
    if len(cc) != 2 or not cc.isalpha():
        return ""
    return chr(0x1F1E6 + ord(cc[0].upper()) - 65) + chr(0x1F1E6 + ord(cc[1].upper()) - 65)


def _demographic_entry(dimension: str, raw: object) -> tuple[str, str]:
    """Map a raw grouped value to a (stable key, human label)."""
    if dimension == "nationality":
        cc = (str(raw).strip().upper() if raw not in (None, "") else "")
        if not cc:
            return "unknown", "Неопределён"
        if cc == "OTHER":
            return "OTHER", "🌍 Другая"
        name = _COUNTRY_NAMES.get(cc, cc)
        flag = _flag_emoji(cc)
        return cc, (f"{flag} {name}" if flag else name)
    if dimension == "age":
        if raw in (None, ""):
            return "unknown", "Не указан"
        key = str(raw)
        return key, _AGE_LABELS.get(key, key)
    # premium — иконка-бейдж рисуется на фронте мини-аппа (см. PREMIUM_SVG)
    if raw is True:
        return "premium", "Premium"
    if raw is False:
        return "regular", "Без Premium"
    return "unknown", "Неизвестно"


def _earned_expr() -> ColumnElement[Decimal]:
    return ResourceIssue.publisher_payout_rub + ResourceIssue.retention_bonus_rub


def _growth(cur: Decimal, prev: Decimal) -> float | None:
    """Percent change cur vs prev; None when there's no baseline."""
    if prev == 0:
        return None
    return round(float((cur - prev) / prev * 100), 1)


def _retention(subs: int, unsubs: int) -> float | None:
    if subs <= 0:
        return None
    return round(max(0.0, (1 - unsubs / subs)) * 100, 1)


def _churn(subs: int, unsubs: int) -> float | None:
    if subs <= 0:
        return None
    return round(unsubs / subs, 4)


@dataclass(slots=True)
class SummaryStats:
    period_from: datetime
    period_to: datetime
    earned_rub: Decimal
    earned_growth_pct: float | None
    subs: int
    subs_growth_pct: float | None
    unsubs: int
    unsubs_growth_pct: float | None
    issued: int
    retention_pct: float | None
    churn_ratio: float | None


@dataclass(slots=True)
class TimeseriesPoint:
    bucket: datetime
    earned_rub: Decimal
    subs: int
    unsubs: int
    issued: int


@dataclass(slots=True)
class ResourceStat:
    resource_id: int
    title: str
    username: str | None
    type: str
    subs: int
    unsubs: int
    earned_rub: Decimal
    retention_pct: float | None


@dataclass(slots=True)
class BotStat:
    bot_id: int
    name: str
    username: str | None
    subs: int
    earned_rub: Decimal
    retention_pct: float | None


@dataclass(slots=True)
class BotRef:
    bot_id: int
    name: str
    username: str | None
    is_active: bool


@dataclass(slots=True)
class DemographicSlice:
    key: str
    label: str
    count: int


def _bucket_starts(since: datetime, until: datetime, bucket: str) -> list[datetime]:
    """Aligned bucket start datetimes covering [since, until] (for zero-fill)."""
    if bucket == "day":
        start = since.replace(hour=0, minute=0, second=0, microsecond=0)
        step = timedelta(days=1)
    elif bucket == "week":  # align to Monday, matching Postgres date_trunc('week')
        d = since.replace(hour=0, minute=0, second=0, microsecond=0)
        start = d - timedelta(days=d.weekday())
        step = timedelta(weeks=1)
    else:  # month
        start = since.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        step = None  # use relativedelta

    out: list[datetime] = []
    cur = start
    # Hard cap to avoid runaway ranges
    for _ in range(1000):
        if cur > until:
            break
        out.append(cur)
        cur = cur + relativedelta(months=1) if bucket == "month" else cur + step  # type: ignore[operator]
    return out


class StatsRepository:
    """Read-only aggregations over resource_issues for one publisher."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    def _scope(
        self,
        publisher_id: int,
        bot_id: int | None,
        resource_id: int | None,
    ) -> list[ColumnElement[bool]]:
        conds: list[ColumnElement[bool]] = [ResourceIssue.publisher_id == publisher_id]
        if bot_id is not None:
            conds.append(ResourceIssue.publisher_bot_id == bot_id)
        if resource_id is not None:
            conds.append(ResourceIssue.campaign_resource_id == resource_id)
        return conds

    def _audience_cond(
        self, audience: tuple[str, str] | None
    ) -> ColumnElement[bool] | None:
        """Predicate restricting issues to users in one demographic segment.

        Returns None when no real filter applies (so callers skip the EndUser
        join). Requires joining EndUser on ResourceIssue.user_tg_id when not None.
        """
        if audience is None:
            return None
        dim, key = audience
        if not key or key == "__rest__":
            return None
        if dim == "nationality":
            col = func.coalesce(EndUser.geo_country, EndUser.country_code)
            return col.is_(None) if key == "unknown" else col == key
        if dim == "age":
            return EndUser.age_range.is_(None) if key == "unknown" else EndUser.age_range == key
        if dim == "premium":
            if key == "premium":
                return EndUser.has_telegram_premium.is_(True)
            if key == "regular":
                return EndUser.has_telegram_premium.is_(False)
            return EndUser.has_telegram_premium.is_(None)
        return None

    async def advertiser_traffic_bought(self, *, advertiser_id: int) -> int:
        """Total traffic delivered across this advertiser's campaigns.

        Sums campaign_resources.actual_subscribers (incremented on each verified
        subscription / confirmed bot-start) over all of the advertiser's campaigns.
        """
        from src.core.db.models import Campaign

        stmt = (
            select(func.coalesce(func.sum(CampaignResource.actual_subscribers), 0))
            .join(Campaign, CampaignResource.campaign_id == Campaign.id)
            .where(Campaign.advertiser_id == advertiser_id)
        )
        result = await self.session.execute(stmt)
        return int(result.scalar() or 0)

    async def summary(
        self,
        *,
        publisher_id: int,
        since: datetime,
        until: datetime,
        bot_id: int | None = None,
        resource_id: int | None = None,
        audience: tuple[str, str] | None = None,
    ) -> SummaryStats:
        prev_since = since - (until - since)
        scope = self._scope(publisher_id, bot_id, resource_id)
        aud = self._audience_cond(audience)

        def earned_between(lo: datetime, hi: datetime) -> ColumnElement[Decimal]:
            return func.coalesce(
                func.sum(
                    case(
                        (
                            and_(
                                ResourceIssue.status.in_(_EARNED_STATUSES),
                                ResourceIssue.verified_at >= lo,
                                ResourceIssue.verified_at <= hi,
                            ),
                            _earned_expr(),
                        ),
                        else_=0,
                    )
                ),
                0,
            )

        def count_between(col: Any, lo: datetime, hi: datetime) -> Any:
            return func.count(case((and_(col >= lo, col <= hi), ResourceIssue.link_id)))

        stmt = select(
            earned_between(since, until).label("earned_cur"),
            earned_between(prev_since, since).label("earned_prev"),
            count_between(ResourceIssue.subscribed_at, since, until).label("subs_cur"),
            count_between(ResourceIssue.subscribed_at, prev_since, since).label("subs_prev"),
            count_between(ResourceIssue.unsubscribed_at, since, until).label("unsubs_cur"),
            count_between(ResourceIssue.unsubscribed_at, prev_since, since).label("unsubs_prev"),
            count_between(ResourceIssue.issued_at, since, until).label("issued_cur"),
        )
        if aud is not None:
            stmt = stmt.join(EndUser, EndUser.user_tg_id == ResourceIssue.user_tg_id).where(
                and_(*scope, aud)
            )
        else:
            stmt = stmt.where(and_(*scope))
        row = (await self.session.execute(stmt)).one()

        earned_cur = Decimal(str(row.earned_cur))
        subs_cur, unsubs_cur = int(row.subs_cur), int(row.unsubs_cur)
        return SummaryStats(
            period_from=since,
            period_to=until,
            earned_rub=earned_cur,
            earned_growth_pct=_growth(earned_cur, Decimal(str(row.earned_prev))),
            subs=subs_cur,
            subs_growth_pct=_growth(Decimal(subs_cur), Decimal(int(row.subs_prev))),
            unsubs=unsubs_cur,
            unsubs_growth_pct=_growth(Decimal(unsubs_cur), Decimal(int(row.unsubs_prev))),
            issued=int(row.issued_cur),
            retention_pct=_retention(subs_cur, unsubs_cur),
            churn_ratio=_churn(subs_cur, unsubs_cur),
        )

    async def timeseries(
        self,
        *,
        publisher_id: int,
        since: datetime,
        until: datetime,
        bucket: str = "day",
        bot_id: int | None = None,
        resource_id: int | None = None,
        audience: tuple[str, str] | None = None,
    ) -> list[TimeseriesPoint]:
        if bucket not in _VALID_BUCKETS:
            bucket = "day"
        scope = self._scope(publisher_id, bot_id, resource_id)
        aud = self._audience_cond(audience)

        async def grouped(ts_col: Any, value: Any, *extra: Any) -> dict[datetime, Any]:
            # Truncate in UTC explicitly so buckets align with _bucket_starts()
            # regardless of the DB session's TimeZone setting.
            b = func.date_trunc(bucket, ts_col, "UTC").label("b")
            stmt = select(b, value)
            if aud is not None:
                stmt = stmt.join(EndUser, EndUser.user_tg_id == ResourceIssue.user_tg_id).where(
                    and_(*scope, ts_col >= since, ts_col <= until, aud, *extra)
                )
            else:
                stmt = stmt.where(and_(*scope, ts_col >= since, ts_col <= until, *extra))
            rows = await self.session.execute(stmt.group_by(b))
            return {r[0]: r[1] for r in rows.all()}

        earned_by = await grouped(
            ResourceIssue.verified_at,
            func.coalesce(func.sum(_earned_expr()), 0),
            ResourceIssue.status.in_(_EARNED_STATUSES),
        )
        subs_by = await grouped(ResourceIssue.subscribed_at, func.count(ResourceIssue.link_id))
        unsubs_by = await grouped(ResourceIssue.unsubscribed_at, func.count(ResourceIssue.link_id))
        issued_by = await grouped(ResourceIssue.issued_at, func.count(ResourceIssue.link_id))

        points: list[TimeseriesPoint] = []
        for b in _bucket_starts(since, until, bucket):
            points.append(
                TimeseriesPoint(
                    bucket=b,
                    earned_rub=Decimal(str(earned_by.get(b, 0))),
                    subs=int(subs_by.get(b, 0) or 0),
                    unsubs=int(unsubs_by.get(b, 0) or 0),
                    issued=int(issued_by.get(b, 0) or 0),
                )
            )
        return points

    async def by_resource(
        self,
        *,
        publisher_id: int,
        since: datetime,
        until: datetime,
        bot_id: int | None = None,
        limit: int = 50,
        audience: tuple[str, str] | None = None,
    ) -> list[ResourceStat]:
        scope = self._scope(publisher_id, bot_id, None)
        aud = self._audience_cond(audience)

        subs = func.count(
            case((and_(ResourceIssue.subscribed_at >= since, ResourceIssue.subscribed_at <= until), ResourceIssue.link_id))
        )
        unsubs = func.count(
            case((and_(ResourceIssue.unsubscribed_at >= since, ResourceIssue.unsubscribed_at <= until), ResourceIssue.link_id))
        )
        earned = func.coalesce(
            func.sum(
                case(
                    (
                        and_(
                            ResourceIssue.status.in_(_EARNED_STATUSES),
                            ResourceIssue.verified_at >= since,
                            ResourceIssue.verified_at <= until,
                        ),
                        _earned_expr(),
                    ),
                    else_=0,
                )
            ),
            0,
        )

        stmt = select(
            CampaignResource.id,
            CampaignResource.title,
            CampaignResource.username,
            CampaignResource.type,
            subs.label("subs"),
            unsubs.label("unsubs"),
            earned.label("earned"),
        ).join(CampaignResource, CampaignResource.id == ResourceIssue.campaign_resource_id)
        conds = list(scope)
        if aud is not None:
            stmt = stmt.join(EndUser, EndUser.user_tg_id == ResourceIssue.user_tg_id)
            conds.append(aud)
        rows = await self.session.execute(
            stmt.where(and_(*conds))
            .group_by(CampaignResource.id, CampaignResource.title, CampaignResource.username, CampaignResource.type)
            .order_by(earned.desc(), subs.desc())
            .limit(limit)
        )

        out: list[ResourceStat] = []
        for r in rows.all():
            s, u = int(r.subs), int(r.unsubs)
            if s == 0 and Decimal(str(r.earned)) == 0 and u == 0:
                continue
            out.append(
                ResourceStat(
                    resource_id=r.id,
                    title=r.title,
                    username=r.username,
                    type=r.type.value if hasattr(r.type, "value") else str(r.type),
                    subs=s,
                    unsubs=u,
                    earned_rub=Decimal(str(r.earned)),
                    retention_pct=_retention(s, u),
                )
            )
        return out

    async def by_bot(
        self,
        *,
        publisher_id: int,
        since: datetime,
        until: datetime,
    ) -> list[BotStat]:
        subs = func.count(
            case((and_(ResourceIssue.subscribed_at >= since, ResourceIssue.subscribed_at <= until), ResourceIssue.link_id))
        )
        unsubs = func.count(
            case((and_(ResourceIssue.unsubscribed_at >= since, ResourceIssue.unsubscribed_at <= until), ResourceIssue.link_id))
        )
        earned = func.coalesce(
            func.sum(
                case(
                    (
                        and_(
                            ResourceIssue.status.in_(_EARNED_STATUSES),
                            ResourceIssue.verified_at >= since,
                            ResourceIssue.verified_at <= until,
                        ),
                        _earned_expr(),
                    ),
                    else_=0,
                )
            ),
            0,
        )
        rows = await self.session.execute(
            select(
                PublisherBot.id,
                PublisherBot.name,
                PublisherBot.tg_bot_username,
                subs.label("subs"),
                unsubs.label("unsubs"),
                earned.label("earned"),
            )
            .join(PublisherBot, PublisherBot.id == ResourceIssue.publisher_bot_id)
            .where(ResourceIssue.publisher_id == publisher_id)
            .group_by(PublisherBot.id, PublisherBot.name, PublisherBot.tg_bot_username)
            .order_by(earned.desc())
        )
        return [
            BotStat(
                bot_id=r.id,
                name=r.name,
                username=r.tg_bot_username,
                subs=int(r.subs),
                earned_rub=Decimal(str(r.earned)),
                retention_pct=_retention(int(r.subs), int(r.unsubs)),
            )
            for r in rows.all()
        ]

    async def list_bots(self, *, publisher_id: int) -> list[BotRef]:
        """All bots of a publisher (for the dashboard picker)."""
        rows = await self.session.execute(
            select(PublisherBot.id, PublisherBot.name, PublisherBot.tg_bot_username, PublisherBot.is_active)
            .where(PublisherBot.publisher_id == publisher_id)
            .order_by(PublisherBot.id)
        )
        return [BotRef(bot_id=r.id, name=r.name, username=r.tg_bot_username, is_active=bool(r.is_active)) for r in rows.all()]

    async def by_demographic(
        self,
        *,
        publisher_id: int,
        dimension: str,
        bot_id: int | None = None,
        limit: int = 12,
    ) -> list[DemographicSlice]:
        """Audience composition over one dimension (nationality / age / premium).

        Counts end users who onboarded through this publisher's bots (optionally a
        single bot). All-time snapshot — это «портрет аудитории», не временной ряд.
        The tail beyond `limit` slices is folded into one «Другие» slice so the
        total (and therefore every percentage) is preserved.
        """
        if dimension not in DEMOGRAPHIC_DIMENSIONS:
            dimension = "nationality"

        if dimension == "nationality":
            key_col: Any = func.coalesce(EndUser.geo_country, EndUser.country_code)
        elif dimension == "age":
            key_col = EndUser.age_range
        else:  # premium
            key_col = EndUser.has_telegram_premium

        conds: list[ColumnElement[bool]] = [PublisherBot.publisher_id == publisher_id]
        if bot_id is not None:
            conds.append(PublisherBot.id == bot_id)

        rows = await self.session.execute(
            select(key_col.label("k"), func.count(EndUser.id).label("c"))
            .join(PublisherBot, PublisherBot.id == EndUser.onboarded_via_bot_id)
            .where(and_(*conds))
            .group_by(key_col)
        )

        merged: dict[str, list[Any]] = {}  # key -> [label, count]
        for r in rows.all():
            key, label = _demographic_entry(dimension, r.k)
            if key in merged:
                merged[key][1] += int(r.c)
            else:
                merged[key] = [label, int(r.c)]

        ordered = sorted(merged.items(), key=lambda kv: kv[1][1], reverse=True)
        out: list[DemographicSlice] = [
            DemographicSlice(key=k, label=v[0], count=v[1]) for k, v in ordered[:limit]
        ]
        tail = ordered[limit:]
        if tail:
            out.append(
                DemographicSlice(
                    key="__rest__",
                    label="Другие",
                    count=sum(v[1] for _, v in tail),
                )
            )
        return out

    async def bot_belongs_to_publisher(self, *, publisher_id: int, bot_id: int) -> bool:
        row = await self.session.execute(
            select(PublisherBot.id).where(
                PublisherBot.id == bot_id, PublisherBot.publisher_id == publisher_id
            )
        )
        return row.scalar_one_or_none() is not None


# ============================ Advertiser side ============================
#
# Same issue-level data, viewed from the advertiser who paid for it: spend is
# the gross reward_rub of each verified/paid subscription, bucketed by
# verified_at, across the advertiser's campaigns.


@dataclass(slots=True)
class AdvSummary:
    spent_rub: Decimal
    bought: int
    active_campaigns: int


@dataclass(slots=True)
class AdvTsPoint:
    bucket: datetime
    spent_rub: Decimal
    bought: int


@dataclass(slots=True)
class AdvResourceRow:
    resource_id: int
    title: str
    username: str | None
    type: str
    bought: int
    spent_rub: Decimal


class AdvertiserStatsRepository:
    """Read-only aggregations over the advertiser's campaigns (what they bought)."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    def _spent_in(self, lo: datetime, hi: datetime) -> Any:
        return func.coalesce(
            func.sum(
                case(
                    (
                        and_(
                            ResourceIssue.status.in_(_EARNED_STATUSES),
                            ResourceIssue.verified_at >= lo,
                            ResourceIssue.verified_at <= hi,
                        ),
                        ResourceIssue.reward_rub,
                    ),
                    else_=0,
                )
            ),
            0,
        )

    def _bought_in(self, lo: datetime, hi: datetime) -> Any:
        return func.count(
            case(
                (
                    and_(
                        ResourceIssue.status.in_(_EARNED_STATUSES),
                        ResourceIssue.verified_at >= lo,
                        ResourceIssue.verified_at <= hi,
                    ),
                    ResourceIssue.link_id,
                )
            )
        )

    async def summary(
        self, *, advertiser_id: int, since: datetime, until: datetime,
    ) -> AdvSummary:
        stmt = (
            select(
                self._spent_in(since, until).label("spent"),
                self._bought_in(since, until).label("bought"),
            )
            .select_from(ResourceIssue)
            .join(CampaignResource, ResourceIssue.campaign_resource_id == CampaignResource.id)
            .join(Campaign, CampaignResource.campaign_id == Campaign.id)
            .where(Campaign.advertiser_id == advertiser_id)
        )
        row = (await self.session.execute(stmt)).one()

        active = await self.session.execute(
            select(func.count(Campaign.id)).where(
                and_(
                    Campaign.advertiser_id == advertiser_id,
                    Campaign.status == CampaignStatus.ACTIVE,
                )
            )
        )
        return AdvSummary(
            spent_rub=Decimal(str(row.spent)),
            bought=int(row.bought),
            active_campaigns=int(active.scalar() or 0),
        )

    async def spend_timeseries(
        self, *, advertiser_id: int, since: datetime, until: datetime, bucket: str = "day",
    ) -> list[AdvTsPoint]:
        if bucket not in _VALID_BUCKETS:
            bucket = "day"
        b = func.date_trunc(bucket, ResourceIssue.verified_at, "UTC").label("b")
        stmt = (
            select(
                b,
                func.coalesce(func.sum(ResourceIssue.reward_rub), 0),
                func.count(ResourceIssue.link_id),
            )
            .join(CampaignResource, ResourceIssue.campaign_resource_id == CampaignResource.id)
            .join(Campaign, CampaignResource.campaign_id == Campaign.id)
            .where(
                and_(
                    Campaign.advertiser_id == advertiser_id,
                    ResourceIssue.status.in_(_EARNED_STATUSES),
                    ResourceIssue.verified_at >= since,
                    ResourceIssue.verified_at <= until,
                )
            )
            .group_by(b)
        )
        rows = {r[0]: (r[1], r[2]) for r in (await self.session.execute(stmt)).all()}
        points: list[AdvTsPoint] = []
        for bs in _bucket_starts(since, until, bucket):
            spent, cnt = rows.get(bs, (0, 0))
            points.append(AdvTsPoint(bucket=bs, spent_rub=Decimal(str(spent)), bought=int(cnt)))
        return points

    async def by_resource(
        self, *, advertiser_id: int, since: datetime, until: datetime, limit: int = 40,
    ) -> list[AdvResourceRow]:
        stmt = (
            select(
                CampaignResource.id,
                CampaignResource.title,
                CampaignResource.username,
                CampaignResource.type,
                self._bought_in(since, until).label("bought"),
                self._spent_in(since, until).label("spent"),
            )
            .select_from(CampaignResource)
            .join(Campaign, CampaignResource.campaign_id == Campaign.id)
            .outerjoin(ResourceIssue, ResourceIssue.campaign_resource_id == CampaignResource.id)
            .where(Campaign.advertiser_id == advertiser_id)
            .group_by(
                CampaignResource.id,
                CampaignResource.title,
                CampaignResource.username,
                CampaignResource.type,
            )
            .order_by(self._spent_in(since, until).desc())
            .limit(limit)
        )
        out: list[AdvResourceRow] = []
        for rid, title, username, rtype, bought, spent in (await self.session.execute(stmt)).all():
            out.append(AdvResourceRow(
                resource_id=rid,
                title=title or "—",
                username=username,
                type=rtype.value if hasattr(rtype, "value") else str(rtype),
                bought=int(bought),
                spent_rub=Decimal(str(spent)),
            ))
        return out
