"""Boost verification.

Channel/group boosts are verified by polling `getUserChatBoosts` — unlike
subscriptions, a boost produces no `chat_member` event, so there is nothing to
react to. The same service backs two callers:

  * the periodic worker (`poll_boost_issues`) — the source of truth: it both
    detects new boosts (PENDING → SUBSCRIBED) and catches removed boosts during
    the hold (SUBSCRIBED → UNSUBSCRIBED, which the revert worker refunds);
  * the publisher API (`/check-resource`, `/check-task`) — an opportunistic
    live check for PENDING boost issues so the partner sees confirmation
    immediately instead of waiting for the next worker tick.

Money safety: a state change only ever happens on a definitive answer from
Telegram. When the boost status is unknown (checker bot missing from the pool,
Telegram error) the issue is left untouched.
"""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.db.models import CampaignResource, CheckerBot, ResourceIssue
from src.core.db.models.enums import IssueStatus, TaskType
from src.core.logging import get_logger
from src.domain.issues.repository import ResourceIssueRepository
from src.domain.issues.state_machine import IssueStateMachine
from src.domain.publishers import PublisherRepository
from src.integrations.telegram import get_checker_pool

log = get_logger("issues.boost_verify")


class BoostVerificationService:
    """Polls boost state and applies it to ResourceIssues. Caller commits."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.machine = IssueStateMachine(session)

    async def _checker_tg_id(self, checker_bot_id: int | None) -> int | None:
        if checker_bot_id is None:
            return None
        row = await self.session.execute(
            select(CheckerBot.tg_bot_id).where(CheckerBot.id == checker_bot_id)
        )
        return row.scalar_one_or_none()

    async def _apply(
        self,
        issue: ResourceIssue,
        *,
        is_boosting: bool,
    ) -> str | None:
        """Apply one boost observation. Returns the resulting status, or None."""
        if issue.status == IssueStatus.PENDING:
            if not is_boosting:
                return None
            pub_repo = PublisherRepository(self.session)
            publisher = await pub_repo.get_by_id(issue.publisher_id)
            if publisher is None:
                log.error("boost_publisher_missing", publisher_id=issue.publisher_id)
                return None
            await self.machine.mark_subscribed(issue, publisher)
            return issue.status.value
        if issue.status == IssueStatus.SUBSCRIBED:
            if is_boosting:
                return None
            await self.machine.mark_unsubscribed(issue)
            return issue.status.value
        return None

    async def check_issue(
        self,
        issue: ResourceIssue,
        resource: CampaignResource | None,
    ) -> str | None:
        """Live boost detection for a PENDING boost issue (API hot path).

        Only handles PENDING → SUBSCRIBED (the latency-sensitive direction);
        boost removal during hold is left to the periodic worker so we don't
        hit getUserChatBoosts on every publisher poll. Cheap-exits for anything
        that isn't an actionable boost issue.
        """
        if (
            resource is None
            or resource.task_type != TaskType.BOOST
            or resource.tg_chat_id is None
            or issue.status != IssueStatus.PENDING
        ):
            return None

        tg_id = await self._checker_tg_id(resource.checker_bot_id)
        if tg_id is None:
            return None

        pool = get_checker_pool()
        is_boosting = await pool.user_is_boosting(
            checker_bot_tg_id=tg_id,
            chat_id=resource.tg_chat_id,
            user_id=issue.user_tg_id,
        )
        if is_boosting is None:
            return None
        return await self._apply(issue, is_boosting=is_boosting)

    async def poll_batch(self, *, limit: int = 100) -> dict:
        """Worker entrypoint: poll all pending/hold boost issues in one batch."""
        repo = ResourceIssueRepository(self.session)
        rows = await repo.list_boost_issues_to_poll(limit=limit)
        if not rows:
            return {"checked": 0, "subscribed": 0, "unsubscribed": 0, "unknown": 0}

        # Resolve each resource's checker bot Telegram id (batched).
        checker_ids = {r.checker_bot_id for _, r in rows if r.checker_bot_id is not None}
        checker_tg_by_id: dict[int, int] = {}
        if checker_ids:
            cb_rows = await self.session.execute(
                select(CheckerBot.id, CheckerBot.tg_bot_id).where(
                    CheckerBot.id.in_(checker_ids)
                )
            )
            checker_tg_by_id = {cid: tg for cid, tg in cb_rows.all()}

        pool = get_checker_pool()
        subscribed = unsubscribed = unknown = 0
        for issue, resource in rows:
            tg_id = checker_tg_by_id.get(resource.checker_bot_id) if resource.checker_bot_id else None
            if tg_id is None or resource.tg_chat_id is None:
                unknown += 1
                continue
            is_boosting = await pool.user_is_boosting(
                checker_bot_tg_id=tg_id,
                chat_id=resource.tg_chat_id,
                user_id=issue.user_tg_id,
            )
            if is_boosting is None:
                unknown += 1
                continue
            result = await self._apply(issue, is_boosting=is_boosting)
            if result == IssueStatus.SUBSCRIBED.value:
                subscribed += 1
            elif result == IssueStatus.UNSUBSCRIBED.value:
                unsubscribed += 1

        return {
            "checked": len(rows),
            "subscribed": subscribed,
            "unsubscribed": unsubscribed,
            "unknown": unknown,
        }
