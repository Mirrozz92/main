"""Repository for TonTopup — direct USDT (TON) top-up intents."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.db.models import TonTopup
from src.core.db.models.enums import TonTopupStatus


class TonTopupRepository:
    """Pure data-access for ton_topups."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def create(
        self,
        *,
        advertiser_id: int,
        amount_rub: Decimal,
        expected_usdt: Decimal,
        memo: str,
        expires_at: datetime,
    ) -> TonTopup:
        topup = TonTopup(
            advertiser_id=advertiser_id,
            amount_rub=amount_rub,
            expected_usdt=expected_usdt,
            memo=memo,
            status=TonTopupStatus.PENDING,
            expires_at=expires_at,
        )
        self.session.add(topup)
        await self.session.flush()
        return topup

    async def get_by_id(self, topup_id: int) -> TonTopup | None:
        result = await self.session.execute(
            select(TonTopup).where(TonTopup.id == topup_id)
        )
        return result.scalar_one_or_none()

    async def get_by_memo(self, memo: str) -> TonTopup | None:
        result = await self.session.execute(
            select(TonTopup).where(TonTopup.memo == memo)
        )
        return result.scalar_one_or_none()

    async def get_by_tx_hash(self, tx_hash: str) -> TonTopup | None:
        result = await self.session.execute(
            select(TonTopup).where(TonTopup.tx_hash == tx_hash)
        )
        return result.scalar_one_or_none()

    async def list_pending_active(self, *, now: datetime, limit: int = 200) -> list[TonTopup]:
        """Pending top-ups whose deadline has not passed yet (oldest first)."""
        result = await self.session.execute(
            select(TonTopup)
            .where(
                TonTopup.status == TonTopupStatus.PENDING,
                TonTopup.expires_at > now,
            )
            .order_by(TonTopup.created_at)
            .limit(limit)
        )
        return list(result.scalars().all())

    async def list_expired_pending(self, *, now: datetime, limit: int = 500) -> list[TonTopup]:
        result = await self.session.execute(
            select(TonTopup)
            .where(
                TonTopup.status == TonTopupStatus.PENDING,
                TonTopup.expires_at <= now,
            )
            .limit(limit)
        )
        return list(result.scalars().all())
