"""Payments service: create CryptoBot invoices and handle paid notifications.

Strategy (chosen for simplicity & UX):
- Invoice is created in RUB (fiat mode), with accepted_assets="USDT,TON".
- CryptoBot shows the user the equivalent in their chosen crypto, at the
  current CryptoBot rate. We never store crypto amounts in balances.
- On invoice_paid webhook → we credit the fiat amount in RUB to advertiser.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from decimal import ROUND_UP, Decimal
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from src.core.config import get_settings
from src.core.db.models import Advertiser, TonTopup, Transaction
from src.core.db.models.enums import TonTopupStatus, TransactionStatus, TransactionType
from src.core.logging import get_logger
from src.domain.advertisers import AdvertiserRepository
from src.domain.exceptions import CryptoBotError, DomainError
from src.domain.payments.ton_repository import TonTopupRepository
from src.domain.transactions import TransactionService
from src.integrations.cryptobot import CryptoBotClient, Invoice
from src.integrations.cryptobot.schemas import CreateInvoiceRequest, WebhookUpdate
from src.integrations.ton import JettonTransfer
from src.shared.idgen import generate_id, generate_memo
from src.shared.money import to_money

log = get_logger("payments")


class PaymentsService:
    """Business ops for top-ups and (later) payouts."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.adv_repo = AdvertiserRepository(session)
        self.tx_service = TransactionService(session)
        self.tx_repo = self.tx_service.repo

    # ---------- Top-up creation ----------

    async def create_topup_invoice(
        self,
        *,
        advertiser: Advertiser,
        amount_rub: Decimal,
        bot_username: str | None = None,
    ) -> tuple[Invoice, Transaction]:
        """Create a RUB invoice in CryptoBot (paid by USDT or TON).

        Also creates a PENDING transaction in our ledger so we can correlate the
        webhook callback. The transaction will be marked COMPLETED in
        handle_invoice_paid().

        Args:
            advertiser: who's topping up
            amount_rub: how much to credit (in RUB)
            bot_username: the bot's username (for paid_btn_url back to the bot)

        Returns:
            (invoice, pending_transaction)
        """
        settings = get_settings()

        if amount_rub < settings.min_campaign_topup_rub:
            raise DomainError(
                f"Минимальная сумма пополнения: {settings.min_campaign_topup_rub:.0f} ₽"
            )

        amount = to_money(amount_rub)

        # Internal payload: link this invoice back to advertiser & idempotency key
        idem_key = generate_id("idm")
        payload = json.dumps({
            "advertiser_id": advertiser.id,
            "idempotency_key": idem_key,
            "tg_user_id": advertiser.tg_user_id,
        })

        req = CreateInvoiceRequest(
            amount=str(amount),
            currency_type="fiat",
            fiat="RUB",
            accepted_assets="USDT,TON",
            description=f"Пополнение FastSub на {amount:.2f} ₽",
            payload=payload,
            allow_anonymous=False,
            allow_comments=False,
            expires_in=3 * 60 * 60,  # 3 hours
        )

        if bot_username:
            req.paid_btn_name = "openBot"
            req.paid_btn_url = f"https://t.me/{bot_username.lstrip('@')}"

        # Call CryptoBot
        try:
            async with CryptoBotClient() as cb:
                invoice = await cb.create_invoice(req)
        except CryptoBotError:
            raise
        except Exception as e:
            log.error("topup_invoice_create_failed", error=str(e))
            raise CryptoBotError("Не удалось создать счёт. Попробуйте позже.") from e

        # Pre-create a PENDING transaction so /balance shows "ожидает оплаты"
        # external_id = invoice_id (str), idempotency_key — наш сгенерированный
        tx = await self.tx_repo.create(
            type=TransactionType.ADVERTISER_TOPUP,
            amount_rub=amount,
            advertiser_id=advertiser.id,
            external_id=str(invoice.invoice_id),
            description=f"Ожидает оплаты счёта #{invoice.invoice_id}",
            meta={
                "invoice_hash": invoice.hash,
                "currency_type": invoice.currency_type,
                "fiat": invoice.fiat,
                "accepted_assets": "USDT,TON",
                "bot_invoice_url": invoice.bot_invoice_url,
            },
            idempotency_key=idem_key,
            status=TransactionStatus.PENDING,
        )
        log.info(
            "topup_invoice_created",
            advertiser_id=advertiser.id,
            amount=str(amount),
            invoice_id=invoice.invoice_id,
            tx_id=tx.id,
        )
        return invoice, tx

    # ---------- Webhook: invoice_paid ----------

    async def handle_invoice_paid(self, update: WebhookUpdate) -> dict[str, Any]:
        """Handle invoice_paid webhook from CryptoBot.

        Steps:
        1. Find the pending Transaction by external_id (invoice_id).
        2. Validate amount/advertiser from invoice.payload.
        3. Credit the balance and mark transaction COMPLETED.
        4. Return info dict to be used for notification.

        Returns a dict with `advertiser_tg_id` and `amount_rub` for notify caller.
        Returns empty dict if already processed.
        """
        invoice = update.payload

        if invoice.status != "paid":
            log.warning("webhook_invoice_not_paid", invoice_id=invoice.invoice_id, status=invoice.status)
            return {}

        # Parse our payload (which we set during createInvoice)
        meta_payload: dict[str, Any] = {}
        if invoice.payload:
            try:
                meta_payload = json.loads(invoice.payload)
            except Exception as e:
                log.error(
                    "webhook_invalid_payload",
                    invoice_id=invoice.invoice_id,
                    payload=invoice.payload[:200] if invoice.payload else None,
                    error=str(e),
                )
                return {}

        advertiser_id = meta_payload.get("advertiser_id")
        idempotency_key = meta_payload.get("idempotency_key")
        tg_user_id = meta_payload.get("tg_user_id")

        if not advertiser_id or not idempotency_key:
            log.error(
                "webhook_missing_advertiser_or_key",
                invoice_id=invoice.invoice_id,
                payload_keys=list(meta_payload.keys()),
            )
            return {}

        advertiser = await self.adv_repo.get_by_id(int(advertiser_id))
        if advertiser is None:
            log.error("webhook_advertiser_not_found", invoice_id=invoice.invoice_id, advertiser_id=advertiser_id)
            return {}

        # Find the pending tx and update it. We don't use credit_advertiser_topup's
        # idempotency check directly because we want to update the EXISTING row.
        existing_tx = await self.tx_repo.get_by_idempotency_key(idempotency_key)

        # Amount in RUB — берём из invoice.amount (т.к. инвойс был выставлен в RUB)
        # Если по каким-то причинам currency_type не "fiat" — это аномалия, логируем
        if invoice.currency_type != "fiat":
            log.warning(
                "webhook_non_fiat_invoice",
                invoice_id=invoice.invoice_id,
                currency_type=invoice.currency_type,
            )
        amount_rub = to_money(invoice.amount)

        if existing_tx is None:
            # Не нашли pending — создаём как новую (на случай если webhook пришёл раньше нашей записи)
            log.warning(
                "webhook_no_pending_tx_creating_new",
                invoice_id=invoice.invoice_id,
                idempotency_key=idempotency_key,
            )
            advertiser.balance_rub = advertiser.balance_rub + amount_rub
            await self.tx_repo.create(
                type=TransactionType.ADVERTISER_TOPUP,
                amount_rub=amount_rub,
                advertiser_id=advertiser.id,
                external_id=str(invoice.invoice_id),
                description=f"Пополнение через CryptoBot, счёт #{invoice.invoice_id}",
                meta={
                    "invoice_hash": invoice.hash,
                    "paid_asset": invoice.paid_asset,
                    "paid_amount": invoice.paid_amount,
                    "paid_fiat_rate": invoice.paid_fiat_rate,
                },
                idempotency_key=idempotency_key,
                status=TransactionStatus.COMPLETED,
            )
        elif existing_tx.status == TransactionStatus.COMPLETED:
            log.info(
                "webhook_duplicate_paid",
                invoice_id=invoice.invoice_id,
                tx_id=existing_tx.id,
            )
            return {}  # idempotent: ничего не делаем
        else:
            # PENDING → COMPLETED. Credit balance.
            advertiser.balance_rub = advertiser.balance_rub + amount_rub
            existing_tx.status = TransactionStatus.COMPLETED
            existing_tx.description = f"Пополнение через CryptoBot, счёт #{invoice.invoice_id}"
            existing_tx.meta = {
                **(existing_tx.meta or {}),
                "paid_asset": invoice.paid_asset,
                "paid_amount": invoice.paid_amount,
                "paid_fiat_rate": invoice.paid_fiat_rate,
            }

        log.info(
            "topup_completed",
            advertiser_id=advertiser.id,
            amount=str(amount_rub),
            invoice_id=invoice.invoice_id,
            paid_asset=invoice.paid_asset,
            paid_amount=invoice.paid_amount,
        )

        return {
            "advertiser_tg_id": int(tg_user_id) if tg_user_id else advertiser.tg_user_id,
            "amount_rub": amount_rub,
            "invoice_id": invoice.invoice_id,
            "paid_asset": invoice.paid_asset or "",
            "paid_amount": invoice.paid_amount or "",
        }

    # ---------- Direct USDT (TON) top-up ----------

    async def create_ton_topup(
        self,
        *,
        advertiser: Advertiser,
        amount_rub: Decimal,
    ) -> TonTopup:
        """Create a pending direct-USDT top-up: locks in the RUB amount + memo.

        The advertiser then sends the shown USDT amount to our TON wallet with
        the memo as the transfer comment; the poller credits the RUB amount.
        """
        settings = get_settings()
        amount = to_money(amount_rub)
        if amount < settings.min_campaign_topup_rub:
            raise DomainError(
                f"Минимальная сумма пополнения: {settings.min_campaign_topup_rub:.0f} ₽"
            )

        # Курс берём у CryptoBot (1 USDT = rate ₽); сам платёж идёт мимо CryptoBot
        rate: Decimal | None = None
        try:
            async with CryptoBotClient() as cb:
                rate = await cb.get_rate("USDT", "RUB")
        except Exception as e:
            log.warning("ton_rate_fetch_failed", error=str(e))
        if rate is None or rate <= 0:
            raise CryptoBotError("Не удалось получить курс USDT. Попробуйте позже.")

        # Округляем USDT вверх, чтобы не запросить меньше рублёвого эквивалента
        expected_usdt = (amount / rate).quantize(Decimal("0.000001"), rounding=ROUND_UP)

        ton_repo = TonTopupRepository(self.session)
        memo = generate_memo()
        for _ in range(5):
            if await ton_repo.get_by_memo(memo) is None:
                break
            memo = generate_memo()

        expires_at = datetime.now(UTC) + timedelta(minutes=settings.ton_topup_expires_minutes)
        topup = await ton_repo.create(
            advertiser_id=advertiser.id,
            amount_rub=amount,
            expected_usdt=expected_usdt,
            memo=memo,
            expires_at=expires_at,
        )
        log.info(
            "ton_topup_created",
            advertiser_id=advertiser.id,
            amount=str(amount),
            expected_usdt=str(expected_usdt),
            memo=memo,
            topup_id=topup.id,
        )
        return topup

    def _ton_match(self, topup: TonTopup, transfer: JettonTransfer) -> bool:
        """True if an on-chain transfer satisfies a pending top-up (memo + amount)."""
        if not transfer.comment or transfer.comment.strip() != topup.memo:
            return False
        tol = get_settings().ton_amount_tolerance_percent / Decimal("100")
        min_usdt = topup.expected_usdt * (Decimal("1") - tol)
        return transfer.amount >= min_usdt

    async def try_credit_ton_topup(self, topup: TonTopup, transfer: JettonTransfer) -> bool:
        """Credit a matched transfer to the advertiser. Idempotent.

        Returns True only if it credited the balance on this call.
        """
        if topup.status != TonTopupStatus.PENDING:
            return False
        if not self._ton_match(topup, transfer):
            return False

        ton_repo = TonTopupRepository(self.session)
        # Transfer already consumed (e.g. by an earlier tick)?
        if transfer.event_id and await ton_repo.get_by_tx_hash(transfer.event_id) is not None:
            return False

        advertiser = await self.adv_repo.get_by_id(topup.advertiser_id)
        if advertiser is None:
            log.error(
                "ton_topup_advertiser_missing",
                topup_id=topup.id,
                advertiser_id=topup.advertiser_id,
            )
            return False

        tx = await self.tx_repo.create(
            type=TransactionType.ADVERTISER_TOPUP,
            amount_rub=topup.amount_rub,
            advertiser_id=advertiser.id,
            external_id=topup.memo,
            description=f"Пополнение через USDT (TON), memo {topup.memo}",
            meta={
                "method": "ton_usdt",
                "tx_hash": transfer.event_id,
                "paid_usdt": str(transfer.amount),
                "sender": transfer.sender,
            },
            idempotency_key=f"ton_{topup.memo}",
            status=TransactionStatus.COMPLETED,
        )
        advertiser.balance_rub = advertiser.balance_rub + topup.amount_rub
        topup.status = TonTopupStatus.PAID
        topup.tx_hash = transfer.event_id or None
        topup.paid_usdt = transfer.amount
        topup.transaction_id = tx.id
        log.info(
            "ton_topup_credited",
            topup_id=topup.id,
            advertiser_id=advertiser.id,
            amount_rub=str(topup.amount_rub),
            paid_usdt=str(transfer.amount),
            tx_hash=transfer.event_id,
        )
        return True

    async def match_ton_transfers(
        self,
        topups: list[TonTopup],
        transfers: list[JettonTransfer],
    ) -> list[TonTopup]:
        """Match transfers to pending top-ups by memo and credit each.

        Returns the list of top-ups credited on this call.
        """
        by_memo: dict[str, JettonTransfer] = {}
        for t in transfers:
            if t.comment:
                by_memo.setdefault(t.comment.strip(), t)

        credited: list[TonTopup] = []
        for topup in topups:
            transfer = by_memo.get(topup.memo)
            if transfer is not None and await self.try_credit_ton_topup(topup, transfer):
                credited.append(topup)
        return credited

    async def expire_ton_topups(self) -> int:
        """Mark pending top-ups past their deadline as expired. Returns count."""
        ton_repo = TonTopupRepository(self.session)
        stale = await ton_repo.list_expired_pending(now=datetime.now(UTC))
        for topup in stale:
            topup.status = TonTopupStatus.EXPIRED
        if stale:
            log.info("ton_topups_expired", count=len(stale))
        return len(stale)
