"""Repository for AdvertiserApiToken."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.db.models import AdvertiserApiToken


class AdvertiserTokenRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_hash(self, token_hash: str) -> AdvertiserApiToken | None:
        result = await self.session.execute(
            select(AdvertiserApiToken).where(AdvertiserApiToken.token_hash == token_hash)
        )
        return result.scalar_one_or_none()

    async def list_for_advertiser(
        self,
        advertiser_id: int,
        *,
        include_revoked: bool = False,
    ) -> list[AdvertiserApiToken]:
        stmt = select(AdvertiserApiToken).where(
            AdvertiserApiToken.advertiser_id == advertiser_id,
        )
        if not include_revoked:
            stmt = stmt.where(AdvertiserApiToken.is_active.is_(True))
        stmt = stmt.order_by(desc(AdvertiserApiToken.created_at))
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def create(
        self,
        *,
        advertiser_id: int,
        token_prefix: str,
        token_hash: str,
        label: str,
        token_encrypted: bytes | None = None,
    ) -> AdvertiserApiToken:
        token = AdvertiserApiToken(
            advertiser_id=advertiser_id,
            token_prefix=token_prefix,
            token_hash=token_hash,
            token_encrypted=token_encrypted,
            label=label,
            is_active=True,
        )
        self.session.add(token)
        await self.session.flush()
        return token

    async def revoke(self, token: AdvertiserApiToken) -> None:
        token.is_active = False
        token.revoked_at = datetime.now(timezone.utc)

    async def touch(self, token: AdvertiserApiToken) -> None:
        token.last_used_at = datetime.now(timezone.utc)
        token.requests_count = token.requests_count + 1
