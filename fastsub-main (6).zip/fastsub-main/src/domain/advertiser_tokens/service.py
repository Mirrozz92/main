"""Service layer for advertiser API tokens.

Each advertiser has 0..1 ACTIVE token, used by their bot to confirm bot-start
tasks. Regenerating creates a new token and revokes the old one in the same
transaction. Plaintext is Fernet-encrypted at rest so the bot/cabinet can show
and re-copy the key.
"""

from __future__ import annotations

import hashlib
import secrets
from dataclasses import dataclass

from sqlalchemy.ext.asyncio import AsyncSession

from src.core.crypto import CryptoError, decrypt, encrypt
from src.core.db.models import AdvertiserApiToken
from src.core.logging import get_logger
from src.domain.advertiser_tokens.repository import AdvertiserTokenRepository

log = get_logger("advertiser_tokens")


TOKEN_PREFIX_LITERAL = "fsa_live_"
TOKEN_RANDOM_HEX_LEN = 40
DISPLAY_PREFIX_LEN = 12


@dataclass
class TokenCreationResult:
    plaintext: str
    token_record: AdvertiserApiToken


class AdvertiserTokenService:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.repo = AdvertiserTokenRepository(session)

    async def create_for_advertiser(
        self,
        *,
        advertiser_id: int,
        label: str = "Default",
    ) -> TokenCreationResult:
        random_part = secrets.token_hex(TOKEN_RANDOM_HEX_LEN // 2)
        plaintext = f"{TOKEN_PREFIX_LITERAL}{random_part}"
        token_hash = hash_token(plaintext)
        token_prefix = plaintext[:DISPLAY_PREFIX_LEN]
        token_encrypted = encrypt(plaintext)

        record = await self.repo.create(
            advertiser_id=advertiser_id,
            token_prefix=token_prefix,
            token_hash=token_hash,
            token_encrypted=token_encrypted,
            label=label,
        )
        log.info("advertiser_token_created", advertiser_id=advertiser_id, token_id=record.id)
        return TokenCreationResult(plaintext=plaintext, token_record=record)

    async def regenerate_for_advertiser(
        self,
        *,
        advertiser_id: int,
        label: str = "Regenerated",
    ) -> TokenCreationResult:
        active = await self.repo.list_for_advertiser(advertiser_id, include_revoked=False)
        for tok in active:
            await self.repo.revoke(tok)
            log.info("advertiser_token_revoked_during_regen", token_id=tok.id)
        return await self.create_for_advertiser(advertiser_id=advertiser_id, label=label)

    async def get_active_for_advertiser(self, advertiser_id: int) -> AdvertiserApiToken | None:
        tokens = await self.repo.list_for_advertiser(advertiser_id, include_revoked=False)
        return tokens[0] if tokens else None

    async def get_plaintext_for_advertiser(self, advertiser_id: int) -> str | None:
        """Decrypt the active token's plaintext, or None if unrecoverable."""
        tok = await self.get_active_for_advertiser(advertiser_id)
        if tok is None or not tok.token_encrypted:
            return None
        try:
            return decrypt(tok.token_encrypted)
        except CryptoError:
            return None

    async def ensure_plaintext_for_advertiser(self, *, advertiser_id: int) -> str:
        """Return a copy-pasteable key, (re)generating one if none is recoverable."""
        existing = await self.get_plaintext_for_advertiser(advertiser_id)
        if existing is not None:
            return existing
        result = await self.regenerate_for_advertiser(
            advertiser_id=advertiser_id, label="Integration"
        )
        return result.plaintext

    async def verify(self, plaintext: str) -> AdvertiserApiToken | None:
        if not plaintext or not plaintext.startswith(TOKEN_PREFIX_LITERAL):
            return None
        record = await self.repo.get_by_hash(hash_token(plaintext))
        if record is None or not record.is_active:
            return None
        return record


def hash_token(plaintext: str) -> str:
    return hashlib.sha256(plaintext.encode("utf-8")).hexdigest()
