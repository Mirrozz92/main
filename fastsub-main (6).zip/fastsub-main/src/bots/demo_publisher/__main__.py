"""Demo publisher bot — reference integration running on the platform.

Configuration (env):
  DEMO_PUBLISHER_BOT_ID    publisher_bots.id whose Telegram token is used (default 1)
  DEMO_PUBLISHER_API_TOKEN fsp_live_… token authorising the public API calls
  DEMO_PUBLISHER_API_BASE  base URL of the public API (default http://api:8000/api/v1)

The Telegram bot token is read (decrypted) straight from the DB row, so the
only secret that has to live in the environment is the API token.
"""

from __future__ import annotations

import asyncio
import logging
import os

import httpx
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from sqlalchemy import select

from src.core.crypto import decrypt
from src.core.db.models.publisher import PublisherBot
from src.core.db.session import async_session_factory

logger = logging.getLogger("demo_publisher")

API_BASE = os.environ.get("DEMO_PUBLISHER_API_BASE", "http://api:8000/api/v1")
API_TOKEN = os.environ.get("DEMO_PUBLISHER_API_TOKEN", "").strip()
BOT_DB_ID = int(os.environ.get("DEMO_PUBLISHER_BOT_ID", "1"))

HEADERS = {"Authorization": f"Bearer {API_TOKEN}"}


async def _load_bot_token() -> str:
    """Decrypt the Telegram bot token for the configured publisher bot."""
    async with async_session_factory() as session:
        bot_row = (
            await session.execute(
                select(PublisherBot).where(PublisherBot.id == BOT_DB_ID)
            )
        ).scalar_one_or_none()
    if bot_row is None:
        raise RuntimeError(f"publisher_bot {BOT_DB_ID} not found")
    if not bot_row.tg_bot_token_encrypted:
        raise RuntimeError(f"publisher_bot {BOT_DB_ID} has no telegram token")
    return decrypt(bytes(bot_row.tg_bot_token_encrypted))


async def _api_post(path: str, payload: dict) -> dict:
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.post(f"{API_BASE}{path}", headers=HEADERS, json=payload)
    try:
        return resp.json()
    except ValueError:
        return {"ok": False, "http_status": resp.status_code}


def _build_dispatcher() -> Dispatcher:
    dp = Dispatcher()

    @dp.message(CommandStart())
    async def start(message: Message) -> None:
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text="Получить задания", callback_data="get_tasks")]
            ]
        )
        await message.answer("Нажмите, чтобы получить задания:", reply_markup=kb)

    @dp.callback_query(F.data == "get_tasks")
    async def get_tasks(cb: CallbackQuery) -> None:
        data = await _api_post(
            "/request-op", {"user_id": cb.from_user.id, "count": 3}
        )
        if not data.get("ok"):
            reason = data.get("reason")
            if reason == "onboarding_required" and data.get("onboarding_url"):
                await cb.message.answer(
                    "Пройдите регистрацию: " + data["onboarding_url"]
                )
            else:
                await cb.message.answer("Заданий пока нет.")
            await cb.answer()
            return

        for task in data.get("tasks", []):
            link = task.get("invite_link") or task.get("start_link")
            kb = InlineKeyboardMarkup(
                inline_keyboard=[
                    [InlineKeyboardButton(text="Подписаться", url=link)],
                    [
                        InlineKeyboardButton(
                            text="Проверить",
                            callback_data=f"check:{task['link_id']}",
                        )
                    ],
                ]
            )
            await cb.message.answer(
                f"{task['title']} — награда {task['reward_for_publisher']} руб",
                reply_markup=kb,
            )
        await cb.answer()

    @dp.callback_query(F.data.startswith("check:"))
    async def check(cb: CallbackQuery) -> None:
        link_id = cb.data.split(":", 1)[1]
        data = await _api_post("/check-resource", {"link_id": link_id})
        status = data.get("status")
        if status in ("subscribed", "verified"):
            await cb.answer("Подписка подтверждена!", show_alert=True)
        else:
            await cb.answer(
                "Подписка не найдена. Подпишитесь и повторите.", show_alert=True
            )

    return dp


async def main() -> None:
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s"
    )
    if not API_TOKEN:
        raise RuntimeError("DEMO_PUBLISHER_API_TOKEN is not set")

    token = await _load_bot_token()
    bot = Bot(token)
    dp = _build_dispatcher()

    me = await bot.get_me()
    logger.info("demo publisher bot @%s started (api=%s)", me.username, API_BASE)
    try:
        await bot.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(bot)
    finally:
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
