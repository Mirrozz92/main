"""Reference publisher bot the platform runs itself.

Mirrors the integration example shown on the API docs page: a user presses
"Получить задания", the bot calls /request-op, shows sponsors, and after the
user subscribes verifies via /check-resource. Used as a live demo bot.
"""
