"""Keyboards for publisher bot — new bot-centric UX."""

from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo

from src.bots.publisher import texts
from src.core.config import get_settings


def dashboard_url(bot_id: int | None = None) -> str:
    """HTTPS URL of the stats mini-app, optionally preselecting one bot."""
    base = get_settings().public_base_url.rstrip("/")
    url = f"{base}/app/stats"
    if bot_id is not None:
        url += f"?bot_id={bot_id}"
    return url


def integration_app_url(tab: str | None = None, bot_id: int | None = None) -> str:
    """HTTPS URL of the unified «Интеграция» mini-app (Advertiser/Publisher/Webhooks)."""
    base = get_settings().public_base_url.rstrip("/")
    url = f"{base}/app/integration"
    q = []
    if tab is not None:
        q.append(f"tab={tab}")
    if bot_id is not None:
        q.append(f"bot_id={bot_id}")
    if q:
        url += "?" + "&".join(q)
    return url


def docs_url(bot_id: int) -> str:
    """Per-bot integration → opens the Publisher tab of the unified mini-app."""
    return integration_app_url(tab="pub", bot_id=bot_id)


def main_menu_kb() -> InlineKeyboardMarkup:
    # Статистика теперь живёт в «Профиле», а не в меню.
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=texts.BTN_SELL_TRAFFIC, callback_data=texts.CB_SELL_TRAFFIC)],
        [
            InlineKeyboardButton(text=texts.BTN_PROFILE, callback_data=texts.CB_PROFILE),
            InlineKeyboardButton(text=texts.BTN_BALANCE, callback_data=texts.CB_BALANCE),
        ],
        [InlineKeyboardButton(text=texts.BTN_HELP, callback_data=texts.CB_HELP)],
    ])


def back_to_menu_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=texts.BTN_BACK, callback_data=texts.CB_MENU)],
    ])


def profile_kb() -> InlineKeyboardMarkup:
    """Профиль: статистика + интеграция (API-доки/ключи) + возврат в меню."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=texts.BTN_STATS, web_app=WebAppInfo(url=dashboard_url()))],
        [InlineKeyboardButton(text=texts.BTN_PROFILE_INTEGRATION, web_app=WebAppInfo(url=integration_app_url()))],
        [InlineKeyboardButton(text=texts.BTN_BACK, callback_data=texts.CB_MENU)],
    ])


def sell_traffic_kb(bots: list[tuple[int, str, bool]]) -> InlineKeyboardMarkup:
    """bots: list of (bot_id, name, is_active)."""
    rows: list[list[InlineKeyboardButton]] = []
    for bid, name, is_active in bots:
        emoji =""if is_active else""
        display = name if len(name) <= 30 else name[:27] +"…"
        rows.append([
            InlineKeyboardButton(
                text=f"{emoji} {display}",
                callback_data=f"{texts.CB_BOT_VIEW}{bid}",
            )
        ])
    rows.append([InlineKeyboardButton(text=texts.BTN_ADD_BOT, callback_data=texts.CB_ADD_BOT)])
    rows.append([InlineKeyboardButton(text=texts.BTN_BACK, callback_data=texts.CB_MENU)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def add_bot_choice_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=texts.BTN_BOT_WITH_TOKEN, callback_data=texts.CB_ADD_WITH_TOKEN)],
        [InlineKeyboardButton(text=texts.BTN_BOT_WITHOUT_TOKEN, callback_data=texts.CB_ADD_WITHOUT_TOKEN)],
        [InlineKeyboardButton(text=texts.BTN_CANCEL, callback_data=texts.CB_SELL_TRAFFIC)],
    ])


def add_bot_cancel_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=texts.BTN_CANCEL, callback_data=texts.CB_SELL_TRAFFIC)],
    ])


def bot_card_kb(bot_id: int, is_active: bool) -> InlineKeyboardMarkup:
    toggle_text = "⏹ Остановить" if is_active else "▶️ Запустить"
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="⚙️ Настройки", callback_data=f"{texts.CB_BOT_SETTINGS}{bot_id}"),
            InlineKeyboardButton(text="📊 Статистика", web_app=WebAppInfo(url=dashboard_url(bot_id))),
        ],
        [
            InlineKeyboardButton(text="🖥 Интеграция (API)", web_app=WebAppInfo(url=docs_url(bot_id))),
        ],
        [InlineKeyboardButton(text=toggle_text, callback_data=f"{texts.CB_BOT_TOGGLE}{bot_id}")],
        [InlineKeyboardButton(text="« Назад", callback_data=texts.CB_SELL_TRAFFIC)],
    ])


def settings_kb(bot_id: int, show_quiz: bool, get_links: bool) -> InlineKeyboardMarkup:
    quiz_mark = "✓" if show_quiz else "✗"
    links_mark = "✓" if get_links else "✗"
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="Кол-во спонсоров",
            callback_data=f"{texts.CB_SET_SPONSORS}{bot_id}",
        )],
        [InlineKeyboardButton(
            text="Время сброса",
            callback_data=f"{texts.CB_SET_TTL}{bot_id}",
        )],
        [InlineKeyboardButton(
            text="Мин. цена за подписчика",
            callback_data=f"{texts.CB_SET_MINPRICE}{bot_id}",
        )],
        [InlineKeyboardButton(
            text=f"{quiz_mark} Показывать анкету",
            callback_data=f"{texts.CB_TOGGLE_QUIZ}{bot_id}",
        )],
        [InlineKeyboardButton(
            text=f"{links_mark} Отдавать ссылки в API",
            callback_data=f"{texts.CB_TOGGLE_LINKS}{bot_id}",
        )],
        [InlineKeyboardButton(
            text="Фильтр заданий",
            callback_data=f"{texts.CB_FILTER_MENU}{bot_id}",
        )],
        [InlineKeyboardButton(
            text="Исключить тематики",
            callback_data=f"{texts.CB_THEMES_MENU}{bot_id}",
        )],
        [InlineKeyboardButton(text="« К боту", callback_data=f"{texts.CB_BOT_VIEW}{bot_id}")],
    ])


def task_filter_kb(
    bot_id: int,
    excluded_task_types: list[str],
    excluded_resource_types: list[str],
) -> InlineKeyboardMarkup:
    """Toggle screen: ✅ enabled / ❌ excluded, for task types + resource types."""
    rows: list[list[InlineKeyboardButton]] = []
    task_row: list[InlineKeyboardButton] = []
    for val, label in texts.TASK_TYPE_FILTER_ORDER:
        mark = "❌" if val in excluded_task_types else "✅"
        task_row.append(InlineKeyboardButton(
            text=f"{mark} {label}",
            callback_data=f"{texts.CB_FILTER_TOGGLE}{bot_id}:t:{val}",
        ))
    rows.append(task_row)
    res_row: list[InlineKeyboardButton] = []
    for val, label in texts.RESOURCE_TYPE_FILTER_ORDER:
        mark = "❌" if val in excluded_resource_types else "✅"
        res_row.append(InlineKeyboardButton(
            text=f"{mark} {label}",
            callback_data=f"{texts.CB_FILTER_TOGGLE}{bot_id}:r:{val}",
        ))
    rows.append(res_row)
    rows.append([
        InlineKeyboardButton(
            text="Сохранить",
            callback_data=f"{texts.CB_FILTER_SAVE}{bot_id}",
        ),
        InlineKeyboardButton(
            text="Отмена",
            callback_data=f"{texts.CB_BOT_SETTINGS}{bot_id}",
        ),
    ])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def excluded_themes_kb(
    bot_id: int,
    excluded: list[str],
    counts: dict[str, int] | None = None,
) -> InlineKeyboardMarkup:
    counts = counts or {}
    total = sum(counts.values())
    rows: list[list[InlineKeyboardButton]] = []
    chunk: list[InlineKeyboardButton] = []
    for theme in texts.ALL_THEMES:
        mark = "✓ " if theme in excluded else ""
        label = texts.THEME_LABELS[theme]
        share = round(100 * counts.get(theme, 0) / total) if total else 0
        chunk.append(InlineKeyboardButton(
            text=f"{mark}{label} · {share}%",
            callback_data=f"{texts.CB_THEME_TOGGLE}{bot_id}:{theme}",
        ))
        if len(chunk) == 2:
            rows.append(chunk)
            chunk = []
    if chunk:
        rows.append(chunk)
    rows.append([
        InlineKeyboardButton(
            text="Сохранить",
            callback_data=f"{texts.CB_THEMES_SAVE}{bot_id}",
        ),
        InlineKeyboardButton(
            text="Отмена",
            callback_data=f"{texts.CB_BOT_SETTINGS}{bot_id}",
        ),
    ])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def sponsors_presets_kb(bot_id: int, current: int) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    chunk: list[InlineKeyboardButton] = []
    for n in texts.SPONSORS_PRESETS:
        mark ="" if n == current else""
        chunk.append(InlineKeyboardButton(
            text=f"{mark}{n}",
            callback_data=f"{texts.CB_SPONSORS_VALUE}{bot_id}:{n}",
        ))
        if len(chunk) == 5:
            rows.append(chunk); chunk = []
    if chunk:
        rows.append(chunk)
    rows.append([InlineKeyboardButton(
        text="Своё значение",
        callback_data=f"{texts.CB_SPONSORS_CUSTOM}{bot_id}",
    )])
    rows.append([InlineKeyboardButton(
        text="« К настройкам",
        callback_data=f"{texts.CB_BOT_SETTINGS}{bot_id}",
    )])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def minprice_presets_kb(bot_id: int, current) -> InlineKeyboardMarkup:
    from decimal import Decimal
    cur = Decimal(str(current or 0))
    rows: list[list[InlineKeyboardButton]] = []
    chunk: list[InlineKeyboardButton] = []
    for value, label in texts.MINPRICE_PRESETS:
        mark = "✓ " if Decimal(value) == cur else ""
        chunk.append(InlineKeyboardButton(
            text=f"{mark}{label}",
            callback_data=f"{texts.CB_MINPRICE_VALUE}{bot_id}:{value}",
        ))
        if len(chunk) == 3:
            rows.append(chunk); chunk = []
    if chunk:
        rows.append(chunk)
    rows.append([InlineKeyboardButton(
        text="Своё значение",
        callback_data=f"{texts.CB_MINPRICE_CUSTOM}{bot_id}",
    )])
    rows.append([InlineKeyboardButton(
        text="« К настройкам",
        callback_data=f"{texts.CB_BOT_SETTINGS}{bot_id}",
    )])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def ttl_presets_kb(bot_id: int, current: int) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    chunk: list[InlineKeyboardButton] = []
    for seconds, label in texts.TTL_PRESETS_SECONDS:
        mark ="" if seconds == current else""
        chunk.append(InlineKeyboardButton(
            text=f"{mark}{label}",
            callback_data=f"{texts.CB_TTL_VALUE}{bot_id}:{seconds}",
        ))
        if len(chunk) == 4:
            rows.append(chunk); chunk = []
    if chunk:
        rows.append(chunk)
    rows.append([InlineKeyboardButton(
        text="Своё значение",
        callback_data=f"{texts.CB_TTL_CUSTOM}{bot_id}",
    )])
    rows.append([InlineKeyboardButton(
        text="« К настройкам",
        callback_data=f"{texts.CB_BOT_SETTINGS}{bot_id}",
    )])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def custom_value_cancel_kb(bot_id: int, callback_back: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=texts.BTN_CANCEL, callback_data=f"{callback_back}{bot_id}")],
    ])


def integration_kb(bot_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text=texts.BTN_REGENERATE,
            callback_data=f"{texts.CB_TOKEN_REGEN_PROMPT}{bot_id}",
        )],
        [InlineKeyboardButton(text="« К боту", callback_data=f"{texts.CB_BOT_VIEW}{bot_id}")],
    ])


def regenerate_confirm_kb(bot_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(
                text=texts.BTN_CONFIRM,
                callback_data=f"{texts.CB_TOKEN_REGEN_CONFIRM}{bot_id}",
            ),
            InlineKeyboardButton(
                text=texts.BTN_CANCEL,
                callback_data=f"{texts.CB_BOT_INTEGRATION}{bot_id}",
            ),
        ],
    ])


def balance_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=texts.BTN_WITHDRAW, callback_data=texts.CB_WITHDRAW),
            InlineKeyboardButton(text=texts.BTN_HISTORY, callback_data=texts.CB_HISTORY),
        ],
        [InlineKeyboardButton(text=texts.BTN_BACK, callback_data=texts.CB_MENU)],
    ])


def history_kb(page: int, total_pages: int) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    if total_pages > 1:
        nav: list[InlineKeyboardButton] = []
        if page > 0:
            nav.append(InlineKeyboardButton(
                text="« Назад", callback_data=f"{texts.CB_HISTORY_PAGE}{page - 1}",
            ))
        nav.append(InlineKeyboardButton(
            text=f"{page + 1}/{total_pages}", callback_data=texts.CB_NOOP,
        ))
        if page < total_pages - 1:
            nav.append(InlineKeyboardButton(
                text="Вперёд »", callback_data=f"{texts.CB_HISTORY_PAGE}{page + 1}",
            ))
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="« К балансу", callback_data=texts.CB_BALANCE)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def withdraw_cancel_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=texts.BTN_CANCEL, callback_data=texts.CB_BALANCE)],
    ])


def withdraw_method_kb() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(
            text=label,
            callback_data=f"{texts.CB_WITHDRAW_METHOD}{key}",
        )]
        for key, label in texts.WITHDRAW_METHOD_LABELS.items()
    ]
    rows.append([InlineKeyboardButton(text=texts.BTN_CANCEL, callback_data=texts.CB_BALANCE)])
    return InlineKeyboardMarkup(inline_keyboard=rows)
