"""Admin command: manually credit a user's balance — /addbalance.

Usage: /addbalance <@username|tg_id> <amount> [adv|pub]
Defaults to the advertiser balance; pass `pub` for a publisher.
"""

from __future__ import annotations

from decimal import Decimal, InvalidOperation

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.db.models import Advertiser, Publisher
from src.core.logging import get_logger
from src.domain.transactions import TransactionService

router = Router(name="admin_balance")
log = get_logger("admin.balance")

_USAGE = (
    "Пополнение баланса\n\n"
    "<code>/addbalance &lt;@username|tg_id&gt; &lt;сумма&gt; [adv|pub]</code>\n\n"
    "Примеры:\n"
    "• <code>/addbalance @nklabs 5000</code> — +5000 ₽ рекламодателю\n"
    "• <code>/addbalance 7057452528 1000 pub</code> — +1000 ₽ паблишеру\n\n"
    "По умолчанию — рекламодателю (adv)."
)


async def _resolve(
    session: AsyncSession, role: str, target_raw: str,
) -> Advertiser | Publisher | None:
    model = Advertiser if role == "adv" else Publisher
    if target_raw.startswith("@"):
        stmt = select(model).where(model.tg_username == target_raw[1:])
    else:
        try:
            stmt = select(model).where(model.tg_user_id == int(target_raw))
        except ValueError:
            return None
    result = await session.execute(stmt)
    return result.scalar_one_or_none()


@router.message(Command("addbalance"))
async def add_balance(
    message: Message,
    admin_tg_id: int,
    session: AsyncSession,
) -> None:
    parts = (message.text or "").split()
    if len(parts) < 3:
        await message.answer(_USAGE)
        return

    target_raw = parts[1]
    try:
        amount = Decimal(parts[2].replace(",", "."))
    except (InvalidOperation, ValueError):
        await message.answer("Сумма должна быть числом.\n\n" + _USAGE)
        return
    if amount <= 0 or amount > Decimal("1000000"):
        await message.answer("Сумма должна быть от 0 до 1 000 000 ₽.")
        return

    role = parts[3].lower() if len(parts) >= 4 else "adv"
    if role not in ("adv", "pub"):
        await message.answer("Роль должна быть <code>adv</code> или <code>pub</code>.\n\n" + _USAGE)
        return

    target = await _resolve(session, role, target_raw)
    if target is None:
        who = "Рекламодатель" if role == "adv" else "Паблишер"
        await message.answer(f"{who} не найден: {target_raw}")
        return

    svc = TransactionService(session)
    try:
        await svc.admin_credit_balance(
            target=target, amount_rub=amount, admin_tg_id=admin_tg_id,
        )
    except ValueError as e:
        await message.answer(f"Ошибка: {e}")
        return

    to_whom = "рекламодателю" if role == "adv" else "паблишеру"
    label = f"@{target.tg_username}" if target.tg_username else f"id:{target.id}"
    await message.answer(
        f"✅ Зачислено <b>{amount:.2f} ₽</b> {to_whom} {label}.\n"
        f"Новый баланс: <b>{target.balance_rub:.2f} ₽</b>"
    )
    log.info(
        "admin_addbalance_ok",
        admin_tg_id=admin_tg_id, role=role, target_id=target.id, amount=str(amount),
    )
