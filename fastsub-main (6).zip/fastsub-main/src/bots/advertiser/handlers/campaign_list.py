"""Campaign listing and detail handlers."""

from __future__ import annotations

import math
from decimal import Decimal

from aiogram import F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from src.bots.advertiser import texts
from src.bots.advertiser.keyboards import campaign as camp_kb
from src.bots.advertiser.keyboards.main_menu import back_to_menu_kb
from src.bots.advertiser.states.campaign import CampaignEdit
from src.core.db.models import Advertiser
from src.core.db.models.enums import CampaignStatus
from src.core.logging import get_logger
from src.domain.campaigns import CampaignRepository, CampaignService
from src.domain.exceptions import CampaignValidationError, InsufficientFundsError

router = Router(name="campaign_list")
log = get_logger("handler.campaign_list")


PAGE_SIZE = 10


STATUS_EMOJI: dict[CampaignStatus, str] = {
    CampaignStatus.DRAFT:"",
    CampaignStatus.PENDING_MODERATION:"",
    CampaignStatus.ACTIVE:"",
    CampaignStatus.PAUSED:"",
    CampaignStatus.COMPLETED:"",
    CampaignStatus.REJECTED:"",
    CampaignStatus.CANCELED:"",
}


STATUS_LABEL: dict[CampaignStatus, str] = {
    CampaignStatus.DRAFT:"Черновик",
    CampaignStatus.PENDING_MODERATION:"На модерации",
    CampaignStatus.ACTIVE:"Активна",
    CampaignStatus.PAUSED:"Пауза",
    CampaignStatus.COMPLETED:"Завершена",
    CampaignStatus.REJECTED:"Отклонена",
    CampaignStatus.CANCELED:"Отменена",
}


# ---------- Override: CB_CAMPAIGNS now shows real list ----------


@router.callback_query(F.data == texts.CB_CAMPAIGNS)
async def show_my_campaigns(
    callback: CallbackQuery,
    advertiser: Advertiser,
    session: AsyncSession,
) -> None:
    await _render_page(callback, advertiser, session, page=0)


@router.callback_query(F.data.startswith(camp_kb.CB_CAMP_LIST_PAGE))
async def list_page(
    callback: CallbackQuery,
    advertiser: Advertiser,
    session: AsyncSession,
) -> None:
    try:
        page = int(callback.data.removeprefix(camp_kb.CB_CAMP_LIST_PAGE))
    except ValueError:
        await callback.answer("Неверная страница", show_alert=True)
        return
    await _render_page(callback, advertiser, session, page=page)


async def _render_page(
    callback: CallbackQuery,
    advertiser: Advertiser,
    session: AsyncSession,
    *,
    page: int,
) -> None:
    repo = CampaignRepository(session)
    total = await repo.count_for_advertiser(advertiser.id)

    if total == 0:
        try:
            await callback.message.edit_text(
                "<b>Кампании</b>\n\n"
                "У вас пока нет ни одной кампании.\n\n"
                "Нажмите «Создать», чтобы начать.",
                reply_markup=camp_kb.campaigns_empty_kb(),
            )
        except TelegramBadRequest:
            pass
        await callback.answer()
        return

    total_pages = max(1, math.ceil(total / PAGE_SIZE))
    page = max(0, min(page, total_pages - 1))

    campaigns = await repo.list_for_advertiser(
        advertiser.id, limit=PAGE_SIZE, offset=page * PAGE_SIZE,
    )

    rows: list[tuple[int, str, str]] = []
    for c in campaigns:
        emoji = STATUS_EMOJI.get(c.status,"•")
        rows.append((c.id, c.title, emoji))

    text = (
        f"<b>Мои кампании</b> ({total} шт.)\n\n"
        "Нажмите на кампанию для подробностей."
    )
    try:
        await callback.message.edit_text(
            text,
            reply_markup=camp_kb.campaign_list_kb(
                rows, page=page, total_pages=total_pages,
            ),
        )
    except TelegramBadRequest:
        pass
    await callback.answer()


# ---------- Detail ----------


@router.callback_query(F.data.startswith(camp_kb.CB_CAMP_VIEW))
async def view_campaign(
    callback: CallbackQuery,
    advertiser: Advertiser,
    session: AsyncSession,
) -> None:
    try:
        campaign_id = int(callback.data.removeprefix(camp_kb.CB_CAMP_VIEW))
    except ValueError:
        await callback.answer("Неверный ID", show_alert=True)
        return

    repo = CampaignRepository(session)
    campaign = await repo.get_by_id(campaign_id, with_resources=True)

    if campaign is None or campaign.advertiser_id != advertiser.id:
        await callback.answer("Кампания не найдена", show_alert=True)
        return

    await _render_campaign_detail(callback, campaign)
    await callback.answer()


def _campaign_detail_text(campaign) -> str:
    lines = [
        f"{STATUS_EMOJI.get(campaign.status, '•')} <b>{campaign.title}</b>\n",
        f"<b>Статус:</b> {STATUS_LABEL.get(campaign.status, str(campaign.status.value))}",
        f"<b>Бюджет:</b> {campaign.budget_total_rub:.2f} ₽",
    ]
    if campaign.budget_spent_rub > 0:
        lines.append(f"<b>Потрачено:</b> {campaign.budget_spent_rub:.2f} ₽")
    if campaign.budget_reserved_rub > 0:
        lines.append(f"<b>В резерве:</b> {campaign.budget_reserved_rub:.2f} ₽")
    if campaign.status == CampaignStatus.REJECTED and campaign.rejection_reason:
        lines.append(f"\n<b>Причина отклонения:</b>\n<i>{campaign.rejection_reason}</i>")
    lines.append("\n<b>Ресурсы:</b>")
    for r in campaign.resources:
        name = (r.username and f"@{r.username}") or r.title or f"chat {r.tg_chat_id}"
        lines.append(
            f"• {name} — {r.reward_rub:.2f} ₽ × {r.target_subscribers}"
            f"(набрано {r.actual_subscribers})"
        )
    return "\n".join(lines)


async def _render_campaign_detail(callback: CallbackQuery, campaign) -> None:
    try:
        await callback.message.edit_text(
            _campaign_detail_text(campaign),
            reply_markup=camp_kb.campaign_detail_kb(campaign.id, status=campaign.status.value),
        )
    except TelegramBadRequest:
        pass


async def _load_owned(callback, advertiser, session, raw_prefix):
    """Parse campaign_id from callback, load it (with resources), verify ownership."""
    try:
        campaign_id = int(callback.data.removeprefix(raw_prefix))
    except ValueError:
        await callback.answer("Неверный ID", show_alert=True)
        return None
    campaign = await CampaignRepository(session).get_by_id(campaign_id, with_resources=True)
    if campaign is None or campaign.advertiser_id != advertiser.id:
        await callback.answer("Кампания не найдена", show_alert=True)
        return None
    return campaign


@router.callback_query(F.data.startswith(camp_kb.CB_CAMP_PAUSE))
async def pause_campaign(
    callback: CallbackQuery, advertiser: Advertiser, session: AsyncSession,
) -> None:
    campaign = await _load_owned(callback, advertiser, session, camp_kb.CB_CAMP_PAUSE)
    if campaign is None:
        return
    try:
        await CampaignService(session).pause(campaign=campaign)
    except CampaignValidationError as e:
        await callback.answer(e.user_message, show_alert=True)
        return
    await callback.answer("Кампания на паузе")
    await _render_campaign_detail(callback, campaign)


@router.callback_query(F.data.startswith(camp_kb.CB_CAMP_RESUME))
async def resume_campaign(
    callback: CallbackQuery, advertiser: Advertiser, session: AsyncSession,
) -> None:
    campaign = await _load_owned(callback, advertiser, session, camp_kb.CB_CAMP_RESUME)
    if campaign is None:
        return
    try:
        await CampaignService(session).resume(campaign=campaign)
    except CampaignValidationError as e:
        await callback.answer(e.user_message, show_alert=True)
        return
    await callback.answer("Кампания возобновлена")
    await _render_campaign_detail(callback, campaign)


@router.callback_query(F.data.startswith(camp_kb.CB_CAMP_DELETE_OK))
async def delete_campaign_confirmed(
    callback: CallbackQuery, advertiser: Advertiser, session: AsyncSession,
) -> None:
    campaign = await _load_owned(callback, advertiser, session, camp_kb.CB_CAMP_DELETE_OK)
    if campaign is None:
        return
    try:
        refund = await CampaignService(session).cancel_with_refund(campaign=campaign)
    except CampaignValidationError as e:
        await callback.answer(e.user_message, show_alert=True)
        return
    await callback.answer(f"Удалено. Возврат: {refund:.2f} ₽")
    await _render_page(callback, advertiser, session, page=0)


@router.callback_query(F.data.startswith(camp_kb.CB_CAMP_DELETE))
async def delete_campaign_prompt(
    callback: CallbackQuery, advertiser: Advertiser, session: AsyncSession,
) -> None:
    campaign = await _load_owned(callback, advertiser, session, camp_kb.CB_CAMP_DELETE)
    if campaign is None:
        return
    refund = (
        campaign.budget_total_rub
        if campaign.status == CampaignStatus.PENDING_MODERATION
        else campaign.budget_reserved_rub
    )
    try:
        await callback.message.edit_text(
            f"Удалить кампанию «{campaign.title}»?\n\n"
            f"На баланс вернётся остаток: <b>{refund:.2f} ₽</b>.\n"
            f"Действие необратимо.",
            reply_markup=camp_kb.campaign_delete_confirm_kb(campaign.id),
        )
    except TelegramBadRequest:
        pass
    await callback.answer()


@router.callback_query(F.data.startswith(camp_kb.CB_CAMP_CANCEL_DRAFT))
async def cancel_draft(
    callback: CallbackQuery,
    advertiser: Advertiser,
    session: AsyncSession,
) -> None:
    try:
        campaign_id = int(callback.data.removeprefix(camp_kb.CB_CAMP_CANCEL_DRAFT))
    except ValueError:
        await callback.answer("Неверный ID", show_alert=True)
        return

    svc = CampaignService(session)
    campaign = await svc.repo.get_by_id(campaign_id)
    if campaign is None or campaign.advertiser_id != advertiser.id:
        await callback.answer("Кампания не найдена", show_alert=True)
        return

    try:
        await svc.cancel_draft(campaign=campaign)
    except CampaignValidationError as e:
        await callback.answer(e.user_message, show_alert=True)
        return

    await callback.answer("Черновик удалён")
    # Return to list
    await _render_page(callback, advertiser, session, page=0)


# ---------- Edit: rename + buy more subscribers ----------


@router.callback_query(F.data.startswith(camp_kb.CB_CAMP_EDIT))
async def edit_menu(
    callback: CallbackQuery, state: FSMContext, advertiser: Advertiser, session: AsyncSession,
) -> None:
    await state.clear()
    campaign = await _load_owned(callback, advertiser, session, camp_kb.CB_CAMP_EDIT)
    if campaign is None:
        return
    try:
        await callback.message.edit_text(
            f"✏️ <b>Редактирование «{campaign.title}»</b>\n\n"
            "Измените название или докупите подписчиков по ресурсу.",
            reply_markup=camp_kb.campaign_edit_kb(campaign.id, campaign.resources),
        )
    except TelegramBadRequest:
        pass
    await callback.answer()


@router.callback_query(F.data.startswith(camp_kb.CB_CAMP_RENAME))
async def rename_prompt(
    callback: CallbackQuery, state: FSMContext, advertiser: Advertiser, session: AsyncSession,
) -> None:
    campaign = await _load_owned(callback, advertiser, session, camp_kb.CB_CAMP_RENAME)
    if campaign is None:
        return
    await state.set_state(CampaignEdit.entering_title)
    await state.update_data(edit_campaign_id=campaign.id)
    try:
        await callback.message.edit_text(
            "Введите новое название кампании (1–255 символов):",
            reply_markup=camp_kb.campaign_edit_back_kb(campaign.id),
        )
    except TelegramBadRequest:
        pass
    await callback.answer()


@router.message(CampaignEdit.entering_title, F.text)
async def rename_input(
    message: Message, state: FSMContext, advertiser: Advertiser, session: AsyncSession,
) -> None:
    data = await state.get_data()
    cid = data.get("edit_campaign_id")
    if cid is None:
        await state.clear()
        return
    svc = CampaignService(session)
    campaign = await svc.repo.get_by_id(cid, with_resources=True)
    if campaign is None or campaign.advertiser_id != advertiser.id:
        await state.clear()
        return
    try:
        await svc.rename(campaign=campaign, new_title=message.text or "")
    except CampaignValidationError as e:
        await message.answer(e.user_message, reply_markup=camp_kb.campaign_edit_back_kb(cid))
        return
    await state.clear()
    await message.answer(
        _campaign_detail_text(campaign),
        reply_markup=camp_kb.campaign_detail_kb(campaign.id, status=campaign.status.value),
    )


@router.callback_query(F.data.startswith(camp_kb.CB_CAMP_ADDSUBS))
async def addsubs_prompt(
    callback: CallbackQuery, state: FSMContext, advertiser: Advertiser, session: AsyncSession,
) -> None:
    raw = callback.data.removeprefix(camp_kb.CB_CAMP_ADDSUBS)
    try:
        cid_str, rid_str = raw.split(":", 1)
        cid, rid = int(cid_str), int(rid_str)
    except (ValueError, IndexError):
        await callback.answer("Неверные данные", show_alert=True)
        return
    campaign = await CampaignRepository(session).get_by_id(cid, with_resources=True)
    if campaign is None or campaign.advertiser_id != advertiser.id:
        await callback.answer("Кампания не найдена", show_alert=True)
        return
    resource = next((r for r in campaign.resources if r.id == rid), None)
    if resource is None:
        await callback.answer("Ресурс не найден", show_alert=True)
        return
    await state.set_state(CampaignEdit.entering_addsubs)
    await state.update_data(edit_campaign_id=cid, edit_resource_id=rid)
    name = (resource.username and f"@{resource.username}") or resource.title or f"#{resource.id}"
    try:
        await callback.message.edit_text(
            f"Сколько подписчиков докупить для <b>{name}</b>?\n"
            f"Цена: {resource.reward_rub:.2f} ₽/подп. Спишется из баланса.",
            reply_markup=camp_kb.campaign_edit_back_kb(cid),
        )
    except TelegramBadRequest:
        pass
    await callback.answer()


@router.message(CampaignEdit.entering_addsubs, F.text)
async def addsubs_input(
    message: Message, state: FSMContext, advertiser: Advertiser, session: AsyncSession,
) -> None:
    data = await state.get_data()
    cid = data.get("edit_campaign_id")
    rid = data.get("edit_resource_id")
    if cid is None or rid is None:
        await state.clear()
        return
    raw = (message.text or "").strip()
    try:
        count = int(raw)
    except ValueError:
        await message.answer(
            "Введите целое число подписчиков, например 100.",
            reply_markup=camp_kb.campaign_edit_back_kb(cid),
        )
        return
    if count <= 0 or count > 1_000_000:
        await message.answer("Количество должно быть от 1 до 1 000 000.")
        return

    svc = CampaignService(session)
    campaign = await svc.repo.get_by_id(cid, with_resources=True)
    if campaign is None or campaign.advertiser_id != advertiser.id:
        await state.clear()
        return
    resource = next((r for r in campaign.resources if r.id == rid), None)
    if resource is None:
        await state.clear()
        return
    try:
        cost = await svc.add_subscribers(campaign=campaign, resource=resource, count=count)
    except InsufficientFundsError as e:
        await message.answer(
            f"{e.user_message}\n\nПополните баланс и попробуйте снова.",
            reply_markup=camp_kb.campaign_edit_back_kb(cid),
        )
        return
    except CampaignValidationError as e:
        await message.answer(e.user_message, reply_markup=camp_kb.campaign_edit_back_kb(cid))
        return

    await state.clear()
    await message.answer(
        f"✅ Докуплено {count} подписчиков (−{cost:.2f} ₽).\n\n"
        + _campaign_detail_text(campaign),
        reply_markup=camp_kb.campaign_detail_kb(campaign.id, status=campaign.status.value),
    )
