"""Direct USDT (TON) top-up branch of the top-up flow.

Reached from the payment-method choice (see topup.py). Shows the wallet
address, exact USDT amount and a unique memo; lets the user open a wallet via
a deep link and re-check payment on demand. The periodic worker
(src/workers/ton_payments.py) also credits in the background.
"""

from __future__ import annotations

from decimal import Decimal, InvalidOperation
from urllib.parse import urlencode

from aiogram import F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from src.bots.advertiser.keyboards import topup as topup_kb
from src.bots.advertiser.keyboards.main_menu import main_menu_inline_kb
from src.bots.advertiser.states.topup import TopupStates
from src.core.config import get_settings
from src.core.db.models import Advertiser, TonTopup
from src.core.db.models.enums import TonTopupStatus
from src.core.logging import get_logger
from src.domain.exceptions import CryptoBotError, DomainError
from src.domain.payments import PaymentsService, TonTopupRepository
from src.integrations.ton import TonClient
from src.shared.money import to_money

router = Router(name="topup_ton")
log = get_logger("handler.topup_ton")


# ---------- Rendering helpers ----------


def _fmt_usdt(value: Decimal) -> str:
    """USDT amount without trailing zeros (e.g. 5.230000 → '5.23')."""
    s = f"{value:.6f}".rstrip("0").rstrip(".")
    return s or "0"


def _wallet_deeplink(wallet: str, jetton_master: str, expected_usdt: Decimal, memo: str) -> str:
    """Tonkeeper deep link with amount (in USDT minimal units), jetton and memo prefilled."""
    nano = int((expected_usdt * (Decimal(10) ** 6)).to_integral_value())
    params = urlencode({"amount": str(nano), "text": memo, "jetton": jetton_master})
    return f"https://app.tonkeeper.com/transfer/{wallet}?{params}"


def _instructions_text(topup: TonTopup, wallet: str, minutes: int) -> str:
    return (
        "💎 <b>Оплата USDT (TON)</b>\n\n"
        f"К оплате: <b>{_fmt_usdt(topup.expected_usdt)} USDT</b> "
        f"(≈ {topup.amount_rub:.2f} ₽)\n\n"
        "1️⃣ Отправьте эту сумму <b>USDT</b> в сети <b>TON</b> на адрес:\n"
        f"<code>{wallet}</code>\n\n"
        "2️⃣ Обязательно укажите комментарий к переводу:\n"
        f"<code>{topup.memo}</code>\n\n"
        "⚠️ Без точного комментария платёж не зачислится автоматически.\n\n"
        "Зачисление — в течение ~минуты после подтверждения сети.\n"
        f"<i>Реквизиты действительны {minutes} мин.</i>"
    )


def _paid_text(topup: TonTopup) -> str:
    paid = topup.paid_usdt if topup.paid_usdt is not None else topup.expected_usdt
    return (
        "✅ <b>Баланс пополнен</b>\n\n"
        f"Зачислено: <b>{topup.amount_rub:.2f} ₽</b>\n"
        f"Оплачено: <b>{_fmt_usdt(paid)} USDT</b> (TON)\n\n"
        "Спасибо! Теперь вы можете создать кампанию."
    )


# ---------- Method: direct USDT (TON) ----------


@router.callback_query(TopupStates.choosing_method, F.data == topup_kb.CB_TOPUP_METHOD_TON)
async def method_ton(
    callback: CallbackQuery,
    state: FSMContext,
    advertiser: Advertiser,
    session: AsyncSession,
) -> None:
    """User chose to pay directly in USDT on TON — create intent + show requisites."""
    data = await state.get_data()
    try:
        amount_rub = to_money(Decimal(data.get("amount_rub", "0")))
    except (InvalidOperation, ValueError):
        amount_rub = Decimal("0")
    if amount_rub <= 0:
        await callback.answer("Сумма не задана, начните заново", show_alert=True)
        await state.clear()
        return

    await callback.answer("Готовлю реквизиты…")
    svc = PaymentsService(session)
    try:
        topup = await svc.create_ton_topup(advertiser=advertiser, amount_rub=amount_rub)
    except DomainError as e:
        try:
            await callback.message.edit_text(
                f"{e.user_message}", reply_markup=topup_kb.topup_method_kb()
            )
        except TelegramBadRequest:
            pass
        return
    except CryptoBotError as e:
        log.error("ton_topup_create_error", error=str(e), advertiser_id=advertiser.id)
        try:
            await callback.message.edit_text(
                "Не удалось подготовить оплату. Попробуйте позже.",
                reply_markup=main_menu_inline_kb(),
            )
        except TelegramBadRequest:
            pass
        return

    await state.clear()
    settings = get_settings()
    deep_link = _wallet_deeplink(
        settings.ton_wallet_address,
        settings.ton_usdt_jetton_master,
        topup.expected_usdt,
        topup.memo,
    )
    try:
        await callback.message.edit_text(
            _instructions_text(topup, settings.ton_wallet_address, settings.ton_topup_expires_minutes),
            reply_markup=topup_kb.topup_ton_kb(deep_link, topup.id),
        )
    except TelegramBadRequest:
        pass


# ---------- On-demand "проверить оплату" ----------


@router.callback_query(F.data.startswith(topup_kb.CB_TOPUP_TON_CHECK))
async def check_ton_payment(callback: CallbackQuery, session: AsyncSession) -> None:
    """Poll the indexer once for this top-up and credit it if the transfer arrived."""
    raw = callback.data.removeprefix(topup_kb.CB_TOPUP_TON_CHECK)
    try:
        topup_id = int(raw)
    except ValueError:
        await callback.answer("Некорректный счёт", show_alert=True)
        return

    ton_repo = TonTopupRepository(session)
    topup = await ton_repo.get_by_id(topup_id)
    if topup is None:
        await callback.answer("Счёт не найден", show_alert=True)
        return
    if topup.status == TonTopupStatus.PAID:
        await callback.answer("Оплата уже зачислена ✅", show_alert=True)
        try:
            await callback.message.edit_text(_paid_text(topup), reply_markup=main_menu_inline_kb())
        except TelegramBadRequest:
            pass
        return
    if topup.status == TonTopupStatus.EXPIRED:
        await callback.answer("Счёт истёк. Создайте новый.", show_alert=True)
        return

    svc = PaymentsService(session)
    async with TonClient() as ton:
        transfers = await ton.get_incoming_usdt_transfers(limit=100)
    credited = await svc.match_ton_transfers([topup], transfers)

    if credited:
        await callback.answer("Оплата найдена ✅")
        try:
            await callback.message.edit_text(_paid_text(topup), reply_markup=main_menu_inline_kb())
        except TelegramBadRequest:
            pass
    else:
        await callback.answer(
            "Платёж пока не виден. Если только что отправили — подождите минуту и нажмите ещё раз.",
            show_alert=True,
        )
