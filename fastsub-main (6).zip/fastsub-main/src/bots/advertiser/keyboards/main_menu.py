"""Main menu inline keyboard."""

from __future__ import annotations
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from src.bots.advertiser import texts


def main_menu_inline_kb() -> InlineKeyboardMarkup:
    # In the combined "main" bot the advertiser section is just one part of the
    # unified top-level menu. Always return that unified menu so every "« Назад"
    # lands on the real main menu (advertiser + publisher), not the legacy
    # advertiser-only one. Imported lazily to avoid an import cycle at startup.
    from src.bots.main.keyboards import main_menu_kb as unified_menu_kb

    return unified_menu_kb()


def back_to_menu_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=texts.btn_back(), callback_data=texts.CB_MENU)],
    ])
