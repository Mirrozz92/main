"""Advertiser model — пользователи, заказывающие рекламу."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from sqlalchemy import (
    BigInteger,
    DateTime,
    ForeignKey,
    Index,
    LargeBinary,
    Numeric,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from src.core.db.base import Base, TimestampMixin


class Advertiser(Base, TimestampMixin):
    __tablename__ = "advertisers"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)

    # Telegram identity
    tg_user_id: Mapped[int] = mapped_column(BigInteger, unique=True, nullable=False, index=True)
    tg_username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    full_name: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # Balances в рублях (NUMERIC(18, 4))
    balance_rub: Mapped[Decimal] = mapped_column(
        Numeric(18, 4), nullable=False, default=Decimal("0"), server_default="0"
    )
    reserved_rub: Mapped[Decimal] = mapped_column(
        Numeric(18, 4), nullable=False, default=Decimal("0"), server_default="0"
    )
    total_spent_rub: Mapped[Decimal] = mapped_column(
        Numeric(18, 4), nullable=False, default=Decimal("0"), server_default="0"
    )

    # Status
    is_banned: Mapped[bool] = mapped_column(default=False, server_default="false", nullable=False)
    ban_reason: Mapped[str | None] = mapped_column(Text, nullable=True)

    def __repr__(self) -> str:
        return f"<Advertiser id={self.id} tg={self.tg_user_id} balance={self.balance_rub}>"


class AdvertiserApiToken(Base, TimestampMixin):
    """API key for an advertiser's bot to confirm bot-start tasks.

    The advertiser drops a few lines into their bot's /start handler: when the
    payload is `fastsub_<link_id>`, it calls POST /api/v1/advertiser/confirm-start
    with this key so we can reliably verify the start. One active token per
    advertiser; regenerating revokes the previous one.
    """

    __tablename__ = "advertiser_api_tokens"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)

    advertiser_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("advertisers.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    token_prefix: Mapped[str] = mapped_column(String(16), nullable=False)
    token_hash: Mapped[str] = mapped_column(String(64), nullable=False, unique=True, index=True)
    # Fernet-encrypted plaintext so the bot/cabinet UI can show & re-copy the key.
    token_encrypted: Mapped[bytes | None] = mapped_column(LargeBinary, nullable=True)

    label: Mapped[str] = mapped_column(String(128), nullable=False, default="Default")

    is_active: Mapped[bool] = mapped_column(default=True, server_default="true", nullable=False)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    requests_count: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0, server_default="0"
    )

    advertiser: Mapped[Advertiser] = relationship("Advertiser")

    __table_args__ = (
        Index("ix_advertiser_api_tokens_active", "is_active", "advertiser_id"),
    )
