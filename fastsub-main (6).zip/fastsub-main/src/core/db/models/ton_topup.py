"""TonTopup — намерение прямого пополнения баланса рекламодателя в USDT (TON).

Создаётся в момент, когда рекламодатель выбирает оплату USDT на наш TON-кошелёк.
Хранит сумму в ₽ (что зачислить), ожидаемую сумму в USDT (для отображения и
матчинга) и уникальный memo-комментарий. Фоновый воркер сверяет входящие
on-chain переводы по memo и переводит запись в `paid`, создавая запись в ledger.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from sqlalchemy import BigInteger, DateTime, ForeignKey, Index, Numeric, String
from sqlalchemy.orm import Mapped, mapped_column

from src.core.db.base import Base, TimestampMixin
from src.core.db.models.enums import TonTopupStatus
from src.core.db.types import pg_enum


class TonTopup(Base, TimestampMixin):
    __tablename__ = "ton_topups"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)

    advertiser_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("advertisers.id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )

    # Сколько зачислить (₽) и сколько ждём в USDT (snapshot курса на момент создания)
    amount_rub: Mapped[Decimal] = mapped_column(Numeric(18, 4), nullable=False)
    expected_usdt: Mapped[Decimal] = mapped_column(Numeric(18, 6), nullable=False)

    # Уникальный комментарий-мемо, который плательщик прикладывает к переводу
    memo: Mapped[str] = mapped_column(String(32), nullable=False, unique=True)

    status: Mapped[TonTopupStatus] = mapped_column(
        pg_enum(TonTopupStatus, name="ton_topup_status"),
        nullable=False,
        default=TonTopupStatus.PENDING,
        server_default=TonTopupStatus.PENDING.value,
    )

    # Детали найденного перевода (заполняются при оплате)
    tx_hash: Mapped[str | None] = mapped_column(String(128), nullable=True, unique=True)
    paid_usdt: Mapped[Decimal | None] = mapped_column(Numeric(18, 6), nullable=True)
    transaction_id: Mapped[int | None] = mapped_column(
        BigInteger,
        ForeignKey("transactions.id", ondelete="SET NULL"),
        nullable=True,
    )

    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)

    __table_args__ = (
        # Hot index для воркера-поллера: pending с приближающимся истечением
        Index("ix_ton_topups_status_expires", "status", "expires_at"),
    )
