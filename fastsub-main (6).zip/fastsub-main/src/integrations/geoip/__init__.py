"""IP geolocation + VPN/proxy detection (used on the web-onboarding form)."""

from src.integrations.geoip.client import GeoIpClient, GeoResult

__all__ = ["GeoIpClient", "GeoResult"]
