"""GeoIP lookup with VPN/proxy detection.

Default provider is ip-api.com — its free endpoint returns the `proxy` and
`hosting` flags we use to spot VPN/proxy/datacenter traffic. We treat such
traffic as «Неопределён»: when a request looks like a VPN we deliberately drop
the country/city so it is not counted as real geo.

The lookup is fail-open: any error/timeout returns an undetermined result so it
can never block a user's registration.
"""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass

import httpx

from src.core.config import get_settings
from src.core.logging import get_logger

log = get_logger("geoip")


@dataclass(slots=True)
class GeoResult:
    """Result of an IP lookup.

    country_code / city are None when the IP is a VPN/proxy or could not be
    resolved. `is_vpn` is True only when the provider positively flagged the IP.
    """

    country_code: str | None
    city: str | None
    is_vpn: bool

    @classmethod
    def undetermined(cls) -> GeoResult:
        return cls(country_code=None, city=None, is_vpn=False)

    @classmethod
    def vpn(cls) -> GeoResult:
        return cls(country_code=None, city=None, is_vpn=True)


def _is_public_ip(ip: str | None) -> bool:
    if not ip:
        return False
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return not (addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_reserved)


class GeoIpClient:
    """Async geoip client (ip-api.com compatible)."""

    def __init__(
        self,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float | None = None,
    ) -> None:
        settings = get_settings()
        self._base = (base_url or settings.geoip_api_base_url).rstrip("/")
        self._timeout = timeout if timeout is not None else settings.geoip_timeout_seconds
        key = api_key
        if key is None and settings.geoip_api_key is not None:
            key = settings.geoip_api_key.get_secret_value()
        self._key = key

    async def lookup(self, ip: str | None) -> GeoResult:
        """Resolve country/city + VPN flag for `ip`. Never raises."""
        if not _is_public_ip(ip):
            return GeoResult.undetermined()

        params = {"fields": "status,message,countryCode,city,proxy,hosting"}
        if self._key:
            params["key"] = self._key

        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.get(f"{self._base}/{ip}", params=params)
                resp.raise_for_status()
                data = resp.json()
        except Exception as e:
            # Fail-open: geo is best-effort and must never block registration.
            log.warning("geoip_lookup_failed", ip=ip, error=str(e))
            return GeoResult.undetermined()

        if data.get("status") != "success":
            log.info("geoip_no_result", ip=ip, message=data.get("message"))
            return GeoResult.undetermined()

        if data.get("proxy") or data.get("hosting"):
            return GeoResult.vpn()

        cc = (data.get("countryCode") or "").strip().upper() or None
        city = (data.get("city") or "").strip() or None
        return GeoResult(country_code=cc, city=city[:80] if city else None, is_vpn=False)
