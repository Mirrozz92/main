"""Read-only TON indexer client (tonapi.io).

Detects incoming USDT (jetton) transfers to our wallet. We never hold the
wallet's private key — we only *watch* the address and match payments by the
text comment (memo) the payer attaches.

Docs: https://tonapi.io/api-v2
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Any

import httpx
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from src.core.config import get_settings
from src.core.logging import get_logger

log = get_logger("ton")

USDT_DECIMALS = 6


@dataclass(slots=True)
class JettonTransfer:
    """One incoming jetton transfer, as decoded by the indexer."""

    event_id: str          # unique trace/event id (used for idempotency)
    sender: str            # raw address of the payer
    amount: Decimal        # in human units (e.g. USDT), not nano
    comment: str | None    # text memo the payer attached to the transfer
    utime: int             # unix seconds


class TonClient:
    """Async read-only client over tonapi.io.

    Use as a context manager or call .close() to release the HTTP session.
    """

    def __init__(
        self,
        *,
        wallet: str | None = None,
        jetton_master: str | None = None,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float = 15.0,
    ) -> None:
        settings = get_settings()
        self._wallet = wallet or settings.ton_wallet_address
        self._jetton = jetton_master or settings.ton_usdt_jetton_master
        key = api_key
        if key is None and settings.ton_api_key is not None:
            key = settings.ton_api_key.get_secret_value()

        headers = {"Accept": "application/json"}
        if key:
            headers["Authorization"] = f"Bearer {key}"

        self._client = httpx.AsyncClient(
            base_url=(base_url or settings.ton_api_base_url).rstrip("/"),
            timeout=timeout,
            headers=headers,
        )
        self._wallet_raw: str | None = None

    async def __aenter__(self) -> TonClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def close(self) -> None:
        await self._client.aclose()

    @retry(
        retry=retry_if_exception_type((httpx.TransportError, httpx.HTTPStatusError)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=0.5, max=4),
        reraise=True,
    )
    async def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        resp = await self._client.get(path, params=params or {})
        resp.raise_for_status()
        return resp.json()

    async def _wallet_raw_address(self) -> str | None:
        """Resolve our wallet to its raw (0:hex) form for direction filtering."""
        if self._wallet_raw is not None:
            return self._wallet_raw
        try:
            data = await self._get(f"/v2/address/{self._wallet}/parse")
            self._wallet_raw = (data.get("raw_form") or "").lower() or None
        except Exception as e:  # best-effort: memo uniqueness is the real guard
            log.warning("ton_address_parse_failed", error=str(e))
            self._wallet_raw = None
        return self._wallet_raw

    async def get_incoming_usdt_transfers(self, *, limit: int = 100) -> list[JettonTransfer]:
        """Recent incoming USDT transfers to our wallet (newest first).

        Returns [] on transport/indexer errors (the poller will retry next tick).
        """
        try:
            data = await self._get(
                f"/v2/accounts/{self._wallet}/jettons/{self._jetton}/history",
                params={"limit": limit},
            )
        except Exception as e:
            log.warning("ton_history_fetch_failed", error=str(e))
            return []

        our_raw = await self._wallet_raw_address()
        out: list[JettonTransfer] = []
        for event in data.get("events", []):
            event_id = event.get("event_id") or ""
            utime = int(event.get("timestamp") or 0)
            for action in event.get("actions", []):
                if action.get("type") != "JettonTransfer":
                    continue
                jt = action.get("JettonTransfer") or {}
                recipient = ((jt.get("recipient") or {}).get("address") or "").lower()
                # Skip outgoing/unrelated when we know our raw address
                if our_raw is not None and recipient and recipient != our_raw:
                    continue
                decimals = int((jt.get("jetton") or {}).get("decimals", USDT_DECIMALS))
                try:
                    amount = Decimal(str(jt.get("amount") or "0")) / (Decimal(10) ** decimals)
                except Exception:
                    continue
                out.append(
                    JettonTransfer(
                        event_id=event_id,
                        sender=((jt.get("sender") or {}).get("address") or ""),
                        amount=amount,
                        comment=jt.get("comment"),
                        utime=utime,
                    )
                )
        return out
