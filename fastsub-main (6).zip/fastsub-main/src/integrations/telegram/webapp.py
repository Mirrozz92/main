"""Validate Telegram Mini App `initData`.

Implements the signature check from the Telegram Mini Apps spec:
    secret_key = HMAC_SHA256(key="WebAppData", msg=bot_token)
    hash       = HMAC_SHA256(key=secret_key, msg=data_check_string)
where data_check_string is the `key=value` pairs (except `hash`), sorted by
key and joined with "\\n". This proves the data came from Telegram for our bot.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from typing import Any
from urllib.parse import parse_qsl

from src.core.logging import get_logger

log = get_logger("telegram.webapp")


def validate_init_data(
    init_data: str,
    bot_token: str,
    *,
    max_age_seconds: int = 86400,
) -> dict[str, Any] | None:
    """Return parsed initData (with `user` as a dict) if valid, else None.

    Args:
        init_data: the raw `Telegram.WebApp.initData` query string.
        bot_token: token of the bot that launched the mini app.
        max_age_seconds: reject if `auth_date` is older than this (0 disables).
    """
    if not init_data:
        return None
    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True))
    except Exception:
        return None

    received_hash = pairs.pop("hash", None)
    if not received_hash:
        return None

    data_check_string = "\n".join(f"{k}={pairs[k]}" for k in sorted(pairs))
    secret_key = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    calc_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()

    if not hmac.compare_digest(calc_hash, received_hash):
        return None

    # Freshness check (anti-replay)
    if max_age_seconds > 0:
        auth_date = pairs.get("auth_date")
        try:
            if auth_date is None or (time.time() - int(auth_date)) > max_age_seconds:
                return None
        except ValueError:
            return None

    out: dict[str, Any] = dict(pairs)
    user_raw = pairs.get("user")
    if user_raw:
        try:
            out["user"] = json.loads(user_raw)
        except Exception:
            return None
    return out
