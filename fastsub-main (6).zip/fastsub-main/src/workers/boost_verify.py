"""Boost verification worker.

Boosts have no chat_member event, so we poll `getUserChatBoosts` every minute:
  - PENDING boost issue + user is boosting        → SUBSCRIBED (start hold)
  - SUBSCRIBED boost issue + user stopped boosting → UNSUBSCRIBED (revert worker
    refunds the advertiser)

This is the source of truth for boost state. The publisher API also does an
opportunistic live check on PENDING boost issues for lower latency, but this
worker guarantees both detection and removal-during-hold.
"""

from __future__ import annotations

from src.core.db import async_session_factory
from src.core.logging import get_logger
from src.domain.issues import BoostVerificationService
from src.integrations.telegram import get_checker_pool
from src.workers.broker import broker

log = get_logger("workers.boost_verify")


@broker.task(
    schedule=[{"cron": "* * * * *"}],
    task_name="poll_boost_issues",
)
async def poll_boost_issues(batch_size: int = 100) -> dict:
    """Poll boost issues and apply detected boost-state changes."""
    # Lazily initialise the checker pool in the worker process (idempotent —
    # the API initialises its own copy in its lifespan).
    pool = get_checker_pool()
    try:
        await pool.initialize()
    except Exception as e:
        log.warning("boost_pool_init_failed", error=str(e))

    async with async_session_factory() as session:
        try:
            svc = BoostVerificationService(session)
            result = await svc.poll_batch(limit=batch_size)
            await session.commit()
        except Exception as e:
            await session.rollback()
            log.error("poll_boost_issues_failed", error=str(e))
            raise

    if result.get("subscribed") or result.get("unsubscribed"):
        log.info("poll_boost_issues", **result)
    return result
