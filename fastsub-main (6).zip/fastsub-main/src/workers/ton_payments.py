"""Poll the TON wallet for incoming USDT and credit matched top-ups.

Runs every minute:
1. Expire pending intents past their deadline.
2. Fetch recent incoming USDT transfers from the indexer.
3. Match them to pending intents by memo, credit the advertiser's balance.
4. Notify each credited advertiser.

No private key is ever held — we only watch the wallet (read-only indexer).
"""

from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import select

from src.core.db import async_session_factory
from src.core.db.models import Advertiser
from src.core.logging import get_logger
from src.domain.payments import PaymentsService, TonTopupRepository
from src.integrations.ton import TonClient
from src.workers.broker import broker

log = get_logger("workers.ton_payments")


@broker.task(
    schedule=[{"cron": "* * * * *"}],
    task_name="poll_ton_payments",
)
async def poll_ton_payments() -> dict[str, int]:
    """Credit any pending USDT top-ups that have arrived on-chain."""
    notifications: list[tuple[int | None, str, str, str]] = []
    credited_count = 0

    async with async_session_factory() as session:
        try:
            svc = PaymentsService(session)
            await svc.expire_ton_topups()

            ton_repo = TonTopupRepository(session)
            pending = await ton_repo.list_pending_active(now=datetime.now(UTC))
            if not pending:
                await session.commit()
                return {"pending": 0, "credited": 0}

            async with TonClient() as ton:
                transfers = await ton.get_incoming_usdt_transfers(limit=100)

            credited = await svc.match_ton_transfers(pending, transfers)
            credited_count = len(credited)

            if credited:
                adv_ids = [t.advertiser_id for t in credited]
                rows = await session.execute(
                    select(Advertiser.id, Advertiser.tg_user_id).where(
                        Advertiser.id.in_(adv_ids)
                    )
                )
                tg_by_id: dict[int, int] = {r[0]: r[1] for r in rows.all()}
                notifications = [
                    (tg_by_id.get(t.advertiser_id), str(t.amount_rub), str(t.paid_usdt or ""), t.memo)
                    for t in credited
                ]

            await session.commit()
        except Exception as e:
            await session.rollback()
            log.error("poll_ton_payments_failed", error=str(e))
            raise

    # Fire notifications outside the DB transaction.
    # Imported lazily to avoid a circular import at task-registration time
    # (notifications → broker → _register_tasks → ton_payments).
    from src.workers.notifications import notify_ton_topup_success

    for tg_id, amount_rub, paid_usdt, memo in notifications:
        if tg_id is not None:
            await notify_ton_topup_success.kiq(
                tg_user_id=tg_id,
                amount_rub=amount_rub,
                paid_usdt=paid_usdt,
                memo=memo,
            )

    if credited_count:
        log.info("ton_poll_credited", count=credited_count)
    return {"pending": len(notifications), "credited": credited_count}
