"""Telegram Mini App: «Интеграция» — unified API docs for the profile.

Launched from the Profile «Интеграция» button (account-level, no bot needed).
Auth is by Telegram `initData` (validated against the main bot token). The page
has three tabs — Advertiser API, Publisher API, Webhooks — and injects the real
keys for whichever roles the user has, with copy + regenerate. It also shows the
user's live balances so they can see their account state at a glance.

Routes (hidden from the public OpenAPI schema):
  GET  /app/integration               — the mini-app HTML page
  POST /app/integration/api/context   — {init_data} → roles, keys, balances, base
  POST /app/integration/api/regenerate— {init_data, role, bot_id?} → {key}
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.dependencies import get_session
from src.core.config import get_settings
from src.core.logging import get_logger
from src.domain.advertiser_tokens import AdvertiserTokenService
from src.domain.advertisers import AdvertiserRepository
from src.domain.api_tokens import ApiTokenService
from src.domain.publisher_bots import PublisherBotRepository
from src.domain.publishers import PublisherRepository
from src.integrations.telegram.webapp import validate_init_data

router = APIRouter(tags=["miniapp"])
log = get_logger("api.integration_app")


class ContextRequest(BaseModel):
    init_data: str


class RegenerateRequest(BaseModel):
    init_data: str
    role: str
    bot_id: int | None = None


def _resolve_tg_id(init_data: str) -> int:
    settings = get_settings()
    data = validate_init_data(init_data, settings.main_bot_token.get_secret_value())
    if data is None or not isinstance(data.get("user"), dict):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid init data")
    tg_id = data["user"].get("id")
    if tg_id is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="no user in init data")
    return int(tg_id)


async def _advertiser_block(tg_id: int, session: AsyncSession) -> dict[str, Any] | None:
    adv = await AdvertiserRepository(session).get_by_tg_id(tg_id)
    if adv is None or adv.is_banned:
        return None
    key = await AdvertiserTokenService(session).ensure_plaintext_for_advertiser(advertiser_id=adv.id)
    return {
        "key": key,
        "username": adv.tg_username,
        "balance_rub": str(adv.balance_rub),
        "reserved_rub": str(adv.reserved_rub),
        "total_spent_rub": str(adv.total_spent_rub),
    }


async def _publisher_block(tg_id: int, session: AsyncSession) -> dict[str, Any] | None:
    pub = await PublisherRepository(session).get_by_tg_id(tg_id)
    if pub is None or pub.is_banned:
        return None
    bots = await PublisherBotRepository(session).list_for_publisher(pub.id)
    tok_svc = ApiTokenService(session)
    bot_list: list[dict[str, Any]] = []
    for bot in bots:
        key = await tok_svc.ensure_plaintext_for_bot(publisher_id=pub.id, publisher_bot_id=bot.id)
        bot_list.append({"id": bot.id, "name": bot.name, "key": key, "active": bot.is_active})
    return {
        "balance_rub": str(pub.balance_rub),
        "hold_rub": str(pub.hold_rub),
        "total_earned_rub": str(pub.total_earned_rub),
        "bots": bot_list,
    }


@router.post("/app/integration/api/context", include_in_schema=False)
async def integration_context(
    req: ContextRequest, session: AsyncSession = Depends(get_session)
) -> dict[str, Any]:
    tg_id = _resolve_tg_id(req.init_data)
    advertiser = await _advertiser_block(tg_id, session)
    publisher = await _publisher_block(tg_id, session)
    if advertiser is None and publisher is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Вы ещё не зарегистрированы. Откройте бота и пройдите /start.",
        )
    return {
        "base": get_settings().public_base_url.rstrip("/"),
        "advertiser": advertiser,
        "publisher": publisher,
    }


@router.post("/app/integration/api/regenerate", include_in_schema=False)
async def integration_regenerate(
    req: RegenerateRequest, session: AsyncSession = Depends(get_session)
) -> dict[str, Any]:
    tg_id = _resolve_tg_id(req.init_data)
    if req.role == "advertiser":
        adv = await AdvertiserRepository(session).get_by_tg_id(tg_id)
        if adv is None or adv.is_banned:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="advertiser not found")
        result = await AdvertiserTokenService(session).regenerate_for_advertiser(
            advertiser_id=adv.id, label="Integration"
        )
        return {"key": result.plaintext}
    if req.role == "publisher":
        pub = await PublisherRepository(session).get_by_tg_id(tg_id)
        if pub is None or pub.is_banned:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="publisher not found")
        bot = await PublisherBotRepository(session).get_by_id(req.bot_id or 0)
        if bot is None or bot.publisher_id != pub.id:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="bot not found")
        result = await ApiTokenService(session).regenerate_for_bot(
            publisher_id=pub.id, publisher_bot_id=bot.id, label="Integration"
        )
        return {"key": result.plaintext}
    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="unknown role")


@router.get("/app/integration", response_class=HTMLResponse, include_in_schema=False)
async def integration_page() -> HTMLResponse:
    return HTMLResponse(_PAGE)


_PAGE = r"""<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Интеграция</title>
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<style>
  :root{
    --bg:#0b0b0f; --glass:rgba(255,255,255,.06); --text:#f1f2f6; --hint:#8a8f9c;
    --accent:#4d8bff; --green:#30d158; --gold:#ffb86b; --hair:rgba(255,255,255,.08);
    --sans:-apple-system,"SF Pro Text",system-ui,"Segoe UI",Roboto,sans-serif;
    --mono:ui-monospace,"SF Mono",Menlo,Consolas,monospace;
  }
  *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
  body{margin:0;background:var(--bg);color:var(--text);font-family:var(--sans);
    padding:env(safe-area-inset-top) 0 calc(env(safe-area-inset-bottom) + 28px);
    -webkit-font-smoothing:antialiased}
  body::before{content:"";position:fixed;inset:0;z-index:-1;pointer-events:none;
    background:radial-gradient(620px 360px at 50% -6%, rgba(77,139,255,.16), transparent 70%)}
  .wrap{max-width:640px;margin:0 auto;padding:16px 14px}
  h1{font-size:27px;font-weight:680;letter-spacing:-.5px;margin:8px 4px 2px}
  .sub{color:var(--hint);font-size:14px;margin:0 4px 16px;font-weight:500}
  .glass{background:var(--glass);border:1px solid rgba(255,255,255,.10);
    box-shadow:0 10px 30px rgba(0,0,0,.4),inset 0 1px 0 rgba(255,255,255,.08);
    backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px)}
  .card{border-radius:22px;padding:16px}
  /* segmented control */
  .seg{display:flex;gap:4px;background:rgba(255,255,255,.06);border:1px solid var(--hair);
    border-radius:14px;padding:4px;margin:0 0 18px;position:sticky;top:8px;z-index:5;
    backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px)}
  .seg button{flex:1;border:none;background:transparent;color:var(--hint);font-family:var(--sans);
    font-weight:650;font-size:13px;padding:10px 6px;border-radius:11px;cursor:pointer;transition:.18s}
  .seg button.on{background:linear-gradient(180deg,rgba(255,255,255,.16),rgba(255,255,255,.08));
    color:var(--text);box-shadow:0 4px 12px rgba(0,0,0,.4)}
  .panel{display:none} .panel.on{display:block;animation:fade .22s ease}
  @keyframes fade{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
  .sec-title{font-size:13px;color:var(--hint);text-transform:uppercase;letter-spacing:.5px;
    font-weight:600;margin:24px 14px 9px}
  /* balance stats */
  .stats{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:4px}
  .stat{border-radius:18px;padding:14px 12px;text-align:center}
  .stat .v{font-size:19px;font-weight:740;letter-spacing:-.3px}
  .stat .l{font-size:11px;color:var(--hint);margin-top:3px;font-weight:560}
  .stat.green .v{color:var(--green)} .stat.gold .v{color:var(--gold)}
  /* key */
  .keyhead{display:flex;align-items:center;justify-content:space-between;margin-bottom:11px}
  .keyhead .t{font-size:13px;color:var(--hint);text-transform:uppercase;letter-spacing:.5px;font-weight:600}
  .keyhead .regen{font-size:13px;color:var(--accent);font-weight:600;background:none;border:none;
    cursor:pointer;font-family:var(--sans);padding:4px}
  .keyrow{display:flex;align-items:center;gap:10px}
  .keyval{flex:1;min-width:0;font-family:var(--mono);font-size:13.5px;letter-spacing:-.2px;
    background:rgba(0,0,0,.28);border:1px solid var(--hair);border-radius:13px;padding:13px 14px;
    overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .btn{flex:none;display:inline-flex;align-items:center;gap:7px;border:none;cursor:pointer;
    font-family:var(--sans);font-weight:650;font-size:14px;border-radius:13px;padding:12px 15px;
    background:var(--accent);color:#fff;box-shadow:0 6px 18px rgba(77,139,255,.4)}
  .btn:active{transform:scale(.96)} .btn.ok{background:var(--green);box-shadow:0 6px 18px rgba(48,209,88,.4)}
  .btn svg{width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:2.3;stroke-linecap:round;stroke-linejoin:round}
  .lead{color:var(--hint);font-size:13.5px;line-height:1.5;margin:11px 4px 0}
  /* bot selector */
  .bots{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:12px}
  .botpill{border:1px solid var(--hair);background:rgba(255,255,255,.05);color:var(--hint);
    font-family:var(--sans);font-weight:600;font-size:12.5px;padding:7px 12px;border-radius:11px;cursor:pointer}
  .botpill.on{background:rgba(77,139,255,.16);border-color:rgba(77,139,255,.4);color:#cfe0ff}
  /* endpoints */
  .ep{display:flex;align-items:center;gap:10px;margin-bottom:9px;flex-wrap:wrap}
  .m{font-weight:800;font-size:11px;padding:4px 9px;border-radius:8px;letter-spacing:.4px}
  .m.get{background:rgba(48,209,88,.16);color:#5ee08a}
  .m.post{background:rgba(77,139,255,.18);color:#8fb4ff}
  .path{font-family:var(--mono);font-size:14px;font-weight:600}
  .desc{color:var(--hint);font-size:13.5px;line-height:1.5;margin:0 0 11px}
  .code{position:relative;background:rgba(0,0,0,.32);border:1px solid var(--hair);
    border-radius:14px;padding:13px 14px;margin-top:11px}
  pre{margin:0;overflow-x:auto;font-family:var(--mono);font-size:12.5px;line-height:1.55;
    color:#e6e9f2;white-space:pre;-webkit-overflow-scrolling:touch}
  pre .s{color:#7ee0a3} pre .o{color:#ffb86b} pre .f{color:#8fb4ff}
  pre.lang[hidden]{display:none}
  .tabs{display:inline-flex;gap:4px;background:rgba(255,255,255,.06);border-radius:11px;padding:3px;margin-top:12px}
  .tab{border:none;background:transparent;color:var(--hint);font-family:var(--sans);font-weight:600;
    font-size:12.5px;padding:6px 13px;border-radius:9px;cursor:pointer}
  .tab.on{background:rgba(255,255,255,.15);color:var(--text);box-shadow:0 3px 10px rgba(0,0,0,.4)}
  .cp{position:absolute;top:9px;right:9px;background:rgba(255,255,255,.10);border:1px solid var(--hair);
    color:var(--hint);font-family:var(--sans);font-size:11px;font-weight:600;border-radius:9px;padding:5px 9px;cursor:pointer}
  .cp:active{background:rgba(255,255,255,.18)}
  .params{margin:8px 0 0;border-collapse:collapse;width:100%;font-size:13px}
  .params td{padding:7px 8px;border-top:.5px solid var(--hair);vertical-align:top}
  .params td:first-child{font-family:var(--mono);font-size:12.5px;white-space:nowrap;color:#cfe0ff}
  .params .req{color:#ff8f8f;font-size:11px;font-weight:600;margin-left:5px}
  table.ev{border-collapse:collapse;width:100%;font-size:13px;margin-top:4px}
  table.ev td{padding:8px;border-top:.5px solid var(--hair);vertical-align:top}
  table.ev td:first-child{font-family:var(--mono);font-size:12px;color:#cfe0ff;white-space:nowrap}
  .empty{text-align:center;color:var(--hint);padding:46px 22px;font-size:14.5px;line-height:1.55}
  .msg{display:none;text-align:center;color:var(--hint);padding:54px 20px;font-size:15px;line-height:1.5}
</style>
</head>
<body>
<svg width="0" height="0" style="position:absolute" aria-hidden="true">
  <symbol id="i-copy" viewBox="0 0 24 24"><rect x="9" y="9" width="11" height="11" rx="2.4"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></symbol>
</svg>

<div class="wrap">
  <h1>Интеграция</h1>
  <div class="sub">API вашего аккаунта — ключи, методы, вебхуки</div>

  <div id="content" style="display:none">
    <div class="seg" id="seg">
      <button data-tab="adv" class="on">Advertiser API</button>
      <button data-tab="pub">Publisher API</button>
      <button data-tab="wh">Webhooks</button>
    </div>
    <div class="panel on" id="p-adv"></div>
    <div class="panel" id="p-pub"></div>
    <div class="panel" id="p-wh"></div>
  </div>

  <div class="msg" id="msg">Загрузка…</div>
</div>

<script>
const tg = window.Telegram ? window.Telegram.WebApp : null;
if (tg){ tg.ready(); tg.expand(); try{ tg.setHeaderColor("#0b0b0f"); tg.setBackgroundColor("#0b0b0f"); }catch(e){} }
const initData = tg ? tg.initData : "";
const params = new URLSearchParams(location.search);
const START_TAB = params.get("tab");
const START_BOT = parseInt(params.get("bot_id") || (tg && tg.initDataUnsafe && tg.initDataUnsafe.start_param) || "0") || null;

let BASE = "", CTX = null, PUB_BOT = null;

const ADV_EPS = [
  { group:"Аккаунт", items:[
    { m:"GET", p:"/api/v1/advertiser/me", d:"Ваш аккаунт: баланс, резерв, потрачено, число кампаний." },
    { m:"GET", p:"/api/v1/advertiser/campaigns", d:"Список ваших кампаний со статусами, бюджетами и подписчиками.",
      params:[["limit","","Размер страницы (1–100, по умолчанию 50)"],["offset","","Сколько пропустить"]], q:"?limit=50" },
    { m:"GET", p:"/api/v1/advertiser/stats", d:"Расходы и купленные подписки за период, с разбивкой по времени.",
      params:[["from / to","","Период (ISO-8601), по умолчанию 30 дней"],["bucket","","day | week | month"]], q:"?bucket=day" },
  ]},
  { group:"Задания (bot-start)", items:[
    { m:"POST", p:"/api/v1/advertiser/confirm-start", d:"Подтвердить запуск вашего бота юзером. Вызывайте из обработчика /start, когда payload начинается с fastsub_.",
      params:[["start_param","req","Payload, который получил ваш бот (fastsub_lnk_…)"],["user_id","req","Telegram id юзера, запустившего бота"]],
      body:'{"start_param": "fastsub_lnk_a1b2c3d4", "user_id": 123456789}' },
  ]},
];

const PUB_EPS = [
  { group:"Задания", items:[
    { m:"POST", p:"/api/v1/request-op", d:"Выдать юзеру пачку спонсорских заданий (каналы/боты для подписки).",
      params:[["user_id","req","Telegram id пользователя"],["count","","Сколько заданий вернуть"]], body:'{"user_id": 123456789, "count": 3}' },
    { m:"POST", p:"/api/v1/check-resource", d:"Проверить статус одного выданного ресурса.",
      params:[["link_id","req","Идентификатор ресурса из request-op"]], body:'{"link_id": "lnk_0a1b2c3d"}' },
    { m:"POST", p:"/api/v1/check-task", d:"Проверить статусы всех ресурсов одного задания разом.",
      params:[["task_id","req","Идентификатор задания из request-op"]], body:'{"task_id": "tsk_a1b2c3d4e5f6"}' },
    { m:"GET", p:"/api/v1/user/{user_id}/history", d:"История заданий конкретного пользователя.",
      params:[["limit","","1–100, по умолчанию 50"],["offset","","Сколько пропустить"]], q:"?limit=50&offset=0" },
  ]},
  { group:"Аккаунт и статистика", items:[
    { m:"GET", p:"/api/v1/me", d:"Информация о вашем аккаунте и активном ключе." },
    { m:"GET", p:"/api/v1/stats/summary", d:"KPI-сводка (заработок, подписки, retention) с динамикой.", q:"?from=2026-05-01T00:00:00Z" },
    { m:"GET", p:"/api/v1/stats/timeseries", d:"Ряды по времени для графиков.",
      params:[["bucket","","day | week | month"]], q:"?bucket=day" },
    { m:"GET", p:"/api/v1/stats/resources", d:"Разбивка заработка и подписок по ресурсам." },
  ]},
];

const LANGS = [["curl","curl"],["py","Python"],["js","JS"]];
function exPath(e){ return e.p.replace("{user_id}", "123456789"); }
function genCurl(e){
  if (e.m === "GET") return `curl "{BASE}${exPath(e)}${e.q||""}" \\
  -H "Authorization: Bearer {KEY}"`;
  return `curl -X POST {BASE}${exPath(e)} \\
  -H "Authorization: Bearer {KEY}" \\
  -H "Content-Type: application/json" \\
  -d '${e.body}'`;
}
function genPy(e){
  if (e.m === "GET") return `import requests

r = requests.get(
    "{BASE}${exPath(e)}${e.q||""}",
    headers={"Authorization": "Bearer {KEY}"},
)
print(r.json())`;
  return `import requests

r = requests.post(
    "{BASE}${exPath(e)}",
    headers={"Authorization": "Bearer {KEY}"},
    json=${e.body},
)
print(r.json())`;
}
function genJs(e){
  if (e.m === "GET") return `const r = await fetch("{BASE}${exPath(e)}${e.q||""}", {
  headers: { "Authorization": "Bearer {KEY}" },
});
console.log(await r.json());`;
  return `const r = await fetch("{BASE}${exPath(e)}", {
  method: "POST",
  headers: {
    "Authorization": "Bearer {KEY}",
    "Content-Type": "application/json",
  },
  body: JSON.stringify(${e.body}),
});
console.log(await r.json());`;
}
function mkExamples(e){ return { curl: genCurl(e), py: genPy(e), js: genJs(e) }; }
function esc(s){ return (s||"").replace(/[&<>]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;"}[c])); }
function hl(code){
  return esc(code)
    .replace(/('[^']*'|"[^"]*")/g, m => '<span class="s">'+m+'</span>')
    .replace(/\b(import|from|const|await|async|return|def|None|true|false|null|method|headers|body)\b/g, '<span class="o">$1</span>')
    .replace(/\b(curl|requests|fetch|print|console|JSON)\b/g, '<span class="f">$1</span>');
}
function fill(s, key){ return s.replace(/\{BASE\}/g, BASE).replace(/\{KEY\}/g, key); }

function epsHtml(groups, key){
  let h = "";
  for (const g of groups){
    if (g.group) h += '<div class="sec-title" style="margin-left:14px">'+esc(g.group)+'</div>';
    for (const e of g.items){
      let pr = "";
      if (e.params && e.params.length){
        pr = '<table class="params">';
        for (const [n, req, d] of e.params)
          pr += '<tr><td>'+esc(n)+(req?'<span class="req">required</span>':'')+'</td><td style="color:var(--hint)">'+esc(d)+'</td></tr>';
        pr += '</table>';
      }
      const ex = mkExamples(e);
      let tabs = '<div class="tabs">', code = '<div class="code"><button class="cp" data-cp>копировать</button>';
      LANGS.forEach(([k, label], i) => {
        tabs += '<button class="tab'+(i===0?' on':'')+'" data-lang="'+k+'">'+esc(label)+'</button>';
        code += '<pre class="lang'+(i===0?' on':'')+'" data-lang="'+k+'"'+(i===0?'':' hidden')+'>'+hl(fill(ex[k], key))+'</pre>';
      });
      tabs += '</div>'; code += '</div>';
      h += '<div class="card glass" style="margin-bottom:11px">'+
           '<div class="ep"><span class="m '+e.m.toLowerCase()+'">'+e.m+'</span><span class="path">'+esc(e.p)+'</span></div>'+
           '<div class="desc">'+esc(e.d)+'</div>'+ pr + tabs + code + '</div>';
    }
  }
  return h;
}

function keyCard(role){
  return '<div class="card glass">'+
    '<div class="keyhead"><span class="t">API-ключ</span>'+
    '<button class="regen" data-regen="'+role+'">Перевыпустить</button></div>'+
    '<div class="keyrow"><div class="keyval" id="kv-'+role+'">—</div>'+
    '<button class="btn" data-copykey="'+role+'"><svg><use href="#i-copy"/></svg><span>Копировать</span></button></div>'+
    '<div class="lead">Передавайте в заголовке <span style="font-family:var(--mono);color:#cfe0ff">Authorization: Bearer …</span>. '+
    'Перевыпуск мгновенно отключает старый ключ.</div></div>';
}
function baseCard(){
  return '<div class="sec-title">Базовый URL</div><div class="card glass"><div class="code">'+
    '<button class="cp" data-cp></button><pre>'+esc(BASE)+'</pre></div></div>';
}
function statCard(items){
  let s = '<div class="stats">';
  for (const [v, l, cls] of items) s += '<div class="stat glass '+(cls||'')+'"><div class="v">'+esc(v)+'</div><div class="l">'+esc(l)+'</div></div>';
  return s + '</div>';
}
function money(x){ return (Math.round(parseFloat(x||"0")*100)/100).toLocaleString("ru-RU") + " ₽"; }

function renderAdv(){
  const a = CTX.advertiser, el = document.getElementById("p-adv");
  if (!a){ el.innerHTML = '<div class="empty">Вы ещё не рекламодатель.<br>Откройте «Купить трафик» в боте, чтобы создать первую кампанию.</div>'; return; }
  el.innerHTML =
    statCard([[money(a.balance_rub),"Баланс"],[money(a.reserved_rub),"Резерв","gold"],[money(a.total_spent_rub),"Потрачено","green"]])+
    '<div class="sec-title">Ключ рекламодателя</div>'+ keyCard("advertiser")+ baseCard()+
    '<div class="sec-title">Методы</div>'+ epsHtml(ADV_EPS, a.key);
  document.getElementById("kv-advertiser").textContent = a.key;
  wire(el);
}

function renderPub(){
  const p = CTX.publisher, el = document.getElementById("p-pub");
  if (!p){ el.innerHTML = '<div class="empty">Вы ещё не паблишер.<br>Откройте «Продать трафик» в боте и подключите своего бота.</div>'; return; }
  if (!PUB_BOT && p.bots.length){ PUB_BOT = (START_BOT && p.bots.find(b=>b.id===START_BOT)) ? START_BOT : p.bots[0].id; }
  const bot = p.bots.find(b => b.id === PUB_BOT) || p.bots[0];
  let sel = "";
  if (p.bots.length > 1){
    sel = '<div class="sec-title">Бот</div><div class="bots">';
    for (const b of p.bots) sel += '<button class="botpill'+(b.id===bot.id?' on':'')+'" data-bot="'+b.id+'">'+esc(b.name)+'</button>';
    sel += '</div>';
  }
  el.innerHTML =
    statCard([[money(p.balance_rub),"Баланс","green"],[money(p.hold_rub),"Холд","gold"],[money(p.total_earned_rub),"Заработано"]])+
    sel + '<div class="sec-title">Ключ бота'+(bot?' — '+esc(bot.name):'')+'</div>'+ keyCard("publisher")+ baseCard()+
    '<div class="sec-title">Методы</div>'+ epsHtml(PUB_EPS, bot ? bot.key : "fsp_live_xxx");
  document.getElementById("kv-publisher").textContent = bot ? bot.key : "—";
  wire(el);
}

function renderWh(){
  const el = document.getElementById("p-wh");
  const key = (CTX.publisher && CTX.publisher.bots[0] && CTX.publisher.bots[0].key) || "fsp_live_xxx";
  const cfg = { m:"POST", p:"/api/v1/webhook/configure", d:"Указать URL, куда мы шлём события подписок/отписок. Секрет выдаётся один раз в ответе.",
    params:[["url","req","HTTPS-адрес вашего обработчика"]], body:'{"url": "https://example.com/fastsub/webhook"}' };
  const get = { m:"GET", p:"/api/v1/webhook", d:"Текущая конфигурация вебхука." };
  const events = [
    ["resource.subscribed","Юзер подписался (идёт hold)"],
    ["resource.verified","Подтверждено, вознаграждение начислено"],
    ["resource.unsubscribed","Юзер отписался"],
    ["resource.expired","TTL вышел без подписки"],
    ["resource.reverted","Финальная отмена после отписки"],
  ];
  let evt = '<table class="ev">';
  for (const [e, d] of events) evt += '<tr><td>'+esc(e)+'</td><td style="color:var(--hint)">'+esc(d)+'</td></tr>';
  evt += '</table>';
  const payload = `{
  "event": "resource.verified",
  "link_id": "lnk_a1b2c3d4e5f6",
  "user_id": 123456789,
  "status": "verified",
  "reward_rub": "1.5000",
  "timestamp": "2026-05-23T18:04:11Z"
}`;
  const verifyPy = `import hmac, hashlib

def verify(body, signature, secret):
    expected = hmac.new(
        secret.encode(), body, hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature)`;
  el.innerHTML =
    '<div class="card glass"><div class="desc" style="margin:0">FastSub шлёт события об изменении статуса подписок на ваш сервер — '+
    'вместо постоянного опроса. Каждый запрос подписан заголовком '+
    '<span style="font-family:var(--mono);color:#cfe0ff">X-FastSub-Signature</span> (HMAC-SHA256). Отвечайте 2xx, иначе доставка повторится.</div></div>'+
    '<div class="sec-title">Настройка</div>'+ epsHtml([{group:"", items:[cfg, get]}], key)+
    '<div class="sec-title">События</div><div class="card glass">'+evt+'</div>'+
    '<div class="sec-title">Пример payload</div><div class="card glass"><div class="code">'+
    '<button class="cp" data-cp></button><pre>'+hl(payload)+'</pre></div></div>'+
    '<div class="sec-title">Проверка подписи</div><div class="card glass"><div class="code">'+
    '<button class="cp" data-cp></button><pre>'+hl(verifyPy)+'</pre></div></div>';
  // strip the leading empty sec-title produced by group:""
  wire(el);
}

function wire(scope){
  scope.querySelectorAll(".tabs .tab").forEach(t => t.addEventListener("click", () => {
    const card = t.closest(".card"), lang = t.dataset.lang;
    card.querySelectorAll(".tabs .tab").forEach(x => x.classList.toggle("on", x === t));
    card.querySelectorAll("pre.lang").forEach(p => { const on = p.dataset.lang === lang; p.classList.toggle("on", on); p.hidden = !on; });
  }));
  scope.querySelectorAll("[data-cp]").forEach(b => b.addEventListener("click", () => {
    const c = b.closest(".card"); const pre = c.querySelector("pre.lang.on") || c.querySelector("pre");
    if (pre) copy(pre.innerText, b, "скопировано");
  }));
  scope.querySelectorAll("[data-copykey]").forEach(b => b.addEventListener("click", () => {
    const role = b.dataset.copykey; const v = document.getElementById("kv-"+role).textContent;
    copy(v, b.querySelector("span"), "Скопировано"); b.classList.add("ok"); setTimeout(()=>b.classList.remove("ok"),1400);
  }));
  scope.querySelectorAll("[data-regen]").forEach(b => b.addEventListener("click", () => regen(b.dataset.regen, b)));
  scope.querySelectorAll("[data-bot]").forEach(b => b.addEventListener("click", () => { PUB_BOT = parseInt(b.dataset.bot); renderPub(); }));
}

function copy(text, btn, okText){
  const done = () => { if (btn){ const t=btn.textContent; btn.textContent = okText||"✓"; setTimeout(()=>btn.textContent=t,1400);} if (tg&&tg.HapticFeedback) tg.HapticFeedback.notificationOccurred("success"); };
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, ()=>fb(text,done)); else fb(text,done);
}
function fb(text, done){ const ta=document.createElement("textarea"); ta.value=text; ta.style.position="fixed"; ta.style.opacity="0"; document.body.appendChild(ta); ta.select(); try{document.execCommand("copy"); done();}catch(e){} document.body.removeChild(ta); }

async function apiPost(path, extra){
  const r = await fetch(path, { method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify(Object.assign({ init_data: initData }, extra||{})) });
  if (!r.ok) throw new Error("http "+r.status);
  return r.json();
}

function regen(role, btn){
  const q = "Перевыпустить ключ? Старый сразу перестанет работать.";
  const go = () => {
    btn.textContent = "…";
    const extra = role === "publisher" ? { role, bot_id: PUB_BOT } : { role };
    apiPost("/app/integration/api/regenerate", extra).then(d => {
      if (role === "advertiser"){ CTX.advertiser.key = d.key; renderAdv(); }
      else { const b = CTX.publisher.bots.find(x=>x.id===PUB_BOT); if (b) b.key = d.key; renderPub(); }
    }).catch(()=>{ btn.textContent = "Ошибка"; setTimeout(()=>btn.textContent="Перевыпустить",1600); });
  };
  if (tg && tg.showConfirm) tg.showConfirm(q, ok => { if (ok) go(); }); else if (confirm(q)) go();
}

function showTab(tab){
  document.querySelectorAll("#seg button").forEach(b => b.classList.toggle("on", b.dataset.tab===tab));
  document.querySelectorAll(".panel").forEach(p => p.classList.toggle("on", p.id==="p-"+tab));
  if (tg && tg.HapticFeedback) tg.HapticFeedback.selectionChanged();
}
document.querySelectorAll("#seg button").forEach(b => b.addEventListener("click", () => showTab(b.dataset.tab)));

function showMsg(t){ const m=document.getElementById("msg"); m.textContent=t; m.style.display=""; document.getElementById("content").style.display="none"; }

async function boot(){
  if (!initData){ showMsg("Откройте эту страницу через кнопку «Интеграция» в боте FastSub."); return; }
  try{
    CTX = await apiPost("/app/integration/api/context");
    BASE = CTX.base;
    renderAdv(); renderPub(); renderWh();
    document.getElementById("msg").style.display = "none";
    document.getElementById("content").style.display = "";
    // default tab: prefer ?tab=, else the role the user actually has
    let tab = START_TAB;
    if (!tab) tab = CTX.advertiser ? "adv" : (CTX.publisher ? "pub" : "wh");
    if (tab === "publisher") tab = "pub"; if (tab === "advertiser") tab = "adv"; if (tab === "webhooks") tab = "wh";
    showTab(tab);
  } catch(e){ showMsg("Не удалось загрузить. Попробуйте переоткрыть из бота."); }
}
boot();
</script>
</body>
</html>"""
