"""GET /api/v1/stats — aggregated task counters for the authenticated publisher."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.dependencies import (
    get_current_publisher,
    get_current_publisher_bot,
    get_session,
)
from src.api.rate_limit import stats_limit
from src.api.v1.schemas import (
    DemographicsResponse,
    DemographicSliceSchema,
    ResourcesResponse,
    ResourceStatSchema,
    StatsResponse,
    SummaryResponse,
    TimeseriesPointSchema,
    TimeseriesResponse,
    build_stats,
)
from src.core.db.models import Publisher, PublisherBot
from src.core.logging import get_logger
from src.domain.issues import ResourceIssueRepository
from src.domain.stats import StatsRepository

router = APIRouter(prefix="/api/v1", tags=["publishers"])
log = get_logger("api.stats")

DEFAULT_WINDOW_DAYS = 30


def _as_utc(dt: datetime) -> datetime:
    """Treat tz-naive input as UTC; the DB stores tz-aware timestamps."""
    return dt if dt.tzinfo is not None else dt.replace(tzinfo=UTC)


@router.get(
    "/stats",
    response_model=StatsResponse,
    summary="Aggregated counters for your account",
    description=(
        "Returns issued-task counts per status plus earned/in-hold payouts for "
        "the authenticated publisher, aggregated by `issued_at` over a window.\n\n"
        "**Window**: pass `from` and/or `to` (ISO-8601). Defaults to the last "
        f"{DEFAULT_WINDOW_DAYS} days. Counts cover all of the publisher's bots.\n\n"
        "**Rate limit**: 60 requests per minute per token."
    ),
)
async def stats(
    from_: datetime | None = Query(
        default=None, alias="from", description="Window start (ISO-8601). Default: to - 30d."
    ),
    to: datetime | None = Query(
        default=None, description="Window end (ISO-8601). Default: now."
    ),
    publisher: Publisher = Depends(get_current_publisher),
    publisher_bot: PublisherBot = Depends(get_current_publisher_bot),
    session: AsyncSession = Depends(get_session),
    _rate_limit: None = Depends(stats_limit),
) -> StatsResponse:
    now = datetime.now(UTC)
    period_to = _as_utc(to) if to is not None else now
    period_from = _as_utc(from_) if from_ is not None else period_to - timedelta(days=DEFAULT_WINDOW_DAYS)

    if period_from > period_to:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="`from` must be earlier than or equal to `to`",
        )

    repo = ResourceIssueRepository(session)
    rows = await repo.aggregate_for_publisher(
        publisher_id=publisher.id,
        since=period_from,
        until=period_to,
    )
    str_rows = [(s.value, count, payout, bonus) for s, count, payout, bonus in rows]

    log.info(
        "stats_called",
        publisher_id=publisher.id,
        period_from=period_from.isoformat(),
        period_to=period_to.isoformat(),
    )

    return build_stats(str_rows, period_from=period_from, period_to=period_to)


# --- Analytics endpoints (dashboards / publisher self-serve) ---


def _resolve_window(
    from_: datetime | None, to: datetime | None
) -> tuple[datetime, datetime]:
    now = datetime.now(UTC)
    period_to = _as_utc(to) if to is not None else now
    period_from = _as_utc(from_) if from_ is not None else period_to - timedelta(days=DEFAULT_WINDOW_DAYS)
    if period_from > period_to:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="`from` must be earlier than or equal to `to`",
        )
    return period_from, period_to


async def _ensure_bot_scope(
    repo: StatsRepository, publisher_id: int, bot_id: int | None
) -> None:
    if bot_id is not None and not await repo.bot_belongs_to_publisher(
        publisher_id=publisher_id, bot_id=bot_id
    ):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="bot not found for this account",
        )


@router.get(
    "/stats/summary",
    response_model=SummaryResponse,
    summary="KPI summary with growth vs the previous period",
    description=(
        "Earned, subscriptions, unsubscribes, retention% and churn for the window, "
        "each compared against the immediately preceding window of equal length. "
        "Optionally scope to one of your bots with `bot_id`."
    ),
)
async def stats_summary(
    from_: datetime | None = Query(default=None, alias="from"),
    to: datetime | None = Query(default=None),
    bot_id: int | None = Query(default=None, description="Limit to one of your bots"),
    publisher: Publisher = Depends(get_current_publisher),
    session: AsyncSession = Depends(get_session),
    _rate_limit: None = Depends(stats_limit),
) -> SummaryResponse:
    period_from, period_to = _resolve_window(from_, to)
    repo = StatsRepository(session)
    await _ensure_bot_scope(repo, publisher.id, bot_id)
    s = await repo.summary(
        publisher_id=publisher.id, since=period_from, until=period_to, bot_id=bot_id
    )
    return SummaryResponse(
        period_from=s.period_from,
        period_to=s.period_to,
        bot_id=bot_id,
        earned_rub=s.earned_rub,
        earned_growth_pct=s.earned_growth_pct,
        subs=s.subs,
        subs_growth_pct=s.subs_growth_pct,
        unsubs=s.unsubs,
        unsubs_growth_pct=s.unsubs_growth_pct,
        issued=s.issued,
        retention_pct=s.retention_pct,
        churn_ratio=s.churn_ratio,
    )


@router.get(
    "/stats/timeseries",
    response_model=TimeseriesResponse,
    summary="Time-bucketed series for charts",
    description=(
        "Per-bucket earned / subscriptions / unsubscribes / issued over the window. "
        "`bucket` is day, week or month. Gaps are zero-filled. Optional `bot_id`."
    ),
)
async def stats_timeseries(
    from_: datetime | None = Query(default=None, alias="from"),
    to: datetime | None = Query(default=None),
    bucket: Literal["day", "week", "month"] = Query(default="day"),
    bot_id: int | None = Query(default=None),
    publisher: Publisher = Depends(get_current_publisher),
    session: AsyncSession = Depends(get_session),
    _rate_limit: None = Depends(stats_limit),
) -> TimeseriesResponse:
    period_from, period_to = _resolve_window(from_, to)
    repo = StatsRepository(session)
    await _ensure_bot_scope(repo, publisher.id, bot_id)
    points = await repo.timeseries(
        publisher_id=publisher.id,
        since=period_from,
        until=period_to,
        bucket=bucket,
        bot_id=bot_id,
    )
    return TimeseriesResponse(
        period_from=period_from,
        period_to=period_to,
        bucket=bucket,
        points=[TimeseriesPointSchema.model_validate(p) for p in points],
    )


@router.get(
    "/stats/resources",
    response_model=ResourcesResponse,
    summary="Per-resource breakdown",
    description=(
        "Subscriptions, unsubscribes, earned and retention% per advertised resource "
        "(channel/group/bot), ordered by earnings. Optional `bot_id`."
    ),
)
async def stats_resources(
    from_: datetime | None = Query(default=None, alias="from"),
    to: datetime | None = Query(default=None),
    bot_id: int | None = Query(default=None),
    publisher: Publisher = Depends(get_current_publisher),
    session: AsyncSession = Depends(get_session),
    _rate_limit: None = Depends(stats_limit),
) -> ResourcesResponse:
    period_from, period_to = _resolve_window(from_, to)
    repo = StatsRepository(session)
    await _ensure_bot_scope(repo, publisher.id, bot_id)
    rows = await repo.by_resource(
        publisher_id=publisher.id, since=period_from, until=period_to, bot_id=bot_id
    )
    return ResourcesResponse(
        period_from=period_from,
        period_to=period_to,
        resources=[ResourceStatSchema.model_validate(r) for r in rows],
    )


@router.get(
    "/stats/demographics",
    response_model=DemographicsResponse,
    summary="Audience composition (nationality / age / premium)",
    description=(
        "All-time breakdown of your audience over one `dimension`:\n\n"
        "- `nationality` — country detected by IP at web-registration (VPN/proxy "
        "traffic is reported as «Неопределён»), falling back to self-reported country;\n"
        "- `age` — age bucket;\n"
        "- `premium` — Telegram Premium presence.\n\n"
        "Each slice carries an absolute `count` and a `pct` share. Optional `bot_id` "
        "scopes the audience to one of your bots. The tail is folded into a single "
        "«Другие» slice so percentages always sum to ~100."
    ),
)
async def stats_demographics(
    dimension: Literal["nationality", "age", "premium"] = Query(default="nationality"),
    bot_id: int | None = Query(default=None, description="Limit to one of your bots"),
    publisher: Publisher = Depends(get_current_publisher),
    session: AsyncSession = Depends(get_session),
    _rate_limit: None = Depends(stats_limit),
) -> DemographicsResponse:
    repo = StatsRepository(session)
    await _ensure_bot_scope(repo, publisher.id, bot_id)
    slices = await repo.by_demographic(
        publisher_id=publisher.id, dimension=dimension, bot_id=bot_id
    )
    total = sum(s.count for s in slices)
    return DemographicsResponse(
        dimension=dimension,
        total=total,
        bot_id=bot_id,
        slices=[
            DemographicSliceSchema(
                key=s.key,
                label=s.label,
                count=s.count,
                pct=round(100 * s.count / total) if total else 0,
            )
            for s in slices
        ],
    )
