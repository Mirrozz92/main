"""Advertiser-facing read API: account, campaigns, stats.

Authenticated with `Authorization: Bearer fsa_live_<key>` (the advertiser key
shown in the «Интеграция» mini-app). Lets an advertiser read their own balance
and campaign data programmatically — the same numbers they see in the bot.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from src.api.dependencies import get_current_advertiser, get_current_advertiser_token, get_session
from src.api.rate_limit import advertiser_api_limit
from src.core.db.models import Advertiser, AdvertiserApiToken, Campaign
from src.core.db.models.enums import CampaignStatus
from src.domain.stats import AdvertiserStatsRepository

router = APIRouter(prefix="/api/v1/advertiser", tags=["advertiser"])

DEFAULT_WINDOW_DAYS = 30
_ACTIVE_STATUSES = (CampaignStatus.ACTIVE, CampaignStatus.PENDING_MODERATION, CampaignStatus.PAUSED)


class TokenInfo(BaseModel):
    prefix: str = Field(description="First chars of the key (UI display)")
    requests_count: int
    last_used_at: datetime | None


class AdvertiserInfo(BaseModel):
    id: int
    tg_username: str | None
    full_name: str | None
    balance_rub: Decimal = Field(description="Spendable balance")
    reserved_rub: Decimal = Field(description="Held for running campaigns")
    total_spent_rub: Decimal
    campaigns_total: int
    active_campaigns: int
    current_token: TokenInfo


class CampaignItem(BaseModel):
    id: int
    title: str
    status: str
    theme: str | None
    budget_total_rub: Decimal
    budget_spent_rub: Decimal
    budget_reserved_rub: Decimal
    target_subscribers: int
    actual_subscribers: int
    resources_count: int
    created_at: datetime
    started_at: datetime | None


class CampaignsResponse(BaseModel):
    ok: bool = True
    total: int
    items: list[CampaignItem]


class StatsPoint(BaseModel):
    bucket: datetime
    spent_rub: Decimal
    bought: int


class StatsResponse(BaseModel):
    ok: bool = True
    from_: datetime = Field(serialization_alias="from")
    to: datetime
    spent_rub: Decimal
    bought: int
    active_campaigns: int
    timeseries: list[StatsPoint]


def _as_utc(dt: datetime) -> datetime:
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)


def _resolve_window(from_: datetime | None, to: datetime | None) -> tuple[datetime, datetime]:
    period_to = _as_utc(to) if to is not None else datetime.now(timezone.utc)
    period_from = _as_utc(from_) if from_ is not None else period_to - timedelta(days=DEFAULT_WINDOW_DAYS)
    return period_from, period_to


@router.get("/me", response_model=AdvertiserInfo, summary="Your advertiser account & balance")
async def advertiser_me(
    advertiser: Advertiser = Depends(get_current_advertiser),
    token: AdvertiserApiToken = Depends(get_current_advertiser_token),
    session: AsyncSession = Depends(get_session),
    _rate: None = Depends(advertiser_api_limit),
) -> AdvertiserInfo:
    counts = (
        await session.execute(
            select(Campaign.status).where(Campaign.advertiser_id == advertiser.id)
        )
    ).scalars().all()
    active = sum(1 for s in counts if s in _ACTIVE_STATUSES)
    return AdvertiserInfo(
        id=advertiser.id,
        tg_username=advertiser.tg_username,
        full_name=advertiser.full_name,
        balance_rub=advertiser.balance_rub,
        reserved_rub=advertiser.reserved_rub,
        total_spent_rub=advertiser.total_spent_rub,
        campaigns_total=len(counts),
        active_campaigns=active,
        current_token=TokenInfo(
            prefix=token.token_prefix,
            requests_count=token.requests_count,
            last_used_at=token.last_used_at,
        ),
    )


@router.get("/campaigns", response_model=CampaignsResponse, summary="Your campaigns")
async def advertiser_campaigns(
    limit: int = Query(default=50, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    advertiser: Advertiser = Depends(get_current_advertiser),
    session: AsyncSession = Depends(get_session),
    _rate: None = Depends(advertiser_api_limit),
) -> CampaignsResponse:
    total = (
        await session.execute(
            select(func.count(Campaign.id)).where(Campaign.advertiser_id == advertiser.id)
        )
    ).scalar_one()
    rows = (
        await session.execute(
            select(Campaign)
            .where(Campaign.advertiser_id == advertiser.id)
            .options(selectinload(Campaign.resources))
            .order_by(Campaign.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
    ).scalars().all()

    items: list[CampaignItem] = []
    for c in rows:
        target = sum(r.target_subscribers for r in c.resources)
        actual = sum(r.actual_subscribers for r in c.resources)
        items.append(
            CampaignItem(
                id=c.id,
                title=c.title,
                status=c.status.value,
                theme=c.theme,
                budget_total_rub=c.budget_total_rub,
                budget_spent_rub=c.budget_spent_rub,
                budget_reserved_rub=c.budget_reserved_rub,
                target_subscribers=target,
                actual_subscribers=actual,
                resources_count=len(c.resources),
                created_at=c.created_at,
                started_at=c.started_at,
            )
        )
    return CampaignsResponse(total=total, items=items)


@router.get("/stats", response_model=StatsResponse, summary="Spend & subscribers over a period")
async def advertiser_stats(
    from_: datetime | None = Query(default=None, alias="from"),
    to: datetime | None = Query(default=None),
    bucket: str = Query(default="day", pattern="^(day|week|month)$"),
    advertiser: Advertiser = Depends(get_current_advertiser),
    session: AsyncSession = Depends(get_session),
    _rate: None = Depends(advertiser_api_limit),
) -> StatsResponse:
    period_from, period_to = _resolve_window(from_, to)
    repo = AdvertiserStatsRepository(session)
    summary = await repo.summary(advertiser_id=advertiser.id, since=period_from, until=period_to)
    points = await repo.spend_timeseries(
        advertiser_id=advertiser.id, since=period_from, until=period_to, bucket=bucket
    )
    return StatsResponse(
        from_=period_from,
        to=period_to,
        spent_rub=summary.spent_rub,
        bought=summary.bought,
        active_campaigns=summary.active_campaigns,
        timeseries=[
            StatsPoint(bucket=p.bucket, spent_rub=p.spent_rub, bought=p.bought) for p in points
        ],
    )
