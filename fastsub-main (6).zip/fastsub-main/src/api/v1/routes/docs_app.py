"""Telegram Mini App: per-bot API integration docs.

Launched from the bot's «Интеграция (API)» button. Auth is by Telegram `initData`
(validated against the main bot token). The bot's real API key is fetched over an
initData-authed request and injected into the code examples, with a copy button and
a regenerate action. Dark liquid-glass design, matching the stats mini-app.

Routes (all hidden from the public OpenAPI schema):
  GET  /app/docs                 — the docs mini-app HTML page
  POST /app/docs/api/key         — {init_data, bot_id} → {key, base, bot_name}
  POST /app/docs/api/regenerate  — {init_data, bot_id} → {key}
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.dependencies import get_session
from src.core.config import get_settings
from src.core.db.models import Publisher, PublisherBot
from src.core.logging import get_logger
from src.domain.api_tokens import ApiTokenService
from src.domain.publisher_bots import PublisherBotRepository
from src.domain.publishers import PublisherRepository
from src.integrations.telegram.webapp import validate_init_data

router = APIRouter(tags=["miniapp"])
log = get_logger("api.docs_app")


class KeyRequest(BaseModel):
    init_data: str
    bot_id: int


async def _resolve_publisher(init_data: str, session: AsyncSession) -> Publisher:
    settings = get_settings()
    data = validate_init_data(init_data, settings.main_bot_token.get_secret_value())
    if data is None or not isinstance(data.get("user"), dict):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid init data")
    tg_id = data["user"].get("id")
    if tg_id is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="no user in init data")
    pub = await PublisherRepository(session).get_by_tg_id(int(tg_id))
    if pub is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Вы ещё не зарегистрированы как партнёр. Откройте бота и пройдите /start.",
        )
    if pub.is_banned:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="account disabled")
    return pub


async def _verify_bot(
    session: AsyncSession, publisher: Publisher, bot_id: int
) -> PublisherBot:
    bot = await PublisherBotRepository(session).get_by_id(bot_id)
    if bot is None or bot.publisher_id != publisher.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="bot not found")
    return bot


@router.post("/app/docs/api/key", include_in_schema=False)
async def app_docs_key(
    req: KeyRequest, session: AsyncSession = Depends(get_session)
) -> dict[str, Any]:
    publisher = await _resolve_publisher(req.init_data, session)
    bot = await _verify_bot(session, publisher, req.bot_id)
    svc = ApiTokenService(session)
    key = await svc.ensure_plaintext_for_bot(
        publisher_id=publisher.id, publisher_bot_id=bot.id
    )
    base = get_settings().public_base_url.rstrip("/")
    return {"key": key, "base": base, "bot_name": bot.name}


@router.post("/app/docs/api/regenerate", include_in_schema=False)
async def app_docs_regenerate(
    req: KeyRequest, session: AsyncSession = Depends(get_session)
) -> dict[str, Any]:
    publisher = await _resolve_publisher(req.init_data, session)
    bot = await _verify_bot(session, publisher, req.bot_id)
    svc = ApiTokenService(session)
    result = await svc.regenerate_for_bot(
        publisher_id=publisher.id, publisher_bot_id=bot.id, label="Integration"
    )
    return {"key": result.plaintext}


@router.get("/app/docs", response_class=HTMLResponse, include_in_schema=False)
async def app_docs_page() -> HTMLResponse:
    return HTMLResponse(_PAGE)


_PAGE = r"""<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Интеграция API</title>
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<style>
  :root{
    --bg:#0b0b0f; --glass:rgba(255,255,255,.06); --text:#f1f2f6; --hint:#8a8f9c;
    --accent:#4d8bff; --green:#30d158; --hair:rgba(255,255,255,.08);
    --sans:-apple-system,"SF Pro Text",system-ui,"Segoe UI",Roboto,sans-serif;
    --mono:ui-monospace,"SF Mono",Menlo,Consolas,monospace;
  }
  *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
  body{margin:0;background:var(--bg);color:var(--text);font-family:var(--sans);
    padding:env(safe-area-inset-top) 0 calc(env(safe-area-inset-bottom) + 28px);
    -webkit-font-smoothing:antialiased}
  body::before{content:"";position:fixed;inset:0;z-index:-1;pointer-events:none;
    background:radial-gradient(620px 360px at 50% -6%, rgba(77,139,255,.16), transparent 70%)}
  .wrap{max-width:640px;margin:0 auto;padding:16px 14px}
  h1{font-size:27px;font-weight:680;letter-spacing:-.5px;margin:8px 4px 2px}
  .sub{color:var(--hint);font-size:14px;margin:0 4px 18px;font-weight:500}
  .glass{background:var(--glass);border:1px solid rgba(255,255,255,.10);
    box-shadow:0 10px 30px rgba(0,0,0,.4),inset 0 1px 0 rgba(255,255,255,.08);
    backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px)}
  .card{border-radius:22px;padding:16px}
  .sec-title{font-size:13px;color:var(--hint);text-transform:uppercase;letter-spacing:.5px;
    font-weight:600;margin:26px 14px 9px}
  .keyhead{display:flex;align-items:center;justify-content:space-between;margin-bottom:11px}
  .keyhead .t{font-size:13px;color:var(--hint);text-transform:uppercase;letter-spacing:.5px;font-weight:600}
  .keyhead .regen{font-size:13px;color:var(--accent);font-weight:600;background:none;border:none;
    cursor:pointer;font-family:var(--sans);padding:4px}
  .keyrow{display:flex;align-items:center;gap:10px}
  .keyval{flex:1;min-width:0;font-family:var(--mono);font-size:13.5px;letter-spacing:-.2px;
    background:rgba(0,0,0,.28);border:1px solid var(--hair);border-radius:13px;padding:13px 14px;
    overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .btn{flex:none;display:inline-flex;align-items:center;gap:7px;border:none;cursor:pointer;
    font-family:var(--sans);font-weight:650;font-size:14px;border-radius:13px;padding:12px 15px;
    background:var(--accent);color:#fff;box-shadow:0 6px 18px rgba(77,139,255,.4)}
  .btn:active{transform:scale(.96)}
  .btn.ok{background:var(--green);box-shadow:0 6px 18px rgba(48,209,88,.4)}
  .btn svg{width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:2.3;
    stroke-linecap:round;stroke-linejoin:round}
  .lead{color:var(--hint);font-size:14px;line-height:1.5;margin:2px 4px 0}
  .ep{display:flex;align-items:center;gap:10px;margin-bottom:9px;flex-wrap:wrap}
  .m{font-weight:800;font-size:11px;padding:4px 9px;border-radius:8px;letter-spacing:.4px}
  .m.get{background:rgba(48,209,88,.16);color:#5ee08a}
  .m.post{background:rgba(77,139,255,.18);color:#8fb4ff}
  .path{font-family:var(--mono);font-size:14px;font-weight:600}
  .desc{color:var(--hint);font-size:13.5px;line-height:1.5;margin:0 0 11px}
  .code{position:relative;background:rgba(0,0,0,.32);border:1px solid var(--hair);
    border-radius:14px;padding:13px 14px;margin-top:11px}
  pre{margin:0;overflow-x:auto;font-family:var(--mono);font-size:12.5px;line-height:1.55;
    color:#e6e9f2;white-space:pre;-webkit-overflow-scrolling:touch}
  pre .s{color:#7ee0a3} pre .o{color:#ffb86b} pre .f{color:#8fb4ff}
  pre.lang[hidden]{display:none}
  .tabs{display:inline-flex;gap:4px;background:rgba(255,255,255,.06);border-radius:11px;padding:3px;margin-top:12px}
  .tab{border:none;background:transparent;color:var(--hint);font-family:var(--sans);font-weight:600;
    font-size:12.5px;padding:6px 13px;border-radius:9px;cursor:pointer}
  .tab.on{background:rgba(255,255,255,.15);color:var(--text);box-shadow:0 3px 10px rgba(0,0,0,.4)}
  .cp{position:absolute;top:9px;right:9px;background:rgba(255,255,255,.10);border:1px solid var(--hair);
    color:var(--hint);font-family:var(--sans);font-size:11px;font-weight:600;border-radius:9px;
    padding:5px 9px;cursor:pointer}
  .cp:active{background:rgba(255,255,255,.18)}
  .params{margin:8px 0 0;border-collapse:collapse;width:100%;font-size:13px}
  .params td{padding:7px 8px;border-top:.5px solid var(--hair);vertical-align:top}
  .params td:first-child{font-family:var(--mono);font-size:12.5px;white-space:nowrap;color:#cfe0ff}
  .params .req{color:#ff8f8f;font-size:11px;font-weight:600;margin-left:5px}
  .msg{display:none;text-align:center;color:var(--hint);padding:54px 20px;font-size:15px;line-height:1.5}
  .gap{height:13px}
</style>
</head>
<body>
<svg width="0" height="0" style="position:absolute" aria-hidden="true">
  <symbol id="i-copy" viewBox="0 0 24 24"><rect x="9" y="9" width="11" height="11" rx="2.4"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></symbol>
  <symbol id="i-check" viewBox="0 0 24 24"><path d="M5 12.5l4.2 4.2L19 7"/></symbol>
</svg>

<div class="wrap">
  <h1>Интеграция</h1>
  <div class="sub" id="sub">API вашего бота</div>

  <div id="content" style="display:none">
    <div class="card glass">
      <div class="keyhead">
        <span class="t">API-ключ</span>
        <button class="regen" id="regen">Перевыпустить</button>
      </div>
      <div class="keyrow">
        <div class="keyval" id="keyval">—</div>
        <button class="btn" id="copyKey"><svg><use href="#i-copy"/></svg><span>Копировать</span></button>
      </div>
      <div class="lead" style="margin-top:11px">Передавайте его в заголовке
        <span style="font-family:var(--mono);color:#cfe0ff">Authorization: Bearer …</span>
        Ключ один на бота. Перевыпуск мгновенно отключает старый.</div>
    </div>

    <div class="sec-title">Базовый URL</div>
    <div class="card glass"><div class="code"><button class="cp" data-cp>копировать</button><pre id="baseUrl">—</pre></div></div>

    <div class="sec-title">Методы</div>
    <div id="eps"></div>
  </div>

  <div class="msg" id="msg">Загрузка…</div>
</div>

<script>
const tg = window.Telegram ? window.Telegram.WebApp : null;
if (tg){ tg.ready(); tg.expand(); try{ tg.setHeaderColor("#0b0b0f"); tg.setBackgroundColor("#0b0b0f"); }catch(e){} }
const initData = tg ? tg.initData : "";
const params = new URLSearchParams(location.search);
const BOT_ID = parseInt(params.get("bot_id") || (tg && tg.initDataUnsafe && tg.initDataUnsafe.start_param) || "0") || null;

let KEY = "", BASE = "";

const EPS = [
  { group:"Задания", items:[
    { m:"POST", p:"/api/v1/request-op", d:"Выдать пользователю пачку спонсорских заданий (каналы/боты для подписки).",
      params:[["user_tg_id","req","Telegram ID пользователя"],["limit","","Сколько заданий вернуть (по умолчанию все доступные)"]],
      body:'{"user_tg_id": 123456789, "limit": 5}' },
    { m:"POST", p:"/api/v1/check-task", d:"Проверить статусы всех ресурсов одного задания разом.",
      params:[["task_id","req","Идентификатор задания из request-op"]],
      body:'{"task_id": "tsk_a1b2c3d4e5f6"}' },
    { m:"POST", p:"/api/v1/check-resource", d:"Проверить статус одного выданного ресурса.",
      params:[["link_id","req","Идентификатор ресурса из request-op"]],
      body:'{"link_id": "lnk_0a1b2c3d"}' },
    { m:"GET", p:"/api/v1/user/{user_id}/history", d:"История заданий конкретного пользователя, с пагинацией.",
      params:[["limit","","Размер страницы (1–100, по умолчанию 50)"],["offset","","Сколько пропустить"]],
      q:"?limit=50&offset=0" },
  ]},
  { group:"Аккаунт и вебхуки", items:[
    { m:"GET", p:"/api/v1/me", d:"Информация о вашем аккаунте и активном ключе." },
    { m:"POST", p:"/api/v1/webhook/configure", d:"Задать URL, куда мы шлём события (подписки/отписки). Секрет выдаётся один раз в ответе.",
      params:[["url","req","HTTPS-адрес вашего обработчика"]],
      body:'{"url": "https://example.com/fastsub/webhook"}' },
    { m:"GET", p:"/api/v1/webhook", d:"Текущая конфигурация вебхука." },
  ]},
  { group:"Статистика", items:[
    { m:"GET", p:"/api/v1/stats/summary", d:"KPI-сводка (заработок, подписки, retention) с динамикой к прошлому периоду.",
      params:[["from / to","","Период (ISO-8601). По умолчанию — последние 30 дней"],["bot_id","","Ограничить одним вашим ботом"]],
      q:"?from=2026-05-01T00:00:00Z" },
    { m:"GET", p:"/api/v1/stats/timeseries", d:"Ряды по времени для графиков.",
      params:[["bucket","","day | week | month (по умолчанию day)"],["from / to / bot_id","","см. выше"]],
      q:"?bucket=day" },
    { m:"GET", p:"/api/v1/stats/resources", d:"Разбивка заработка и подписок по ресурсам за период." },
    { m:"GET", p:"/api/v1/stats/demographics", d:"Состав аудитории: страны, возраст, Telegram Premium.",
      params:[["dimension","","nationality | age | premium"],["bot_id","","Ограничить одним ботом"]],
      q:"?dimension=nationality" },
    { m:"GET", p:"/api/v1/stats", d:"Сводные счётчики аккаунта за период.",
      q:"?from=2026-05-01T00:00:00Z" },
  ]},
];

const LANGS = [["curl","curl"],["py","Python"],["js","JS"]];
function exPath(e){ return e.p.replace("{user_id}", "123456789"); }
function genCurl(e){
  if (e.m === "GET")
    return `curl "{BASE}${exPath(e)}${e.q||""}" \\
  -H "Authorization: Bearer {KEY}"`;
  return `curl -X POST {BASE}${exPath(e)} \\
  -H "Authorization: Bearer {KEY}" \\
  -H "Content-Type: application/json" \\
  -d '${e.body}'`;
}
function genPy(e){
  if (e.m === "GET")
    return `import requests

r = requests.get(
    "{BASE}${exPath(e)}${e.q||""}",
    headers={"Authorization": "Bearer {KEY}"},
)
print(r.json())`;
  return `import requests

r = requests.post(
    "{BASE}${exPath(e)}",
    headers={"Authorization": "Bearer {KEY}"},
    json=${e.body},
)
print(r.json())`;
}
function genJs(e){
  if (e.m === "GET")
    return `const r = await fetch("{BASE}${exPath(e)}${e.q||""}", {
  headers: { "Authorization": "Bearer {KEY}" },
});
console.log(await r.json());`;
  return `const r = await fetch("{BASE}${exPath(e)}", {
  method: "POST",
  headers: {
    "Authorization": "Bearer {KEY}",
    "Content-Type": "application/json",
  },
  body: JSON.stringify(${e.body}),
});
console.log(await r.json());`;
}
function mkExamples(e){ return { curl: genCurl(e), py: genPy(e), js: genJs(e) }; }

function esc(s){ return (s||"").replace(/[&<>]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;"}[c])); }
function hl(code){
  return esc(code)
    .replace(/('[^']*'|"[^"]*")/g, m => '<span class="s">'+m+'</span>')
    .replace(/\b(import|from|const|await|async|return|def|None|true|false|null)\b/g, '<span class="o">$1</span>')
    .replace(/\b(curl|requests|fetch|print|console|JSON)\b/g, '<span class="f">$1</span>');
}
function fill(s){ return s.replace(/\{BASE\}/g, BASE).replace(/\{KEY\}/g, KEY); }

function render(){
  document.getElementById("baseUrl").textContent = BASE;
  let h = "";
  for (const g of EPS){
    h += '<div class="sec-title" style="margin-left:14px">'+esc(g.group)+'</div>';
    for (const e of g.items){
      let pr = "";
      if (e.params && e.params.length){
        pr = '<table class="params">';
        for (const [n, req, d] of e.params)
          pr += '<tr><td>'+esc(n)+(req?'<span class="req">required</span>':'')+'</td><td style="color:var(--hint)">'+esc(d)+'</td></tr>';
        pr += '</table>';
      }
      const ex = mkExamples(e);
      let tabs = '<div class="tabs">';
      let code = '<div class="code"><button class="cp" data-cp>копировать</button>';
      LANGS.forEach(([k, label], i) => {
        tabs += '<button class="tab'+(i===0?' on':'')+'" data-lang="'+k+'">'+esc(label)+'</button>';
        code += '<pre class="lang'+(i===0?' on':'')+'" data-lang="'+k+'"'+(i===0?'':' hidden')+'>'+hl(fill(ex[k]))+'</pre>';
      });
      tabs += '</div>'; code += '</div>';
      h += '<div class="card glass" style="margin-bottom:11px">'+
           '<div class="ep"><span class="m '+e.m.toLowerCase()+'">'+e.m+'</span><span class="path">'+esc(e.p)+'</span></div>'+
           '<div class="desc">'+esc(e.d)+'</div>'+ pr + tabs + code + '</div>';
    }
  }
  document.getElementById("eps").innerHTML = h;
  bindCopies(); bindTabs();
}

function bindTabs(){
  document.querySelectorAll(".tabs .tab").forEach(t => t.addEventListener("click", () => {
    const card = t.closest(".card"), lang = t.dataset.lang;
    card.querySelectorAll(".tabs .tab").forEach(x => x.classList.toggle("on", x === t));
    card.querySelectorAll("pre.lang").forEach(p => { const on = p.dataset.lang === lang; p.classList.toggle("on", on); p.hidden = !on; });
  }));
}

function bindCopies(){
  document.querySelectorAll("[data-cp]").forEach(b => b.addEventListener("click", () => {
    const scope = b.closest(".card") || b.parentElement;
    const pre = scope.querySelector("pre.lang.on") || b.parentElement.querySelector("pre");
    if (pre) copy(pre.innerText, b, "скопировано");
  }));
}

function copy(text, btn, okText){
  const done = () => { if (btn){ const t=btn.textContent; btn.textContent = okText||"✓"; setTimeout(()=>btn.textContent=t, 1400); } if (tg && tg.HapticFeedback) tg.HapticFeedback.notificationOccurred("success"); };
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, ()=>fallbackCopy(text, done));
  else fallbackCopy(text, done);
}
function fallbackCopy(text, done){
  const ta=document.createElement("textarea"); ta.value=text; ta.style.position="fixed"; ta.style.opacity="0";
  document.body.appendChild(ta); ta.select(); try{ document.execCommand("copy"); done(); }catch(e){} document.body.removeChild(ta);
}

function setKey(k){
  KEY = k;
  document.getElementById("keyval").textContent = k;
}

async function api(path){
  const r = await fetch(path, { method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({ init_data: initData, bot_id: BOT_ID }) });
  if (!r.ok) throw new Error("http "+r.status);
  return r.json();
}

async function boot(){
  if (!initData || !BOT_ID){ showMsg("Откройте эту страницу через кнопку «Интеграция» в боте FastSub."); return; }
  try{
    const d = await api("/app/docs/api/key");
    BASE = d.base; setKey(d.key);
    document.getElementById("sub").textContent = d.bot_name ? ("Бот: "+d.bot_name) : "API вашего бота";
    document.getElementById("msg").style.display = "none";
    document.getElementById("content").style.display = "";
    render();
  } catch(e){ showMsg("Не удалось загрузить. Попробуйте переоткрыть из бота."); }
}

document.getElementById("copyKey").addEventListener("click", () => {
  const btn = document.getElementById("copyKey"); copy(KEY, btn.querySelector("span"), "Скопировано");
  btn.classList.add("ok"); setTimeout(()=>btn.classList.remove("ok"), 1400);
});
function doRegen(){
  const b = document.getElementById("regen"); b.textContent = "…";
  api("/app/docs/api/regenerate")
    .then(d => { setKey(d.key); render(); b.textContent = "Готово"; })
    .catch(() => { b.textContent = "Ошибка"; })
    .finally(() => setTimeout(()=>b.textContent="Перевыпустить", 1600));
}
document.getElementById("regen").addEventListener("click", () => {
  const q = "Перевыпустить ключ? Старый сразу перестанет работать.";
  if (tg && tg.showConfirm) tg.showConfirm(q, ok => { if (ok) doRegen(); });
  else if (confirm(q)) doRegen();
});

function showMsg(t){ const m=document.getElementById("msg"); m.textContent=t; m.style.display=""; document.getElementById("content").style.display="none"; }
boot();
</script>
</body>
</html>"""
