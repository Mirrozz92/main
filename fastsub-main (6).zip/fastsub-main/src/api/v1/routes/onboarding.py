"""Onboarding web-form for end users.

Two routes:
  - GET  /onboard/{token} — render HTML form (no auth, token is the secret)
  - POST /onboard/{token} — handle form submission, create EndUser

The token is one-shot: consumed (deleted from Redis) on successful POST.
On invalid/expired token — show a friendly error page.
"""

from __future__ import annotations

from html import escape

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.dependencies import get_session
from src.core.config import get_settings
from src.core.logging import get_logger
from src.domain.end_users import EndUserService, OnboardingTokenService
from src.domain.exceptions import DomainError
from src.integrations.geoip import GeoIpClient, GeoResult

# No prefix — this is a top-level page, not under /api/v1
router = APIRouter(tags=["onboarding"])
log = get_logger("api.onboarding")


def _client_ip(request: Request) -> str | None:
    """Real client IP behind nginx (X-Forwarded-For: client, proxy, …)."""
    xff = request.headers.get("x-forwarded-for")
    if xff:
        first = xff.split(",")[0].strip()
        if first:
            return first
    real = request.headers.get("x-real-ip")
    if real:
        return real.strip()
    return request.client.host if request.client else None


async def _lookup_geo(request: Request) -> GeoResult:
    if not get_settings().geoip_enabled:
        return GeoResult.undetermined()
    return await GeoIpClient().lookup(_client_ip(request))


# --- HTML templates ---


def _render_form(token: str) -> str:
    return f"""<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, user-scalable=no">
<title>FastSub — Регистрация</title>
<style>
  :root{{
    --text:#f1f2f6; --hint:#8a8f9c; --accent:#4d8bff; --green:#30d158;
    --glass:rgba(255,255,255,.06); --hair:rgba(255,255,255,.09);
    --sans:-apple-system,"SF Pro Text",system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
  }}
  *{{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}}
  body{{color:var(--text);font-family:var(--sans);font-size:16px;-webkit-font-smoothing:antialiased;
    background:#0b0b0e;min-height:100vh}}
  body::before{{content:"";position:fixed;inset:0;z-index:-1;
    background:
      radial-gradient(540px 320px at 50% -8%, rgba(255,255,255,.07), transparent 62%),
      radial-gradient(620px 460px at 92% 3%, rgba(90,120,200,.09), transparent 60%),
      #0b0b0e}}
  .wrap{{max-width:520px;margin:0 auto;padding:30px 18px calc(40px + env(safe-area-inset-bottom))}}
  .logo{{font-size:30px;font-weight:760;letter-spacing:-.4px}}
  .lead{{color:var(--hint);font-size:15px;line-height:1.5;margin:8px 2px 6px}}
  .sec-label{{font-size:13px;color:var(--hint);text-transform:uppercase;letter-spacing:.5px;font-weight:600;margin:24px 14px 9px}}
  .group{{border-radius:18px;overflow:hidden;background:var(--glass);border:1px solid rgba(255,255,255,.10);
    box-shadow:0 8px 24px rgba(0,0,0,.40),inset 0 1px 0 rgba(255,255,255,.07);
    backdrop-filter:blur(14px) saturate(140%);-webkit-backdrop-filter:blur(14px) saturate(140%)}}
  .opt{{display:flex;align-items:center;gap:12px;padding:14px 16px;cursor:pointer;position:relative;
    font-size:16px;font-weight:500;transition:background .16s}}
  .opt + .opt::before{{content:"";position:absolute;top:0;left:54px;right:0;height:.5px;background:var(--hair)}}
  .opt:active{{background:rgba(77,139,255,.08)}}
  .opt.sel{{background:rgba(77,139,255,.14)}}
  .opt input{{position:absolute;opacity:0;pointer-events:none}}
  .tick{{width:24px;height:24px;border-radius:50%;border:2px solid rgba(255,255,255,.22);
    display:grid;place-items:center;flex:none;transition:.18s}}
  .tick svg{{width:13px;height:13px;stroke:#fff;stroke-width:3.2;fill:none;stroke-linecap:round;stroke-linejoin:round;
    opacity:0;transform:scale(.5);transition:.18s}}
  .opt.sel .tick{{background:var(--accent);border-color:var(--accent);box-shadow:0 4px 12px rgba(77,139,255,.42)}}
  .opt.sel .tick svg{{opacity:1;transform:scale(1)}}
  .consent{{display:flex;gap:12px;align-items:flex-start;margin:22px 4px 0;font-size:13.5px;
    color:var(--hint);line-height:1.5;cursor:pointer}}
  .consent input{{position:absolute;opacity:0;pointer-events:none}}
  .cbox{{width:23px;height:23px;border-radius:7px;border:2px solid rgba(255,255,255,.25);flex:none;margin-top:1px;
    display:grid;place-items:center;transition:.18s}}
  .cbox svg{{width:13px;height:13px;stroke:#fff;stroke-width:3.2;fill:none;stroke-linecap:round;stroke-linejoin:round;opacity:0;transition:.18s}}
  .consent.on .cbox{{background:var(--green);border-color:var(--green);box-shadow:0 4px 12px rgba(48,209,88,.4)}}
  .consent.on .cbox svg{{opacity:1}}
  .submit{{width:100%;margin-top:24px;padding:15px;border:none;border-radius:16px;cursor:pointer;
    font-family:var(--sans);font-size:16px;font-weight:680;color:#fff;letter-spacing:.2px;
    background:linear-gradient(180deg,#4d8bff,#2f6fe0);
    box-shadow:0 10px 26px rgba(47,111,224,.42),inset 0 1px 0 rgba(255,255,255,.25);
    transition:transform .14s,opacity .14s}}
  .submit:active{{transform:scale(.985)}}
  .submit:disabled{{opacity:.45;box-shadow:none;cursor:not-allowed}}
</style>
</head>
<body>
<svg width="0" height="0" style="position:absolute" aria-hidden="true">
  <symbol id="i-check" viewBox="0 0 24 24"><path d="M5 12.5l4.2 4.2L19 7"/></symbol>
</svg>

<div class="wrap">
  <div class="logo">FastSub</div>
  <p class="lead">Короткая анкета для персональных заданий. Любое поле можно пропустить.</p>

  <form method="post" action="/onboard/{escape(token)}" id="f">
    <div class="sec-label">Возраст</div>
    <div class="group">
      <label class="opt"><span class="tick"><svg><use href="#i-check"/></svg></span><span>Младше 14 лет</span><input type="radio" name="age_range" value="under_14"></label>
      <label class="opt"><span class="tick"><svg><use href="#i-check"/></svg></span><span>14 – 16 лет</span><input type="radio" name="age_range" value="14_16"></label>
      <label class="opt"><span class="tick"><svg><use href="#i-check"/></svg></span><span>16 – 18 лет</span><input type="radio" name="age_range" value="16_18"></label>
      <label class="opt"><span class="tick"><svg><use href="#i-check"/></svg></span><span>18 лет и старше</span><input type="radio" name="age_range" value="18_plus"></label>
    </div>

    <div class="sec-label">Пол</div>
    <div class="group">
      <label class="opt"><span class="tick"><svg><use href="#i-check"/></svg></span><span>Мужской</span><input type="radio" name="gender" value="male"></label>
      <label class="opt"><span class="tick"><svg><use href="#i-check"/></svg></span><span>Женский</span><input type="radio" name="gender" value="female"></label>
      <label class="opt"><span class="tick"><svg><use href="#i-check"/></svg></span><span>Не указывать</span><input type="radio" name="gender" value="undisclosed"></label>
    </div>

    <label class="consent" id="consentRow">
      <span class="cbox"><svg><use href="#i-check"/></svg></span>
      <input type="checkbox" name="consent" id="consent" required>
      <span>Я согласен(на) на обработку моих данных согласно политике конфиденциальности FastSub.</span>
    </label>

    <button type="submit" class="submit" id="submitBtn" disabled>Завершить регистрацию</button>
  </form>
</div>

<script>
  document.querySelectorAll('.opt').forEach(opt => {{
    const input = opt.querySelector('input');
    opt.addEventListener('click', () => {{
      document.querySelectorAll('.opt input[name="' + input.name + '"]').forEach(o => o.closest('.opt').classList.remove('sel'));
      opt.classList.add('sel');
    }});
  }});
  const consent = document.getElementById('consent');
  const consentRow = document.getElementById('consentRow');
  const submitBtn = document.getElementById('submitBtn');
  consent.addEventListener('change', () => {{
    consentRow.classList.toggle('on', consent.checked);
    submitBtn.disabled = !consent.checked;
  }});
</script>
</body>
</html>
"""


def _render_error(title: str, message: str) -> str:
    return f"""<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>FastSub — Ошибка</title>
<style>
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{font-family:-apple-system,"SF Pro Text",system-ui,"Segoe UI",Roboto,sans-serif;color:#f1f2f6;
    background:#0b0b0e;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:22px}}
  body::before{{content:"";position:fixed;inset:0;z-index:-1;
    background:radial-gradient(540px 320px at 50% -8%, rgba(255,255,255,.06), transparent 62%),#0b0b0e}}
  .box{{max-width:420px;width:100%;text-align:center;padding:32px 26px;border-radius:24px;
    background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.10);
    box-shadow:0 18px 50px rgba(0,0,0,.55),inset 0 1px 0 rgba(255,255,255,.07);
    backdrop-filter:blur(16px) saturate(140%);-webkit-backdrop-filter:blur(16px) saturate(140%)}}
  .icon{{font-size:46px;margin-bottom:12px}}
  h1{{font-size:22px;font-weight:720;letter-spacing:-.3px;margin-bottom:10px}}
  p{{color:#8a8f9c;font-size:15px;line-height:1.5}}
</style>
</head>
<body>
<div class="box">
  <div class="icon">⚠️</div>
  <h1>{escape(title)}</h1>
  <p>{escape(message)}</p>
</div>
</body>
</html>
"""


def _render_success() -> str:
    return """<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>FastSub — Готово</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,"SF Pro Text",system-ui,"Segoe UI",Roboto,sans-serif;color:#f1f2f6;
    background:#0b0b0e;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:22px}
  body::before{content:"";position:fixed;inset:0;z-index:-1;
    background:radial-gradient(560px 340px at 50% -6%, rgba(48,209,88,.12), transparent 62%),#0b0b0e}
  .box{max-width:420px;width:100%;text-align:center;padding:34px 26px;border-radius:24px;
    background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.10);
    box-shadow:0 18px 50px rgba(0,0,0,.55),inset 0 1px 0 rgba(255,255,255,.07);
    backdrop-filter:blur(16px) saturate(140%);-webkit-backdrop-filter:blur(16px) saturate(140%)}
  .badge{width:74px;height:74px;border-radius:50%;margin:0 auto 16px;display:grid;place-items:center;
    background:linear-gradient(140deg,#43d96a,#27b54a);box-shadow:0 12px 30px rgba(47,194,78,.45)}
  .badge svg{width:38px;height:38px;stroke:#fff;stroke-width:3.4;fill:none;stroke-linecap:round;stroke-linejoin:round}
  h1{font-size:23px;font-weight:740;letter-spacing:-.3px;margin-bottom:10px}
  p{color:#8a8f9c;font-size:15px;line-height:1.55}
  b{color:#f1f2f6}
</style>
</head>
<body>
<div class="box">
  <div class="badge"><svg viewBox="0 0 24 24"><path d="M5 12.5l4.2 4.2L19 7"/></svg></div>
  <h1>Регистрация завершена!</h1>
  <p>Вернитесь в Telegram-бот и нажмите <b>/start</b>, чтобы получить задания.</p>
</div>
</body>
</html>
"""


# --- Routes ---


@router.get("/onboard/{token}", response_class=HTMLResponse, include_in_schema=False)
async def show_form(token: str) -> HTMLResponse:
    """Render onboarding form. Token validated for existence only."""
    token_svc = OnboardingTokenService()
    payload = await token_svc.resolve(token)
    if payload is None:
        return HTMLResponse(
            _render_error(
                "Ссылка устарела",
                "Эта ссылка для регистрации больше не действительна. "
                "Запросите новую в боте, отправив /start.",
            ),
            status_code=404,
        )
    return HTMLResponse(_render_form(token))


@router.post("/onboard/{token}", response_class=HTMLResponse, include_in_schema=False)
async def submit_form(
    token: str,
    request: Request,
    age_range: str | None = Form(default=None),
    gender: str | None = Form(default=None),
    country_code: str | None = Form(default=None),
    country_other: str | None = Form(default=None),
    consent: str | None = Form(default=None),
    session: AsyncSession = Depends(get_session),
) -> HTMLResponse:
    """Submit handler — validate, create EndUser, consume token."""
    if not consent:
        return HTMLResponse(
            _render_error(
                "Не дано согласие",
                "Чтобы продолжить, нужно поставить галочку согласия.",
            ),
            status_code=400,
        )

    token_svc = OnboardingTokenService()
    payload = await token_svc.resolve(token)
    if payload is None:
        return HTMLResponse(
            _render_error(
                "Ссылка устарела",
                "Эта ссылка для регистрации больше не действительна.",
            ),
            status_code=404,
        )

    # Normalize empty strings to None
    age_range = age_range or None
    gender = gender or None
    country_code = country_code or None
    country_other = (country_other or "").strip() or None

    # Detect country / city / VPN from the registration IP. Best-effort and
    # fail-open: a VPN/proxy yields «Неопределён» (no geo counted).
    geo = await _lookup_geo(request)

    svc = EndUserService(session)
    try:
        end_user = await svc.create_from_form(
            user_tg_id=payload.user_tg_id,
            gender=gender,
            age_range=age_range,
            country_code=country_code,
            country_other=country_other,
            publisher_bot_id=payload.publisher_bot_id,
            geo_country=geo.country_code,
            city=geo.city,
            is_vpn=geo.is_vpn,
        )
    except DomainError as e:
        return HTMLResponse(
            _render_error("Ошибка валидации", str(e)),
            status_code=400,
        )

    # Consume token (one-shot)
    await token_svc.consume(token)

    log.info(
        "end_user_onboarded",
        user_tg_id=end_user.user_tg_id,
        country=end_user.country_code,
        age=end_user.age_range,
        geo_country=end_user.geo_country,
        city=end_user.city,
        is_vpn=end_user.is_vpn,
    )

    return HTMLResponse(_render_success())
