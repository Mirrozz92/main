"""Telegram Mini App: publisher statistics dashboard.

Served by FastSub and launched from the publisher bot. Auth is by Telegram
`initData` (validated against the main bot token) — no API token needed.

Routes (all hidden from the public OpenAPI schema):
  GET  /app/stats            — the mini-app HTML page
  POST /app/stats/api/data   — dashboard payload for a selected bot + period
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.dependencies import get_session
from src.core.config import get_settings
from src.core.db.models import Publisher
from src.core.logging import get_logger
from src.domain.advertisers import AdvertiserRepository
from src.domain.publishers import PublisherRepository
from src.domain.stats import AdvertiserStatsRepository, StatsRepository
from src.integrations.telegram.webapp import validate_init_data

router = APIRouter(tags=["miniapp"])
log = get_logger("api.stats_app")


class DataRequest(BaseModel):
    init_data: str
    days: int = 30
    bucket: Literal["day", "week", "month"] = "day"
    bot_id: int | None = None
    demo: Literal["nationality", "age", "premium"] = "nationality"
    # Active audience segment to filter the whole dashboard by, e.g. ("nationality","RU").
    seg_dim: str | None = None
    seg_key: str | None = None
    # Which role's dashboard to render. The advertiser block is only computed
    # for "advertiser" to keep each load light.
    role: Literal["publisher", "advertiser"] = "publisher"


async def _resolve_publisher(init_data: str, session: AsyncSession) -> Publisher:
    settings = get_settings()
    data = validate_init_data(init_data, settings.main_bot_token.get_secret_value())
    if data is None or not isinstance(data.get("user"), dict):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid init data")
    tg_id = data["user"].get("id")
    if tg_id is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="no user in init data")

    pub = await PublisherRepository(session).get_by_tg_id(int(tg_id))
    if pub is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Вы ещё не зарегистрированы как партнёр. Откройте бота и пройдите /start.",
        )
    if pub.is_banned:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="account disabled")
    return pub


@router.post("/app/stats/api/data", include_in_schema=False)
async def app_stats_data(
    req: DataRequest,
    session: AsyncSession = Depends(get_session),
) -> dict[str, Any]:
    publisher = await _resolve_publisher(req.init_data, session)

    days = max(1, min(int(req.days), 365))
    until = datetime.now(UTC)
    since = until - timedelta(days=days)

    repo = StatsRepository(session)

    bot_id = req.bot_id
    if bot_id is not None and not await repo.bot_belongs_to_publisher(
        publisher_id=publisher.id, bot_id=bot_id
    ):
        bot_id = None  # ignore foreign/stale bot ids

    # Active audience segment → filters every metric below (not the breakdown).
    audience: tuple[str, str] | None = None
    if req.seg_dim and req.seg_key and req.seg_key != "__rest__":
        audience = (req.seg_dim, req.seg_key)

    bots = await repo.list_bots(publisher_id=publisher.id)
    summary = await repo.summary(
        publisher_id=publisher.id, since=since, until=until, bot_id=bot_id, audience=audience
    )
    series = await repo.timeseries(
        publisher_id=publisher.id, since=since, until=until, bucket=req.bucket,
        bot_id=bot_id, audience=audience,
    )
    resources = await repo.by_resource(
        publisher_id=publisher.id, since=since, until=until, bot_id=bot_id, limit=30,
        audience=audience,
    )
    # The breakdown itself stays on the full (bot-scoped) audience so you can pick.
    demo_slices = await repo.by_demographic(
        publisher_id=publisher.id, dimension=req.demo, bot_id=bot_id
    )
    demo_total = sum(s.count for s in demo_slices)

    # Lifetime account overview (combines both roles of the same Telegram user):
    # publisher earnings + advertiser ad-spend + traffic bought.
    advertiser = await AdvertiserRepository(session).get_by_tg_id(publisher.tg_user_id)
    ad_spent_total = advertiser.total_spent_rub if advertiser is not None else Decimal("0")
    traffic_bought = (
        await repo.advertiser_traffic_bought(advertiser_id=advertiser.id)
        if advertiser is not None else 0
    )

    def f(d: Decimal) -> float:
        return float(d)

    # Advertiser dashboard block (only for the advertiser role + if they exist).
    advertiser_block: dict[str, Any] | None = None
    if req.role == "advertiser" and advertiser is not None:
        adv_repo = AdvertiserStatsRepository(session)
        adv_sum = await adv_repo.summary(advertiser_id=advertiser.id, since=since, until=until)
        adv_series = await adv_repo.spend_timeseries(
            advertiser_id=advertiser.id, since=since, until=until, bucket=req.bucket,
        )
        adv_res = await adv_repo.by_resource(
            advertiser_id=advertiser.id, since=since, until=until,
        )
        avg_price = (adv_sum.spent_rub / adv_sum.bought) if adv_sum.bought else Decimal("0")
        advertiser_block = {
            "summary": {
                "spent": f(adv_sum.spent_rub),
                "bought": adv_sum.bought,
                "active_campaigns": adv_sum.active_campaigns,
                "avg_price": f(avg_price),
            },
            "timeseries": [
                {"bucket": p.bucket, "spent": f(p.spent_rub), "bought": p.bought}
                for p in adv_series
            ],
            "resources": [
                {
                    "resource_id": r.resource_id,
                    "title": r.title,
                    "username": r.username,
                    "type": r.type,
                    "bought": r.bought,
                    "spent": f(r.spent_rub),
                }
                for r in adv_res
            ],
        }

    return {
        "ok": True,
        "role": req.role,
        "has_advertiser": advertiser is not None,
        "advertiser": advertiser_block,
        "overview": {
            "earned_total": f(publisher.total_earned_rub),
            "ad_spent_total": f(ad_spent_total),
            "traffic_bought": traffic_bought,
        },
        "period_from": since,
        "period_to": until,
        "days": days,
        "bucket": req.bucket,
        "bot_id": bot_id,
        "segment": ({"dim": audience[0], "key": audience[1]} if audience else None),
        "bots": [
            {"id": b.bot_id, "name": b.name, "username": b.username, "is_active": b.is_active}
            for b in bots
        ],
        "summary": {
            "earned": f(summary.earned_rub),
            "earned_growth_pct": summary.earned_growth_pct,
            "subs": summary.subs,
            "subs_growth_pct": summary.subs_growth_pct,
            "unsubs": summary.unsubs,
            "unsubs_growth_pct": summary.unsubs_growth_pct,
            "issued": summary.issued,
            "retention_pct": summary.retention_pct,
            "churn_ratio": summary.churn_ratio,
        },
        "timeseries": [
            {
                "bucket": p.bucket,
                "earned": f(p.earned_rub),
                "subs": p.subs,
                "unsubs": p.unsubs,
                "issued": p.issued,
            }
            for p in series
        ],
        "resources": [
            {
                "resource_id": r.resource_id,
                "title": r.title,
                "username": r.username,
                "type": r.type,
                "subs": r.subs,
                "unsubs": r.unsubs,
                "earned": f(r.earned_rub),
                "retention_pct": r.retention_pct,
            }
            for r in resources
        ],
        "demographics": {
            "dimension": req.demo,
            "total": demo_total,
            "slices": [
                {
                    "key": s.key,
                    "label": s.label,
                    "count": s.count,
                    "pct": round(100 * s.count / demo_total) if demo_total else 0,
                }
                for s in demo_slices
            ],
        },
    }


@router.get("/app/stats", response_class=HTMLResponse, include_in_schema=False)
async def app_stats_page() -> HTMLResponse:
    return HTMLResponse(_PAGE)


_PAGE = """<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, user-scalable=no">
<title>FastSub — Статистика</title>
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
  :root{
    --text:#f1f2f6; --hint:#8a8f9c; --accent:#4d8bff;
    --green:#30d158; --red:#ff453a;
    --glass:rgba(255,255,255,.06); --glass-strong:rgba(28,28,34,.80);
    --hair:rgba(255,255,255,.09);
    --sans:-apple-system,"SF Pro Text",system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
  }
  *{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
  body{color:var(--text);font-family:var(--sans);font-size:16px;-webkit-font-smoothing:antialiased;
    background:#0b0b0e}
  body::before{content:"";position:fixed;inset:0;z-index:-1;
    background:
      radial-gradient(540px 320px at 50% -8%, rgba(255,255,255,.07), transparent 62%),
      radial-gradient(620px 460px at 92% 3%, rgba(90,120,200,.09), transparent 60%),
      #0b0b0e}
  .wrap{max-width:680px;margin:0 auto;padding:8px 15px calc(46px + env(safe-area-inset-bottom))}
  h1{font-size:30px;font-weight:760;letter-spacing:.2px;margin:14px 2px 2px}
  .sub{color:var(--hint);font-size:14px;margin:0 2px}

  .controls{display:flex;flex-wrap:wrap;gap:9px;align-items:center;padding:14px 0 4px}
  .picker{flex:1;min-width:150px;display:flex;align-items:center;justify-content:space-between;gap:10px;
    background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);border-radius:15px;
    padding:11px 14px;font-size:15px;font-weight:500;cursor:pointer;color:var(--text);
    box-shadow:0 6px 16px rgba(0,0,0,.38),inset 0 1px 0 rgba(255,255,255,.07)}
  .picker .chev{color:var(--hint);flex:none;transition:transform .2s}
  .seg{display:inline-flex;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.10);
    border-radius:15px;padding:3px;box-shadow:inset 0 1px 0 rgba(255,255,255,.06)}
  .seg button{border:none;background:transparent;color:var(--hint);font-family:var(--sans);
    font-size:13px;font-weight:600;padding:8px 14px;border-radius:12px;cursor:pointer;
    transition:.18s ease}
  .seg button.on{background:rgba(255,255,255,.17);color:var(--text);box-shadow:0 4px 12px rgba(0,0,0,.45)}
  .roleseg{display:flex;width:100%;margin:13px 0 0}
  .roleseg button{flex:1;font-size:14px;padding:10px 14px}

  .sec-title{font-size:13px;color:var(--hint);text-transform:uppercase;letter-spacing:.5px;
    margin:24px 16px 9px;font-weight:600}
  .kpis{display:grid;grid-template-columns:1fr 1fr;gap:11px;margin-top:22px}
  .glass{background:var(--glass);border:1px solid rgba(255,255,255,.10);
    box-shadow:0 8px 24px rgba(0,0,0,.40),inset 0 1px 0 rgba(255,255,255,.07);
    backdrop-filter:blur(14px) saturate(140%);-webkit-backdrop-filter:blur(14px) saturate(140%)}
  .kpi{border-radius:20px;padding:15px 17px}
  .kpi .lbl{color:var(--hint);font-size:13px;margin-bottom:7px;font-weight:500}
  .kpi .val{font-size:26px;font-weight:740;letter-spacing:.2px;line-height:1.04;font-variant-numeric:tabular-nums}
  .kpi .grow{font-size:13px;margin-top:6px;font-weight:650;font-variant-numeric:tabular-nums}
  .up{color:var(--green)} .down{color:var(--red)} .flat{color:var(--hint)}

  /* account overview (lifetime, both roles) */
  .ov{display:grid;grid-template-columns:1fr 1fr 1fr;border-radius:20px;padding:16px 6px;margin-top:8px}
  .ov-i{padding:0 9px;text-align:center;position:relative;min-width:0}
  .ov-i + .ov-i::before{content:"";position:absolute;left:0;top:5px;bottom:5px;width:.5px;background:var(--hair)}
  .ov-i .lbl{color:var(--hint);font-size:12px;margin-bottom:7px;font-weight:500;line-height:1.25}
  .ov-i .val{font-size:20px;font-weight:740;letter-spacing:.2px;font-variant-numeric:tabular-nums;
    white-space:nowrap;overflow:hidden;text-overflow:ellipsis}

  .card{border-radius:22px;padding:15px 16px}
  .legend{display:flex;gap:18px;margin:0 2px 13px}
  .lg{display:flex;align-items:center;gap:8px;font-size:13px;color:var(--hint);font-weight:550;
    cursor:pointer;user-select:none;-webkit-user-select:none;transition:opacity .18s}
  .lg.off{opacity:.34}
  .badge{width:21px;height:21px;border-radius:50%;display:grid;place-items:center;flex:none}
  .badge svg{width:12px;height:12px;stroke:#fff;stroke-width:3.4;fill:none;stroke-linecap:round;stroke-linejoin:round}
  .badge.ok{background:linear-gradient(140deg,#43d96a,#27b54a);box-shadow:0 4px 11px rgba(47,194,78,.42)}
  .badge.no{background:linear-gradient(140deg,#ff6a60,#ef3a30);box-shadow:0 4px 11px rgba(255,69,58,.42)}
  .chart-box{position:relative;height:194px;width:100%}

  .list{border-radius:22px;overflow:hidden}
  .row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:13px 16px;position:relative}
  .row + .row::before{content:"";position:absolute;top:0;left:16px;right:0;height:.5px;background:var(--hair)}
  .row .l{min-width:0}
  .row .title{font-size:16px;font-weight:560;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .row .meta{color:var(--hint);font-size:13px;margin-top:2px}
  .row .r{text-align:right;flex:none}
  .row .amount{font-size:16px;font-weight:650;font-variant-numeric:tabular-nums}
  .row .ret{color:var(--hint);font-size:12px;margin-top:2px;font-variant-numeric:tabular-nums}
  .empty{color:var(--hint);text-align:center;padding:26px 16px;font-size:15px}
  .msg{color:var(--hint);text-align:center;padding:52px 24px;font-size:16px;line-height:1.45}

  /* audience (demographics) */
  .sec-row{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:24px 14px 9px}
  .sec-row .sec-title{margin:0}
  #demoSeg button{font-size:12px;padding:7px 11px}
  .demo-row{display:flex;align-items:center;gap:12px;padding:12px 16px;position:relative;
    cursor:pointer;transition:background .15s}
  .demo-row + .demo-row::before{content:"";position:absolute;top:0;left:16px;right:16px;height:.5px;background:var(--hair)}
  .demo-row:active{background:rgba(77,139,255,.10)}
  .demo-row.sel{background:rgba(77,139,255,.15)}
  .demo-row.sel .demo-name{color:#cfe0ff}
  .demo-row.fixed{cursor:default}
  .demo-row.fixed:active{background:transparent}
  .demo-name{font-size:15px;font-weight:560;flex:none;width:118px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .demo-bar{flex:1;height:8px;border-radius:6px;background:rgba(255,255,255,.07);overflow:hidden}
  .demo-bar i{display:block;height:100%;border-radius:6px;
    background:linear-gradient(90deg,#4d8bff,#7aa6ff);box-shadow:0 0 12px rgba(77,139,255,.45)}
  .demo-val{flex:none;width:74px;text-align:right;font-variant-numeric:tabular-nums;font-size:15px;font-weight:680}
  .demo-val .c{color:var(--hint);font-size:12px;font-weight:500;margin-left:5px}
  .donut-card{padding:18px 16px 10px}
  .donut-box{position:relative;height:214px;width:100%}
  .donut-center{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;
    justify-content:center;pointer-events:none}
  .donut-center b{font-size:24px;font-weight:680;letter-spacing:-.5px;font-variant-numeric:tabular-nums;line-height:1}
  .donut-center span{font-size:11px;color:var(--hint);text-transform:uppercase;letter-spacing:.5px;margin-top:3px}
  .seg-hint{display:flex;align-items:center;gap:8px;margin:12px 4px 2px;font-size:13px;color:var(--hint)}
  .seg-hint .chip{display:inline-flex;align-items:center;gap:8px;background:rgba(77,139,255,.16);
    border:1px solid rgba(77,139,255,.34);color:#cfe0ff;border-radius:13px;padding:6px 7px 6px 12px;font-weight:650}
  .seg-hint .x{display:grid;place-items:center;width:18px;height:18px;border-radius:50%;
    background:rgba(255,255,255,.14);cursor:pointer;font-weight:700;line-height:1}

  /* bottom-sheet bot picker */
  .overlay{position:fixed;inset:0;z-index:50;background:rgba(0,0,0,.52);
    backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px);
    opacity:0;pointer-events:none;transition:opacity .26s ease}
  .overlay.show{opacity:1;pointer-events:auto}
  .sheet{position:fixed;left:10px;right:10px;bottom:10px;z-index:51;
    background:var(--glass-strong);border:1px solid rgba(255,255,255,.12);border-radius:26px;
    box-shadow:0 24px 60px rgba(0,0,0,.60),inset 0 1px 0 rgba(255,255,255,.07);
    backdrop-filter:blur(22px) saturate(150%);-webkit-backdrop-filter:blur(22px) saturate(150%);
    transform:translateY(130%);transition:transform .34s cubic-bezier(.22,.72,.24,1);
    max-height:72vh;overflow:auto;padding:8px 8px calc(10px + env(safe-area-inset-bottom))}
  .sheet.show{transform:translateY(0)}
  .grab{width:38px;height:5px;border-radius:3px;background:rgba(255,255,255,.22);margin:8px auto 6px}
  .sheet-h{font-size:13px;color:var(--hint);text-transform:uppercase;letter-spacing:.5px;font-weight:600;padding:4px 14px 8px}
  .opt{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 16px;
    border-radius:16px;font-size:16px;cursor:pointer}
  .opt:active{background:rgba(47,123,255,.10)}
  .opt.sel{color:var(--accent);font-weight:650}
  .opt .tick{color:var(--accent);opacity:0}
  .opt.sel .tick{opacity:1}
</style>
</head>
<body>
<svg width="0" height="0" style="position:absolute" aria-hidden="true">
  <symbol id="i-check" viewBox="0 0 24 24"><path d="M5 12.5l4.2 4.2L19 7"/></symbol>
  <symbol id="i-cross" viewBox="0 0 24 24"><path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/></symbol>
  <symbol id="i-chev" viewBox="0 0 24 24"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/></symbol>
  <linearGradient id="tgprem" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="#6c93ff"/><stop offset=".5" stop-color="#976fff"/><stop offset="1" stop-color="#df69d1"/>
  </linearGradient>
</svg>

<div class="wrap">
  <h1>Статистика</h1>
  <div class="sub" id="scope">Загрузка…</div>

  <span class="seg roleseg" id="roleSeg" style="display:none">
    <button data-role="publisher" class="on">Паблишер</button>
    <button data-role="advertiser">Рекламодатель</button>
  </span>

  <div class="controls">
    <button class="picker" id="botBtn"><span id="botLbl">Все боты</span>
      <svg class="chev" width="15" height="15"><use href="#i-chev"/></svg></button>
    <span class="seg" id="periodSeg">
      <button data-d="7">Неделя</button>
      <button data-d="30" class="on">Месяц</button>
      <button data-d="90">3 мес</button>
    </span>
    <span class="seg" id="bucketSeg">
      <button data-b="day" class="on">Дни</button>
      <button data-b="week">Недели</button>
    </span>
  </div>

  <div id="content" style="display:none">
    <div class="sec-title">Итого по аккаунту</div>
    <div class="ov glass">
      <div class="ov-i"><div class="lbl">Заработано</div><div class="val" id="ov_earned">—</div></div>
      <div class="ov-i"><div class="lbl">Потрачено<br>на рекламу</div><div class="val" id="ov_spent">—</div></div>
      <div class="ov-i"><div class="lbl">Куплено<br>трафика</div><div class="val" id="ov_traffic">—</div></div>
    </div>

    <div id="pubView">
    <div class="sec-row">
      <div class="sec-title">Аудитория</div>
      <span class="seg" id="demoSeg">
        <button data-dem="nationality" class="on">Страны</button>
        <button data-dem="age">Возраст</button>
        <button data-dem="premium">Premium</button>
      </span>
    </div>
    <div class="card glass donut-card"><div class="donut-box"><canvas id="chDemo"></canvas><div class="donut-center" id="demoCenter"></div></div></div>
    <div class="list glass" id="demoBox"></div>
    <div class="seg-hint" id="segHint" style="display:none"></div>

    <div class="kpis">
      <div class="kpi glass"><div class="lbl">Заработок, ₽</div><div class="val" id="k_earned">—</div><div class="grow" id="g_earned"></div></div>
      <div class="kpi glass"><div class="lbl">Подписки</div><div class="val" id="k_subs">—</div><div class="grow" id="g_subs"></div></div>
      <div class="kpi glass"><div class="lbl">Retention</div><div class="val" id="k_ret">—</div><div class="grow" id="g_ret"></div></div>
      <div class="kpi glass"><div class="lbl">Отписки</div><div class="val" id="k_unsubs">—</div><div class="grow" id="g_unsubs"></div></div>
    </div>

    <div class="sec-title">Заработок, ₽</div>
    <div class="card glass"><div class="chart-box"><canvas id="chEarned"></canvas></div></div>

    <div class="sec-title">Подписки и отписки</div>
    <div class="card glass">
      <div class="legend">
        <span class="lg" id="lgSubs"><span class="badge ok"><svg><use href="#i-check"/></svg></span>Подписки</span>
        <span class="lg" id="lgUnsubs"><span class="badge no"><svg><use href="#i-cross"/></svg></span>Отписки</span>
      </div>
      <div class="chart-box"><canvas id="chSubs"></canvas></div>
    </div>

    <div class="sec-title">Retention, %</div>
    <div class="card glass"><div class="chart-box"><canvas id="chRet"></canvas></div></div>

    <div class="sec-title">По ресурсам</div>
    <div class="list glass" id="resBox"></div>
    </div><!-- /pubView -->

    <div id="advView" style="display:none">
      <div class="kpis">
        <div class="kpi glass"><div class="lbl">Потрачено, ₽</div><div class="val" id="a_spent">—</div></div>
        <div class="kpi glass"><div class="lbl">Куплено подписчиков</div><div class="val" id="a_bought">—</div></div>
        <div class="kpi glass"><div class="lbl">Активных кампаний</div><div class="val" id="a_active">—</div></div>
        <div class="kpi glass"><div class="lbl">Ср. цена, ₽</div><div class="val" id="a_avg">—</div></div>
      </div>

      <div class="sec-title">Расходы, ₽</div>
      <div class="card glass"><div class="chart-box"><canvas id="chSpend"></canvas></div></div>

      <div class="sec-title">Куплено подписчиков</div>
      <div class="card glass"><div class="chart-box"><canvas id="chBought"></canvas></div></div>

      <div class="sec-title">По ресурсам</div>
      <div class="list glass" id="advResBox"></div>
    </div>
  </div>

  <div class="msg" id="msg" style="display:none"></div>
</div>

<div class="overlay" id="ov"></div>
<div class="sheet" id="sheet">
  <div class="grab"></div>
  <div class="sheet-h">Выбор бота</div>
  <div id="sheetList"></div>
</div>

<script>
const tg = window.Telegram ? window.Telegram.WebApp : null;
if (tg) {
  tg.ready(); tg.expand();
  try { tg.setBackgroundColor('#0b0b0e'); tg.setHeaderColor('#0b0b0e'); } catch(e){}
}
const initData = tg ? tg.initData : "";
const qs = new URLSearchParams(location.search);
const state = { days: 30, bucket: "day", bot_id: qs.get("bot_id") ? parseInt(qs.get("bot_id")) : null, demo: "nationality", seg: null, role: "publisher" };
let BOTS = [];
const charts = {};
const COL = { accent:'#4d8bff', green:'#30d158', red:'#ff453a', hint:'#8a8f9c', grid:'rgba(255,255,255,.07)' };
const fmtRub = n => (n||0).toLocaleString("ru-RU",{maximumFractionDigits:2});
const PERIOD = {7:"Неделя",30:"Месяц",90:"3 месяца"};
function esc(s){ return (s||"").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\\"":"&quot;"}[c])); }

// Telegram Premium star — фирменный градиентный бейдж (заменяет эмодзи-звезду)
var PREMIUM_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 36 36" width="16" height="16" style="vertical-align:-3px;margin-right:5px"><path fill="url(#tgprem)" d="M27.287 34.627c-.404 0-.806-.124-1.152-.371L18 28.422l-8.135 5.834c-.693.496-1.623.496-2.312-.008-.689-.499-.979-1.385-.721-2.194l3.034-9.792-8.062-5.681c-.685-.505-.97-1.393-.708-2.203.264-.808 1.016-1.357 1.866-1.363L12.947 13l3.179-9.549c.268-.809 1.023-1.353 1.874-1.353.851 0 1.606.545 1.875 1.353L23 13l10.036.015c.853.006 1.606.556 1.867 1.363.263.81-.022 1.698-.708 2.203l-8.062 5.681 3.034 9.792c.26.809-.033 1.695-.72 2.194-.347.254-.753.379-1.16.379z"/></svg>';
function demoLabelHtml(dim, key, label){
  return (dim === "premium" && key === "premium" ? PREMIUM_SVG : "") + esc(label);
}

// Палитра долей для круговой диаграммы аудитории (строки подсвечиваются в тон)
var PIE = ['#4d8bff','#30d158','#ff9f0a','#bf5af2','#ff6482','#64d2ff','#ffd60a','#5e5ce6','#ac8e68'];
function demoColor(s, i){ return s.key === "__rest__" ? "rgba(255,255,255,.20)" : PIE[i % PIE.length]; }

function pickSeg(dim, key, label){
  if (key === "__rest__") return;
  if (state.seg && state.seg.dim === dim && state.seg.key === key) state.seg = null;  // повторный тап → сброс
  else state.seg = { dim: dim, key: key, label: label };
  load();
}

function renderDemoChart(d){
  const ctx = document.getElementById("chDemo");
  const center = document.getElementById("demoCenter");
  if (charts.chDemo) charts.chDemo.destroy();
  if (!d || !d.slices || !d.slices.length){ if (center) center.innerHTML = ""; return; }
  const colors = d.slices.map((s, i) => demoColor(s, i));
  const total = d.slices.reduce((a, s) => a + s.count, 0);
  charts.chDemo = new Chart(ctx, {
    type: "doughnut",
    data: { labels: d.slices.map(s => s.label),
      datasets: [{ data: d.slices.map(s => s.count), backgroundColor: colors,
        borderColor: "rgba(20,20,26,.55)", borderWidth: 2, hoverOffset: 6, spacing: 1 }] },
    options: { responsive: true, maintainAspectRatio: false, cutout: "64%", animation: { duration: 320 },
      onClick: (e, els) => { if (!els.length) return; const s = d.slices[els[0].index]; pickSeg(d.dimension, s.key, s.label); },
      plugins: { legend: { display: false },
        tooltip: { backgroundColor:"rgba(26,26,32,.95)", titleColor:"#f1f2f6", bodyColor:"#f1f2f6",
          borderColor:"rgba(255,255,255,.12)", borderWidth:1, cornerRadius:13, padding:11,
          titleFont:{weight:"600",size:12}, bodyFont:{size:13,weight:"600"}, displayColors:true, boxPadding:5, usePointStyle:true,
          callbacks: { label: (c) => " " + c.label + ": " + c.parsed.toLocaleString("ru-RU") + " · " + (total ? Math.round(c.parsed/total*100) : 0) + "%" } } } }
  });
  if (center) center.innerHTML = '<b>'+total.toLocaleString("ru-RU")+'</b><span>аудитория</span>';
}

function grow(el, pct, invert){
  if (pct === null || pct === undefined){ el.textContent=""; return; }
  const up = pct >= 0, good = invert ? !up : up;
  el.className = "grow " + (pct===0 ? "flat" : (good ? "up" : "down"));
  el.textContent = (up?"↑ ":"↓ ") + Math.abs(pct) + "%";
}

function areaFill(rgb){
  return (ctx)=>{ const ch=ctx.chart, a=ch.chartArea; if(!a) return 'transparent';
    const g=ch.ctx.createLinearGradient(0,a.top,0,a.bottom);
    g.addColorStop(0, rgb.replace(')', ',.34)').replace('rgb','rgba'));
    g.addColorStop(1, rgb.replace(')', ',0)').replace('rgb','rgba')); return g; };
}

function lineChart(id, labels, datasets){
  const ctx = document.getElementById(id);
  if (charts[id]) charts[id].destroy();
  charts[id] = new Chart(ctx, {
    type: "line",
    data: { labels, datasets: datasets.map(d => ({
      ...d, tension:.4, borderWidth:2.6, pointRadius:0, pointHoverRadius:5,
      pointBackgroundColor:d.borderColor, pointBorderColor:"#fff", pointBorderWidth:2,
      borderCapStyle:"round", fill:!!d.fill, cubicInterpolationMode:"monotone"
    })) },
    options: {
      responsive:true, maintainAspectRatio:false, interaction:{intersect:false,mode:"index"},
      animation:{duration:300},
      plugins:{
        legend:{ display:false },
        tooltip:{ backgroundColor:"rgba(26,26,32,.95)", titleColor:"#f1f2f6", bodyColor:"#f1f2f6",
          borderColor:"rgba(255,255,255,.12)", borderWidth:1, cornerRadius:13, padding:11,
          titleFont:{weight:"600",size:12}, bodyFont:{size:13,weight:"600"}, displayColors:true, boxPadding:5,
          caretSize:6, usePointStyle:true }
      },
      scales:{
        x:{ grid:{display:false}, border:{display:false},
            ticks:{color:COL.hint,maxRotation:0,autoSkip:true,maxTicksLimit:6,font:{size:11},padding:6} },
        y:{ grid:{color:COL.grid,drawTicks:false}, border:{display:false},
            ticks:{color:COL.hint,font:{size:11},maxTicksLimit:5,padding:8}, beginAtZero:true }
      }
    }
  });
}

function shortDate(iso){ const d=new Date(iso); return d.toLocaleDateString("ru-RU",{day:"2-digit",month:"short"}).replace('.',''); }

/* ---------- bot picker sheet ---------- */
const ov=document.getElementById("ov"), sheet=document.getElementById("sheet");
function openSheet(){ buildSheet(); ov.classList.add("show"); sheet.classList.add("show"); }
function closeSheet(){ ov.classList.remove("show"); sheet.classList.remove("show"); }
ov.addEventListener("click", closeSheet);
document.getElementById("botBtn").addEventListener("click", openSheet);
function buildSheet(){
  const list=document.getElementById("sheetList");
  const opt=(val,label)=>'<div class="opt'+((state.bot_id===val||(val===null&&!state.bot_id))?' sel':'')+'" data-v="'+(val===null?'':val)+'">'+
    '<span>'+esc(label)+'</span><svg class="tick" width="17" height="17"><use href="#i-check"/></svg></div>';
  let h=opt(null,"Все боты");
  for (const b of BOTS){ h+=opt(b.id, b.name + (b.username?" (@"+b.username+")":"")); }
  list.innerHTML=h;
  list.querySelectorAll(".opt").forEach(el=>el.addEventListener("click",()=>{
    const v=el.dataset.v; state.bot_id = v ? parseInt(v) : null; state.seg = null; closeSheet(); syncBotLabel(); load();
  }));
}
function syncBotLabel(){
  const b = state.bot_id ? BOTS.find(x=>x.id===state.bot_id) : null;
  document.getElementById("botLbl").textContent = b ? b.name : "Все боты";
}

function render(data){
  document.getElementById("content").style.display = "";
  document.getElementById("msg").style.display = "none";
  BOTS = data.bots; syncBotLabel();

  // Role switch (only if the user is also an advertiser).
  const roleSeg = document.getElementById("roleSeg");
  if (data.has_advertiser){ roleSeg.style.display = "flex"; }
  else { roleSeg.style.display = "none"; state.role = "publisher"; }
  roleSeg.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.role === data.role));

  const adv = data.role === "advertiser";
  document.getElementById("pubView").style.display = adv ? "none" : "";
  document.getElementById("advView").style.display = adv ? "" : "none";
  document.getElementById("botBtn").style.display = adv ? "none" : "";

  const botName = data.bot_id ? (data.bots.find(b=>b.id===data.bot_id)||{}).name : "Все боты";
  let scope = (adv ? "Реклама" : (botName||"—")) + " · " + (PERIOD[data.days]||data.days+" дн.");
  if (!adv && state.seg) scope += " · " + state.seg.label;
  document.getElementById("scope").textContent = scope;

  const ov = data.overview || {};
  document.getElementById("ov_earned").textContent = fmtRub(ov.earned_total) + " ₽";
  document.getElementById("ov_spent").textContent = fmtRub(ov.ad_spent_total) + " ₽";
  document.getElementById("ov_traffic").textContent = (ov.traffic_bought||0).toLocaleString("ru-RU");

  if (adv){ renderAdvertiser(data.advertiser); return; }

  const s = data.summary;
  document.getElementById("k_earned").textContent = fmtRub(s.earned);
  document.getElementById("k_subs").textContent = s.subs.toLocaleString("ru-RU");
  document.getElementById("k_ret").textContent = (s.retention_pct===null?"—":s.retention_pct+"%");
  document.getElementById("k_unsubs").textContent = s.unsubs.toLocaleString("ru-RU");
  grow(document.getElementById("g_earned"), s.earned_growth_pct, false);
  grow(document.getElementById("g_subs"), s.subs_growth_pct, false);
  grow(document.getElementById("g_ret"), null, false);
  grow(document.getElementById("g_unsubs"), s.unsubs_growth_pct, true);

  const labels = data.timeseries.map(p => shortDate(p.bucket));
  lineChart("chEarned", labels, [{label:"₽", data:data.timeseries.map(p=>p.earned), borderColor:COL.accent, backgroundColor:areaFill("rgb(47,123,255)"), fill:true}]);
  lineChart("chSubs", labels, [
    {label:"Подписки", data:data.timeseries.map(p=>p.subs), borderColor:COL.green},
    {label:"Отписки", data:data.timeseries.map(p=>p.unsubs), borderColor:COL.red}
  ]);
  document.getElementById("lgSubs").classList.remove("off");
  document.getElementById("lgUnsubs").classList.remove("off");
  const ret = data.timeseries.map(p => p.subs>0 ? Math.round((1 - p.unsubs/p.subs)*1000)/10 : null);
  lineChart("chRet", labels, [{label:"%", data:ret, borderColor:COL.accent, backgroundColor:areaFill("rgb(47,123,255)"), fill:true}]);

  const box = document.getElementById("resBox");
  if (!data.resources.length){ box.innerHTML = '<div class="empty">Пока нет данных за период</div>'; }
  else {
    let h = '';
    for (const r of data.resources){
      const sub = r.username ? "@"+r.username : r.type;
      h += '<div class="row"><div class="l"><div class="title">'+esc(r.title)+'</div>'+
           '<div class="meta">'+esc(sub)+' · '+r.subs+' подп.</div></div>'+
           '<div class="r"><div class="amount">'+fmtRub(r.earned)+' ₽</div>'+
           '<div class="ret">ret '+(r.retention_pct===null?"—":r.retention_pct+"%")+'</div></div></div>';
    }
    box.innerHTML = h;
  }

  renderDemo(data.demographics);
}

function renderAdvertiser(a){
  if (!a){ document.getElementById("advResBox").innerHTML = '<div class="empty">Нет данных</div>'; return; }
  const s = a.summary || {};
  document.getElementById("a_spent").textContent = fmtRub(s.spent) + " ₽";
  document.getElementById("a_bought").textContent = (s.bought||0).toLocaleString("ru-RU");
  document.getElementById("a_active").textContent = (s.active_campaigns||0).toLocaleString("ru-RU");
  document.getElementById("a_avg").textContent = fmtRub(s.avg_price) + " ₽";

  const labels = (a.timeseries||[]).map(p => shortDate(p.bucket));
  lineChart("chSpend", labels, [{label:"₽", data:a.timeseries.map(p=>p.spent), borderColor:COL.accent, backgroundColor:areaFill("rgb(47,123,255)"), fill:true}]);
  lineChart("chBought", labels, [{label:"подп.", data:a.timeseries.map(p=>p.bought), borderColor:COL.green, backgroundColor:areaFill("rgb(48,209,88)"), fill:true}]);

  const box = document.getElementById("advResBox");
  if (!a.resources || !a.resources.length){ box.innerHTML = '<div class="empty">Пока нет данных за период</div>'; return; }
  let h = '';
  for (const r of a.resources){
    const sub = r.username ? "@"+r.username : r.type;
    h += '<div class="row"><div class="l"><div class="title">'+esc(r.title)+'</div>'+
         '<div class="meta">'+esc(sub)+' · '+r.bought+' подп.</div></div>'+
         '<div class="r"><div class="amount">'+fmtRub(r.spent)+' ₽</div></div></div>';
  }
  box.innerHTML = h;
}

function renderDemo(d){
  if (!d) return;
  document.querySelectorAll("#demoSeg button").forEach(b => b.classList.toggle("on", b.dataset.dem === d.dimension));
  const box = document.getElementById("demoBox");
  if (!d.slices || !d.slices.length){
    box.innerHTML = '<div class="empty">Пока нет данных об аудитории</div>';
    renderDemoChart(null); renderSegHint(null); return;
  }
  let h = '';
  d.slices.forEach((s, i) => {
    const w = Math.max(3, Math.min(100, s.pct));
    const fixed = s.key === "__rest__";
    const sel = state.seg && state.seg.dim === d.dimension && state.seg.key === s.key;
    const c = demoColor(s, i);
    h += '<div class="demo-row'+(fixed?' fixed':'')+(sel?' sel':'')+'"'+
         (fixed?'':' data-key="'+esc(s.key)+'" data-label="'+esc(s.label)+'"')+'>'+
         '<span class="demo-name">'+demoLabelHtml(d.dimension, s.key, s.label)+'</span>'+
         '<span class="demo-bar"><i style="width:'+w+'%;background:'+c+';box-shadow:none"></i></span>'+
         '<span class="demo-val">'+s.pct+'%<span class="c">'+s.count.toLocaleString("ru-RU")+'</span></span></div>';
  });
  box.innerHTML = h;
  box.querySelectorAll(".demo-row[data-key]").forEach(el => el.addEventListener("click", () =>
    pickSeg(d.dimension, el.dataset.key, el.dataset.label)));
  renderDemoChart(d);
  renderSegHint(state.seg);
}

function renderSegHint(seg){
  const el = document.getElementById("segHint");
  if (!seg){ el.style.display = "none"; el.innerHTML = ""; return; }
  el.style.display = "";
  el.innerHTML = 'Статистика по сегменту: <span class="chip">'+demoLabelHtml(seg.dim, seg.key, seg.label)+
                 '<span class="x" id="segClear">✕</span></span>';
  document.getElementById("segClear").addEventListener("click", (e) => {
    e.stopPropagation(); state.seg = null; load();
  });
}

function showMsg(text){
  document.getElementById("content").style.display = "none";
  const m = document.getElementById("msg"); m.style.display = ""; m.textContent = text;
}

let loading = false;
async function load(){
  if (loading) return; loading = true;
  try{
    const r = await fetch("/app/stats/api/data", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({ init_data: initData, days: state.days, bucket: state.bucket, bot_id: state.bot_id, demo: state.demo,
        seg_dim: state.seg ? state.seg.dim : null, seg_key: state.seg ? state.seg.key : null, role: state.role })
    });
    if (!r.ok){ let d={}; try{ d=await r.json(); }catch(e){} showMsg(d.detail || ("Ошибка загрузки ("+r.status+")")); return; }
    render(await r.json());
  } catch(e){ showMsg("Не удалось загрузить статистику. Проверьте соединение."); }
  finally{ loading = false; }
}

document.querySelectorAll("#periodSeg button").forEach(b => b.addEventListener("click", () => {
  document.querySelectorAll("#periodSeg button").forEach(x=>x.classList.remove("on"));
  b.classList.add("on"); state.days = parseInt(b.dataset.d); load();
}));
document.querySelectorAll("#bucketSeg button").forEach(b => b.addEventListener("click", () => {
  document.querySelectorAll("#bucketSeg button").forEach(x=>x.classList.remove("on"));
  b.classList.add("on"); state.bucket = b.dataset.b; load();
}));
document.querySelectorAll("#demoSeg button").forEach(b => b.addEventListener("click", () => {
  if (b.classList.contains("on")) return;
  document.querySelectorAll("#demoSeg button").forEach(x=>x.classList.remove("on"));
  b.classList.add("on"); state.demo = b.dataset.dem; state.seg = null; load();
}));
document.querySelectorAll("#roleSeg button").forEach(b => b.addEventListener("click", () => {
  if (b.classList.contains("on")) return;
  document.querySelectorAll("#roleSeg button").forEach(x=>x.classList.remove("on"));
  b.classList.add("on"); state.role = b.dataset.role; state.seg = null; load();
}));

function toggleSeries(idx, el){
  const ch = charts["chSubs"]; if(!ch) return;
  const vis = ch.isDatasetVisible(idx);
  ch.setDatasetVisibility(idx, !vis); ch.update();
  el.classList.toggle("off", vis);
}
document.getElementById("lgSubs").addEventListener("click", e => toggleSeries(0, e.currentTarget));
document.getElementById("lgUnsubs").addEventListener("click", e => toggleSeries(1, e.currentTarget));

if (!initData){ showMsg("Откройте эту страницу через кнопку в боте FastSub."); }
else { load(); }
</script>
</body>
</html>"""
