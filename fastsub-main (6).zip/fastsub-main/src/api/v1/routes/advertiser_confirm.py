"""POST /api/v1/advertiser/confirm-start — advertiser confirms a bot-start task.

Bot-start tasks have no signal we can observe ourselves (the advertised bot is
the advertiser's own, not ours). The reliable verification is therefore a direct,
authenticated callback from the advertiser's bot: when it receives
`/start fastsub_<link_id>`, it calls this endpoint with the payload and the
Telegram id of the user who started it.

We cross-check that `user_id` matches the user we actually issued that link to —
so an advertiser can only confirm genuine starts, not credit arbitrary users.
On success the issue moves PENDING → SUBSCRIBED and follows the normal
hold → verified → payout pipeline.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.dependencies import get_current_advertiser, get_session
from src.api.rate_limit import advertiser_confirm_limit
from src.core.db.models import Advertiser, Campaign, CampaignResource
from src.core.db.models.enums import IssueStatus, TaskType
from src.core.logging import get_logger
from src.domain.issues import ResourceIssueRepository
from src.domain.issues.state_machine import IssueStateMachine
from src.domain.publishers import PublisherRepository

router = APIRouter(prefix="/api/v1", tags=["advertiser"])
log = get_logger("api.advertiser_confirm")

_PAYLOAD_PREFIX = "fastsub_"


class ConfirmStartRequest(BaseModel):
    start_param: str = Field(
        ...,
        min_length=4,
        max_length=64,
        description=(
            "The exact start payload your bot received, e.g. `fastsub_lnk_a1b2...`. "
            "The bare `link_id` is also accepted."
        ),
        examples=["fastsub_lnk_a1b2c3d4e5f6a1b2c3d4e5f6"],
    )
    user_id: int = Field(
        ...,
        description="Telegram id of the user who started your bot with this payload.",
        examples=[123456789],
    )


class ConfirmStartResponse(BaseModel):
    ok: bool
    link_id: str
    status: str = Field(
        ...,
        description="Resulting issue status (subscribed once accepted; idempotent on repeat).",
    )
    accepted: bool = Field(
        ...,
        description="True if this call moved the task forward or it was already confirmed.",
    )


@router.post(
    "/advertiser/confirm-start",
    response_model=ConfirmStartResponse,
    summary="Confirm a user started your advertised bot",
    description=(
        "Call this from your bot's `/start` handler when the payload begins with "
        "`fastsub_`. Authenticate with `Authorization: Bearer fsa_live_<key>`.\n\n"
        "**Body**: `start_param` (the payload) + `user_id` (the Telegram id that "
        "started the bot).\n\n"
        "**Idempotent**: repeated calls for an already-confirmed link return its "
        "current status without error.\n\n"
        "**Errors**:\n"
        "- `401` — missing/invalid key\n"
        "- `403` — the task belongs to a different advertiser\n"
        "- `404` — unknown link_id\n"
        "- `409` — `user_id` does not match the user this link was issued to\n\n"
        "**Rate limit**: 600 requests per minute per key."
    ),
)
async def confirm_start(
    body: ConfirmStartRequest,
    advertiser: Advertiser = Depends(get_current_advertiser),
    session: AsyncSession = Depends(get_session),
    _rate_limit: None = Depends(advertiser_confirm_limit),
) -> ConfirmStartResponse:
    link_id = body.start_param.strip()
    if link_id.startswith(_PAYLOAD_PREFIX):
        link_id = link_id[len(_PAYLOAD_PREFIX):]

    issue_repo = ResourceIssueRepository(session)
    issue = await issue_repo.get_by_link_id(link_id)
    if issue is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"link_id not found: {link_id}",
        )

    resource = await session.get(CampaignResource, issue.campaign_resource_id)
    if resource is None or resource.task_type != TaskType.START_BOT:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="this link is not a bot-start task",
        )

    # Ownership: the key's advertiser must own the campaign behind this task.
    campaign = await session.get(Campaign, resource.campaign_id)
    if campaign is None or campaign.advertiser_id != advertiser.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="this task belongs to a different advertiser",
        )

    # Anti-fraud: only the user we issued this link to can be confirmed.
    if issue.user_tg_id != body.user_id:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="user_id does not match the user this link was issued to",
        )

    accepted = False
    if issue.status == IssueStatus.PENDING:
        pub_repo = PublisherRepository(session)
        publisher = await pub_repo.get_by_id(issue.publisher_id)
        if publisher is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="publisher for this link no longer exists",
            )
        machine = IssueStateMachine(session)
        await machine.mark_subscribed(issue, publisher)
        accepted = issue.status == IssueStatus.SUBSCRIBED
        log.info(
            "advertiser_confirm_start",
            link_id=link_id, advertiser_id=advertiser.id,
            user_tg_id=body.user_id, status=issue.status.value,
        )
    elif issue.status in (IssueStatus.SUBSCRIBED, IssueStatus.VERIFIED, IssueStatus.PAID):
        # Already confirmed earlier — idempotent success.
        accepted = True

    return ConfirmStartResponse(
        ok=True,
        link_id=link_id,
        status=issue.status.value,
        accepted=accepted,
    )
