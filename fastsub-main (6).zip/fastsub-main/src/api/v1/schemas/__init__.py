"""Pydantic schemas for API v1."""

from src.api.v1.schemas.stats import (
    DemographicsResponse,
    DemographicSliceSchema,
    ResourcesResponse,
    ResourceStatSchema,
    StatsResponse,
    SummaryResponse,
    TimeseriesPointSchema,
    TimeseriesResponse,
    build_stats,
)
from src.api.v1.schemas.tasks import (
    CheckTaskRequest,
    CheckTaskResponse,
    IssueStatusItem,
    IssueStatusLiteral,
    RequestOpRequest,
    RequestOpResponse,
    TaskItem,
    UserHistoryResponse,
)
from src.api.v1.schemas.webhooks import (
    WebhookConfigureRequest,
    WebhookConfigureResponse,
    WebhookInfoResponse,
)

__all__ = [
    "CheckTaskRequest",
    "CheckTaskResponse",
    "DemographicSliceSchema",
    "DemographicsResponse",
    "IssueStatusItem",
    "IssueStatusLiteral",
    "RequestOpRequest",
    "RequestOpResponse",
    "ResourcesResponse",
    "ResourceStatSchema",
    "StatsResponse",
    "SummaryResponse",
    "TaskItem",
    "TimeseriesPointSchema",
    "TimeseriesResponse",
    "UserHistoryResponse",
    "WebhookConfigureRequest",
    "WebhookConfigureResponse",
    "WebhookInfoResponse",
    "build_stats",
]
